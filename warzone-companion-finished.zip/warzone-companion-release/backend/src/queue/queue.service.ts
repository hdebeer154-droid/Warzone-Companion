import { Injectable, Logger, OnModuleDestroy } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Queue, QueueOptions, Worker, Processor } from 'bullmq';

export const QUEUES = {
  SYNC: 'sync',
  OCR: 'ocr',
  NOTIFICATIONS: 'notifications',
  MAINTENANCE: 'maintenance',
} as const;

export type QueueName = (typeof QUEUES)[keyof typeof QUEUES];

@Injectable()
export class QueueService implements OnModuleDestroy {
  private readonly logger = new Logger(QueueService.name);
  private readonly queues = new Map<string, Queue>();
  private readonly workers: Worker[] = [];
  private readonly connection: { host: string; port: number };
  private readonly prefix: string;

  constructor(private readonly config: ConfigService) {
    this.connection = {
      host: this.config.get<string>('redis.host')!,
      port: this.config.get<number>('redis.port')!,
    };
    this.prefix = this.config.get<string>('redis.prefix') ?? 'wz';
  }

  private options(): QueueOptions {
    return {
      connection: { ...this.connection, maxRetriesPerRequest: null },
      prefix: this.prefix,
      defaultJobOptions: {
        attempts: 5,
        backoff: { type: 'exponential', delay: 2000 },
        removeOnComplete: 200,
        removeOnFail: 500,
      },
    };
  }

  getQueue(name: QueueName): Queue {
    let q = this.queues.get(name);
    if (!q) {
      q = new Queue(name, this.options());
      this.queues.set(name, q);
    }
    return q;
  }

  /** Register a worker for a queue with the given processor. */
  createWorker(name: QueueName, processor: Processor, concurrency = 4): Worker {
    const worker = new Worker(name, processor, {
      connection: { ...this.connection, maxRetriesPerRequest: null },
      prefix: this.prefix,
      concurrency,
    });
    worker.on('failed', (job, err) => this.logger.warn(`[${name}] job ${job?.id} failed: ${err?.message}`));
    worker.on('completed', (job) => this.logger.debug(`[${name}] job ${job.id} completed`));
    this.workers.push(worker);
    this.logger.log(`Worker started for queue '${name}' (concurrency=${concurrency})`);
    return worker;
  }

  async addSync(userId: string, accountId?: string, opts?: { delay?: number; reason?: string }) {
    return this.getQueue(QUEUES.SYNC).add(
      'sync-account',
      { userId, accountId, reason: opts?.reason ?? 'manual' },
      { jobId: `sync:${userId}:${accountId ?? 'all'}:${Date.now()}`, delay: opts?.delay },
    );
  }

  async addOcr(scanId: string, userId: string) {
    return this.getQueue(QUEUES.OCR).add('process-scan', { scanId, userId });
  }

  async addNotification(userId: string, payload: Record<string, any>) {
    return this.getQueue(QUEUES.NOTIFICATIONS).add('push', { userId, ...payload });
  }

  async getCounts(name: QueueName) {
    const q = this.getQueue(name);
    return q.getJobCounts('waiting', 'active', 'completed', 'failed', 'delayed');
  }

  async onModuleDestroy(): Promise<void> {
    await Promise.all(this.workers.map((w) => w.close().catch(() => undefined)));
    await Promise.all([...this.queues.values()].map((q) => q.close().catch(() => undefined)));
  }
}
