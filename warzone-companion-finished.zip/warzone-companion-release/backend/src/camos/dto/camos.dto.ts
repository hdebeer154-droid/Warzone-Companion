import { Type } from 'class-transformer';
import { IsBoolean, IsInt, IsOptional, Min } from 'class-validator';

export class UpdateCamoProgressDto {
  @IsOptional() @Type(() => Number) @IsInt() @Min(0) currentValue?: number;
  @IsOptional() @IsBoolean() completed?: boolean;
}
