import { Body, Controller, Get, Param, Patch, Query } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { CamosService } from './camos.service';
import { UpdateCamoProgressDto } from './dto/camos.dto';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';

@ApiTags('camos')
@ApiBearerAuth()
@Controller('camos')
export class CamosController {
  constructor(private readonly camos: CamosService) {}

  @Get('overview')
  overview(@CurrentUser() user: AuthUser, @Query('gameId') gameId?: string) {
    return this.camos.overview(user.id, gameId);
  }

  @Get('sets')
  sets(@CurrentUser() user: AuthUser, @Query('gameId') gameId?: string) {
    return this.camos.sets(user.id, gameId);
  }

  @Get('weapons/:weaponId')
  weaponCamos(@CurrentUser() user: AuthUser, @Param('weaponId') weaponId: string) {
    return this.camos.weaponCamos(user.id, weaponId);
  }

  @Patch('progress/:challengeId')
  updateProgress(@CurrentUser() user: AuthUser, @Param('challengeId') challengeId: string, @Body() dto: UpdateCamoProgressDto) {
    return this.camos.updateProgress(user.id, challengeId, dto);
  }
}
