import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CatalogService } from '../catalog/catalog.service';
import { UpdateCamoProgressDto } from './dto/camos.dto';

@Injectable()
export class CamosService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly catalog: CatalogService,
  ) {}

  private async gameId(gameId?: string): Promise<string> {
    return gameId ?? (await this.catalog.getActiveGame()).id;
  }

  /** Overall + per-weapon-category camo completion for a user. */
  async overview(userId: string, gameId?: string) {
    const gid = await this.gameId(gameId);
    const challenges = await this.prisma.camoChallenge.findMany({
      where: { weapon: { gameId: gid, active: true } },
      select: { id: true, weaponId: true, weapon: { select: { category: true } } },
    });
    const progress = await this.prisma.camoProgress.findMany({
      where: { userId, camoChallengeId: { in: challenges.map((c) => c.id) } },
      select: { camoChallengeId: true, completed: true },
    });
    const completedSet = new Set(progress.filter((p) => p.completed).map((p) => p.camoChallengeId));

    const byCategory = new Map<string, { total: number; completed: number }>();
    let total = 0;
    let completed = 0;
    for (const c of challenges) {
      total += 1;
      const done = completedSet.has(c.id);
      if (done) completed += 1;
      const cur = byCategory.get(c.weapon.category) ?? { total: 0, completed: 0 };
      cur.total += 1;
      if (done) cur.completed += 1;
      byCategory.set(c.weapon.category, cur);
    }

    return {
      overall: {
        completed,
        total,
        completionPct: total ? Math.round((completed / total) * 100) : 0,
      },
      byCategory: [...byCategory.entries()]
        .map(([category, v]) => ({
          category,
          completed: v.completed,
          total: v.total,
          completionPct: v.total ? Math.round((v.completed / v.total) * 100) : 0,
        }))
        .sort((a, b) => b.total - a.total),
    };
  }

  async sets(userId: string, gameId?: string) {
    const gid = await this.gameId(gameId);
    const sets = await this.prisma.camoSet.findMany({
      where: { gameId: gid },
      orderBy: { orderIndex: 'asc' },
      include: {
        camos: {
          include: {
            challenges: {
              include: { progress: { where: { userId } } },
            },
          },
        },
      },
    });
    return sets.map((s) => {
      let total = 0;
      let completed = 0;
      for (const camo of s.camos) {
        for (const ch of camo.challenges) {
          total += 1;
          const p = ch.progress[0];
          if (p?.completed || (p?.currentValue ?? 0) >= (p?.targetValue ?? ch.targetValue)) completed += 1;
        }
      }
      return {
        id: s.id,
        name: s.name,
        category: s.category,
        orderIndex: s.orderIndex,
        camoCount: s.camos.length,
        completed,
        total,
        completionPct: total ? Math.round((completed / total) * 100) : 0,
        camos: s.camos.map((camo) => ({
          id: camo.id,
          name: camo.name,
          imageUrl: camo.imageUrl,
          rarity: camo.rarity,
          challengeCount: camo.challenges.length,
          completed: camo.challenges.filter((ch) => {
            const p = ch.progress[0];
            return p?.completed || (p?.currentValue ?? 0) >= (p?.targetValue ?? ch.targetValue);
          }).length,
        })),
      };
    });
  }

  /** All camo challenges for a weapon with the user's progress merged in. */
  async weaponCamos(userId: string, weaponId: string) {
    const weapon = await this.prisma.weapon.findUnique({ where: { id: weaponId } });
    if (!weapon) throw new NotFoundException('Weapon not found');
    const challenges = await this.prisma.camoChallenge.findMany({
      where: { weaponId },
      include: { camo: { include: { camoSet: true } }, progress: { where: { userId } } },
    });
    return challenges.map((c) => {
      const p = c.progress[0];
      const current = p?.currentValue ?? 0;
      const target = p?.targetValue ?? c.targetValue;
      return {
        id: c.id,
        description: c.description,
        requirementType: c.requirementType,
        gameMode: c.gameMode,
        camo: { id: c.camo.id, name: c.camo.name, imageUrl: c.camo.imageUrl, rarity: c.camo.rarity, set: c.camo.camoSet.name, setCategory: c.camo.camoSet.category },
        currentValue: current,
        targetValue: target,
        completed: p?.completed ?? current >= target,
        source: p?.source ?? 'CALCULATED',
        progressPct: target ? Math.min(100, Math.round((current / target) * 100)) : 0,
      };
    });
  }

  async updateProgress(userId: string, challengeId: string, dto: UpdateCamoProgressDto) {
    const challenge = await this.prisma.camoChallenge.findUnique({ where: { id: challengeId } });
    if (!challenge) throw new NotFoundException('Camo challenge not found');
    const existing = await this.prisma.camoProgress.findUnique({
      where: { userId_camoChallengeId: { userId, camoChallengeId: challengeId } },
    });
    const target = existing?.targetValue ?? challenge.targetValue;
    const current = dto.currentValue ?? existing?.currentValue ?? 0;
    const completed = dto.completed ?? current >= target;
    return this.prisma.camoProgress.upsert({
      where: { userId_camoChallengeId: { userId, camoChallengeId: challengeId } },
      create: { userId, camoChallengeId: challengeId, currentValue: current, targetValue: target, completed, source: 'MANUAL' },
      update: { currentValue: current, completed, source: 'MANUAL' },
    });
  }
}
