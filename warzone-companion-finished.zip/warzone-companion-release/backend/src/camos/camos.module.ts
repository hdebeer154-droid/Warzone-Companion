import { Module } from '@nestjs/common';
import { CamosController } from './camos.controller';
import { CamosService } from './camos.service';

@Module({
  controllers: [CamosController],
  providers: [CamosService],
  exports: [CamosService],
})
export class CamosModule {}
