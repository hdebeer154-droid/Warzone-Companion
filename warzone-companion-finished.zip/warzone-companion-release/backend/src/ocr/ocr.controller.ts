import {
  Body,
  Controller,
  Get,
  Param,
  Post,
  Query,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiConsumes, ApiTags } from '@nestjs/swagger';
import { OcrService } from './ocr.service';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';

@ApiTags('ocr')
@ApiBearerAuth()
@Controller('ocr')
export class OcrController {
  constructor(private readonly ocr: OcrService) {}

  @Post('scan')
  @ApiConsumes('multipart/form-data')
  @UseInterceptors(FileInterceptor('image', { limits: { fileSize: 12 * 1024 * 1024 } }))
  scan(
    @CurrentUser() user: AuthUser,
    @UploadedFile() file: any,
    @Body('text') text?: string,
  ) {
    return this.ocr.scan(user.id, file, text);
  }

  @Get('scans')
  list(@CurrentUser() user: AuthUser, @Query('page') page?: string, @Query('pageSize') pageSize?: string) {
    return this.ocr.listScans(user.id, Number(page ?? 1), Number(pageSize ?? 20));
  }

  @Get('scans/:id')
  get(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    return this.ocr.getScan(user.id, id);
  }

  @Post('scans/:id/confirm')
  confirm(@CurrentUser() user: AuthUser, @Param('id') id: string, @Body('detections') detections?: any[]) {
    return this.ocr.confirm(user.id, id, detections);
  }

  @Post('scans/:id/reject')
  reject(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    return this.ocr.reject(user.id, id);
  }
}
