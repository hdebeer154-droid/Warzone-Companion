import { BadRequestException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { StorageService } from '../storage/storage.service';
import { ActivityService } from '../activity/activity.service';
import { ObjectivesService } from '../objectives/objectives.service';
import { CatalogService } from '../catalog/catalog.service';
import { Detection, ParseContext, parseDetections, preprocessImage } from './ocr.parser';

@Injectable()
export class OcrService {
  private readonly logger = new Logger(OcrService.name);
  private workerPromise: Promise<any> | null = null;

  constructor(
    private readonly prisma: PrismaService,
    private readonly storage: StorageService,
    private readonly config: ConfigService,
    private readonly activity: ActivityService,
    private readonly objectives: ObjectivesService,
    private readonly catalog: CatalogService,
  ) {}

  private get threshold(): number {
    return this.config.get<number>('ocr.confidenceThreshold') ?? 0.95;
  }

  /** Lazily create a reusable Tesseract worker. */
  private async getWorker(): Promise<any> {
    if (!this.workerPromise) {
      this.workerPromise = (async () => {
        const { createWorker } = await import('tesseract.js');
        const worker = await createWorker('eng');
        return worker;
      })();
    }
    return this.workerPromise;
  }

  private async recognize(buffer: Buffer): Promise<string> {
    const worker = await this.getWorker();
    const { data } = await worker.recognize(buffer);
    return data.text as string;
  }

  private async buildContext(): Promise<ParseContext> {
    const game = await this.catalog.getActiveGame();
    const [weapons, camos] = await Promise.all([
      this.prisma.weapon.findMany({ where: { gameId: game.id, active: true }, select: { id: true, name: true, slug: true, category: true } }),
      this.prisma.camo.findMany({ where: { camoSet: { gameId: game.id } }, select: { id: true, name: true } }),
    ]);
    return { weapons, camos };
  }

  /**
   * Full pipeline: store → preprocess → OCR → parse → match → confidence → persist.
   * `providedText` allows deterministic testing without running the OCR engine.
   */
  async scan(userId: string, file?: { buffer: Buffer; originalname: string; mimetype: string }, providedText?: string) {
    if (!file && !providedText) throw new BadRequestException('Provide an image or text to scan');

    let imageUrl: string | null = null;
    let rawText = providedText ?? '';

    if (file) {
      const stored = await this.storage.put('screenshots', file.originalname || 'scan.png', file.buffer, file.mimetype || 'image/png');
      imageUrl = stored.url;
    }

    const scan = await this.prisma.ocrScan.create({
      data: { userId, imageUrl, status: 'PROCESSING' },
    });

    try {
      if (file && !providedText) {
        const pre = await preprocessImage(file.buffer);
        rawText = await this.recognize(pre);
      }
      const ctx = await this.buildContext();
      const detections = parseDetections(rawText, ctx);

      // Confidence gate: everything >= threshold can auto-apply.
      const allHighConfidence = detections.length > 0 && detections.every((d) => d.confidence >= this.threshold && d.matched);
      const status = detections.length === 0 ? 'FAILED' : allHighConfidence ? 'APPLIED' : 'AWAITING_CONFIRMATION';

      const updated = await this.prisma.ocrScan.update({
        where: { id: scan.id },
        data: {
          rawText,
          detections: detections as unknown as Prisma.InputJsonValue,
          status,
          error: detections.length === 0 ? 'No recognisable progression found in the image' : null,
        },
      });

      let applied = 0;
      if (status === 'APPLIED') {
        applied = await this.applyDetections(userId, detections, false);
        await this.prisma.ocrScan.update({ where: { id: scan.id }, data: { appliedCount: applied } });
      }

      return { ...updated, appliedCount: applied, threshold: this.threshold };
    } catch (err) {
      this.logger.error(`OCR scan failed: ${(err as Error).message}`);
      await this.prisma.ocrScan.update({
        where: { id: scan.id },
        data: { status: 'FAILED', error: (err as Error).message },
      });
      throw new BadRequestException(`OCR processing failed: ${(err as Error).message}`);
    }
  }

  async listScans(userId: string, page = 1, pageSize = 20) {
    const [items, total] = await Promise.all([
      this.prisma.ocrScan.findMany({ where: { userId }, orderBy: { createdAt: 'desc' }, skip: (page - 1) * pageSize, take: pageSize }),
      this.prisma.ocrScan.count({ where: { userId } }),
    ]);
    return { items, total, page, pageSize };
  }

  async getScan(userId: string, id: string) {
    const scan = await this.prisma.ocrScan.findFirst({ where: { id, userId } });
    if (!scan) throw new NotFoundException('Scan not found');
    return scan;
  }

  async confirm(userId: string, id: string, overrides?: Detection[]) {
    const scan = await this.getScan(userId, id);
    const detections = (overrides ?? (scan.detections as unknown as Detection[])) ?? [];
    const applied = await this.applyDetections(userId, detections, true);
    return this.prisma.ocrScan.update({
      where: { id: scan.id },
      data: { status: 'APPLIED', appliedCount: applied, detections: detections as unknown as Prisma.InputJsonValue },
    });
  }

  async reject(userId: string, id: string) {
    const scan = await this.getScan(userId, id);
    return this.prisma.ocrScan.update({ where: { id: scan.id }, data: { status: 'REJECTED' } });
  }

  /**
   * Apply detections to progression. Never overwrites a higher existing value
   * with a lower one unless `explicit` is true (user confirmed).
   */
  async applyDetections(userId: string, detections: Detection[], explicit: boolean): Promise<number> {
    let applied = 0;

    for (const d of detections) {
      if (d.kind === 'WEAPON_LEVEL' && d.weaponId && d.level != null) {
        const weapon = await this.prisma.weapon.findUnique({ where: { id: d.weaponId } });
        if (!weapon) continue;
        const existing = await this.prisma.weaponProgress.findUnique({ where: { userId_weaponId: { userId, weaponId: d.weaponId } } });
        const newLevel = Math.min(weapon.maxLevel, d.level);
        if (existing && existing.level > newLevel && !explicit) continue; // don't regress
        await this.prisma.weaponProgress.upsert({
          where: { userId_weaponId: { userId, weaponId: d.weaponId } },
          create: { userId, weaponId: d.weaponId, level: newLevel, source: 'OCR' },
          update: { level: newLevel, source: 'OCR' },
        });
        if (existing && newLevel > existing.level) {
          await this.activity.recordWeaponLevelUp(userId, weapon.name, newLevel);
        }
        applied += 1;
        continue;
      }

      if (d.kind === 'CAMO_PROGRESS' && d.weaponId && d.requirementType && d.currentValue != null) {
        // Find the matching camo challenge for this weapon + requirement.
        const challenge = await this.prisma.camoChallenge.findFirst({
          where: { weaponId: d.weaponId, requirementType: d.requirementType, ...(d.camoId ? { camoId: d.camoId } : {}) },
          include: { weapon: true },
        });
        if (!challenge) continue;
        const existing = await this.prisma.camoProgress.findUnique({
          where: { userId_camoChallengeId: { userId, camoChallengeId: challenge.id } },
        });
        const target = existing?.targetValue ?? challenge.targetValue;
        const incoming = Math.min(d.currentValue, d.targetValue ?? target);
        if (existing && existing.currentValue > incoming && !explicit) continue; // don't regress
        const completed = incoming >= target;
        await this.prisma.camoProgress.upsert({
          where: { userId_camoChallengeId: { userId, camoChallengeId: challenge.id } },
          create: { userId, camoChallengeId: challenge.id, currentValue: incoming, targetValue: target, completed, source: 'OCR' },
          update: { currentValue: incoming, completed, source: 'OCR' },
        });
        await this.activity.recordCamoProgress(
          userId,
          challenge.weapon.name,
          challenge.requirementType,
          existing?.currentValue ?? 0,
          incoming,
          target,
        );
        applied += 1;
      }
    }

    if (applied > 0) {
      await this.objectives.recompute(userId);
    }
    return applied;
  }
}
