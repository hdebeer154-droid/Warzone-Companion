import sharp from 'sharp';

export type DetectionKind = 'WEAPON_LEVEL' | 'CAMO_PROGRESS' | 'EVENT_PROGRESS' | 'CALLING_CARD_PROGRESS' | 'PLAYER_LEVEL';

export interface ParseContext {
  weapons: { id: string; name: string; slug: string; category: string }[];
  camos: { id: string; name: string }[];
}

export interface Detection {
  kind: DetectionKind;
  rawText: string;
  weaponId?: string;
  weaponName?: string;
  camoId?: string;
  camoName?: string;
  requirementType?: string;
  currentValue?: number;
  targetValue?: number;
  level?: number;
  confidence: number;
  matched: boolean;
}

const REQUIREMENT_KEYWORDS: Record<string, string[]> = {
  HEADSHOTS: ['headshot', 'head shot', 'head-shot'],
  LONGSHOTS: ['longshot', 'long shot', 'long-shot'],
  KILLS: ['kills', 'kill'],
  POINT_BLANK: ['point blank', 'pointblank'],
  MOUNTED_KILLS: ['mounted'],
  HIPFIRE: ['hipfire', 'hip fire'],
  DOUBLE_KILLS: ['double kill'],
  TRIPLE_KILLS: ['triple kill'],
  REVENGE_KILLS: ['revenge'],
  SLIDING_KILLS: ['sliding'],
  CROUCHING_KILLS: ['crouch'],
  ADS_KILLS: ['ads'],
  NO_ATTACHMENT_KILLS: ['no attachment'],
  MELEE_KILLS: ['melee'],
};

/** Image preprocessing: normalise size/contrast to improve OCR accuracy. */
export async function preprocessImage(input: Buffer): Promise<Buffer> {
  return sharp(input)
    .resize({ width: 1600, withoutEnlargement: true })
    .grayscale()
    .normalize()
    .sharpen()
    .png()
    .toBuffer();
}

function findRequirement(line: string): string | undefined {
  const l = line.toLowerCase();
  for (const [type, words] of Object.entries(REQUIREMENT_KEYWORDS)) {
    if (words.some((w) => l.includes(w))) return type;
  }
  return undefined;
}

function findWeapon(line: string, ctx: ParseContext) {
  const l = line.toLowerCase();
  // Prefer the longest matching weapon name to avoid partial collisions.
  let best: { id: string; name: string } | undefined;
  for (const w of ctx.weapons) {
    if (l.includes(w.name.toLowerCase())) {
      if (!best || w.name.length > best.name.length) best = { id: w.id, name: w.name };
    }
  }
  return best;
}

function findCamo(line: string, ctx: ParseContext) {
  const l = line.toLowerCase();
  let best: { id: string; name: string } | undefined;
  for (const c of ctx.camos) {
    if (c.name.length >= 3 && l.includes(c.name.toLowerCase())) {
      if (!best || c.name.length > best.name.length) best = { id: c.id, name: c.name };
    }
  }
  return best;
}

/**
 * Parse OCR text into structured detections. Pure + deterministic so it can be
 * unit-tested independently of the OCR engine.
 */
export function parseDetections(rawText: string, ctx: ParseContext): Detection[] {
  const detections: Detection[] = [];
  const lines = rawText
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);

  let currentWeapon: { id: string; name: string } | undefined;

  for (const line of lines) {
    const weapon = findWeapon(line, ctx);
    if (weapon) currentWeapon = weapon;

    const progress = /(\d{1,4})\s*\/\s*(\d{1,4})/.exec(line);
    const levelMatch = /(?:level|lvl?\.?)\s*(\d{1,3})/i.exec(line);
    const req = findRequirement(line);
    const camo = findCamo(line, ctx);

    if (progress) {
      const currentValue = parseInt(progress[1], 10);
      const targetValue = parseInt(progress[2], 10);
      let confidence = 0.55;
      if (weapon) confidence += 0.25;
      else if (currentWeapon) confidence += 0.12;
      if (req) confidence += 0.15;
      if (currentValue <= targetValue && targetValue > 0) confidence += 0.05;
      detections.push({
        kind: camo ? 'CAMO_PROGRESS' : 'CAMO_PROGRESS',
        rawText: line,
        weaponId: weapon?.id ?? currentWeapon?.id,
        weaponName: weapon?.name ?? currentWeapon?.name,
        camoId: camo?.id,
        camoName: camo?.name,
        requirementType: req,
        currentValue,
        targetValue,
        confidence: Math.min(0.99, confidence),
        matched: !!(weapon || currentWeapon) && !!req,
      });
      continue;
    }

    if (levelMatch && (weapon || currentWeapon)) {
      let confidence = 0.6;
      if (weapon) confidence += 0.25;
      detections.push({
        kind: 'WEAPON_LEVEL',
        rawText: line,
        weaponId: weapon?.id ?? currentWeapon?.id,
        weaponName: weapon?.name ?? currentWeapon?.name,
        level: parseInt(levelMatch[1], 10),
        confidence: Math.min(0.99, confidence),
        matched: true,
      });
    }
  }

  return detections;
}
