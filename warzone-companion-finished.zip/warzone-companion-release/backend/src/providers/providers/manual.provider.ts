import { Injectable } from '@nestjs/common';
import {
  GameDataProvider,
  GetMatchesOptions,
  ProviderChallengeProgress,
  ProviderIdentity,
  ProviderMatch,
  ProviderProfile,
  ProviderProgression,
  ProviderRef,
  ProviderResult,
  ProviderWeaponStat,
} from '../provider.interface';

/**
 * Manual provider — represents user-entered data.
 *
 * It performs no external calls. Progress is written directly by the user via
 * the API/UI. It exists so the sync engine treats "manual" as a first-class,
 * always-available source that never fails and never erases data.
 */
@Injectable()
export class ManualProvider implements GameDataProvider {
  readonly key = 'manual';
  readonly name = 'Manual Entry';

  async isAvailable(): Promise<boolean> {
    return true;
  }

  async getIdentity(ref: ProviderRef): Promise<ProviderIdentity> {
    return { externalId: `manual-${ref.accountId}`, username: ref.platformUsername ?? 'Manual', platform: ref.platform ?? 'UNKNOWN' };
  }

  async getProfile(_ref: ProviderRef): Promise<ProviderResult<ProviderProfile>> {
    return {
      data: { level: 0, prestige: 0, xp: 0, totalMatches: 0, wins: 0, kills: 0, deaths: 0, assists: 0, damage: 0 },
      stale: true,
      fetchedAt: new Date(),
    };
  }

  async getMatches(_ref: ProviderRef, _opts?: GetMatchesOptions): Promise<ProviderResult<ProviderMatch[]>> {
    return { data: [], stale: true, fetchedAt: new Date() };
  }

  async getMatchDetails(): Promise<ProviderMatch> {
    throw new Error('Manual provider does not expose match details');
  }

  async getWeaponStats(_ref: ProviderRef): Promise<ProviderResult<ProviderWeaponStat[]>> {
    return { data: [], stale: true, fetchedAt: new Date() };
  }

  async getChallenges(_ref: ProviderRef): Promise<ProviderResult<ProviderChallengeProgress[]>> {
    return { data: [], stale: true, fetchedAt: new Date() };
  }

  async getProgression(_ref: ProviderRef): Promise<ProviderResult<ProviderProgression>> {
    return { data: { level: 0, prestige: 0, xp: 0, challenges: [] }, stale: true, fetchedAt: new Date() };
  }
}
