import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { Platform } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { ProviderRegistry } from '../providers/provider.registry';
import { AuditService } from '../audit/audit.service';

export interface LinkAccountDto {
  providerKey?: string;
  activisionUsername?: string;
  platform?: Platform;
  platformUsername?: string;
  platformAccountId?: string;
}

@Injectable()
export class AccountsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly registry: ProviderRegistry,
    private readonly audit: AuditService,
  ) {}

  async list(userId: string) {
    return this.prisma.codAccount.findMany({
      where: { userId },
      orderBy: { linkedAt: 'desc' },
    });
  }

  async get(userId: string, id: string) {
    const account = await this.prisma.codAccount.findFirst({ where: { id, userId } });
    if (!account) throw new NotFoundException('Account not found');
    return account;
  }

  /**
   * Link a COD account. We NEVER accept or store an Activision password.
   * Linking is metadata + provider selection only; authentication to any future
   * third-party source must happen server-side via an authorised flow.
   */
  async link(userId: string, dto: LinkAccountDto, ip?: string) {
    const providerKey = dto.providerKey ?? 'mock';
    if (!this.registry.has(providerKey)) {
      throw new BadRequestException(`Unknown provider '${providerKey}'`);
    }
    if (!dto.activisionUsername && !dto.platformUsername) {
      throw new BadRequestException('Provide an Activision username or platform username');
    }
    const account = await this.prisma.codAccount.create({
      data: {
        userId,
        providerKey,
        activisionUsername: dto.activisionUsername,
        platform: dto.platform ?? 'UNKNOWN',
        platformUsername: dto.platformUsername,
        platformAccountId: dto.platformAccountId,
        syncStatus: 'NEVER',
      },
    });
    await this.audit.log({ userId, action: 'account.link', entity: 'cod_account', entityId: account.id, metadata: { providerKey }, ip });
    return account;
  }

  async unlink(userId: string, id: string, ip?: string) {
    const account = await this.get(userId, id);
    await this.prisma.codAccount.delete({ where: { id: account.id } });
    await this.audit.log({ userId, action: 'account.unlink', entity: 'cod_account', entityId: id, ip });
    return { success: true };
  }

  /** Human-friendly sync status incl. "Last synchronized 37 minutes ago." */
  async syncStatus(userId: string) {
    const accounts = await this.prisma.codAccount.findMany({ where: { userId } });
    return accounts.map((a) => ({
      id: a.id,
      providerKey: a.providerKey,
      platform: a.platform,
      activisionUsername: a.activisionUsername,
      syncStatus: a.syncStatus,
      lastSyncAt: a.lastSyncAt,
      lastSyncHuman: this.humanize(a.lastSyncAt),
      syncError: a.syncError,
    }));
  }

  private humanize(date?: Date | null): string {
    if (!date) return 'Never synchronized';
    const diff = Date.now() - date.getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'Synchronized just now';
    if (mins < 60) return `Last synchronized ${mins} minute${mins === 1 ? '' : 's'} ago`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `Last synchronized ${hours} hour${hours === 1 ? '' : 's'} ago`;
    const days = Math.floor(hours / 24);
    return `Last synchronized ${days} day${days === 1 ? '' : 's'} ago`;
  }
}
