import { Injectable, Logger, OnModuleDestroy } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Redis from 'ioredis';

@Injectable()
export class RedisService implements OnModuleDestroy {
  private readonly logger = new Logger(RedisService.name);
  public readonly client: Redis;
  public readonly subscriber: Redis;

  constructor(private readonly config: ConfigService) {
    const host = this.config.get<string>('redis.host');
    const port = this.config.get<number>('redis.port');
    const opts = { host, port, maxRetriesPerRequest: null as unknown as number, lazyConnect: false };
    this.client = new Redis(opts);
    this.subscriber = new Redis(opts);
    this.client.on('error', (e) => this.logger.warn(`Redis error: ${e.message}`));
  }

  get connection() {
    return {
      host: this.config.get<string>('redis.host'),
      port: this.config.get<number>('redis.port'),
    };
  }

  async ping(): Promise<boolean> {
    try {
      const res = await this.client.ping();
      return res === 'PONG';
    } catch {
      return false;
    }
  }

  async get(key: string): Promise<string | null> {
    return this.client.get(key);
  }

  async set(key: string, value: string, ttlSeconds?: number): Promise<void> {
    if (ttlSeconds) await this.client.set(key, value, 'EX', ttlSeconds);
    else await this.client.set(key, value);
  }

  async del(key: string): Promise<void> {
    await this.client.del(key);
  }

  async getJson<T>(key: string): Promise<T | null> {
    const raw = await this.get(key);
    if (!raw) return null;
    try {
      return JSON.parse(raw) as T;
    } catch {
      return null;
    }
  }

  async setJson(key: string, value: unknown, ttlSeconds?: number): Promise<void> {
    await this.set(key, JSON.stringify(value), ttlSeconds);
  }

  /** Fixed-window rate limiter. Returns true when the action is allowed. */
  async rateLimit(bucket: string, limit: number, windowSeconds: number): Promise<boolean> {
    const key = `rl:${bucket}`;
    const count = await this.client.incr(key);
    if (count === 1) await this.client.expire(key, windowSeconds);
    return count <= limit;
  }

  async onModuleDestroy(): Promise<void> {
    await this.client.quit().catch(() => undefined);
    await this.subscriber.quit().catch(() => undefined);
  }
}
