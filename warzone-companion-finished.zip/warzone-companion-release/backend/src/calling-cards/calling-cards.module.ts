import { Module } from '@nestjs/common';
import { CallingCardsController } from './calling-cards.controller';
import { CallingCardsService } from './calling-cards.service';

@Module({
  controllers: [CallingCardsController],
  providers: [CallingCardsService],
  exports: [CallingCardsService],
})
export class CallingCardsModule {}
