import { Injectable } from '@nestjs/common';
import { ObjectiveType, Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { CatalogService } from '../catalog/catalog.service';

interface ObjectiveCandidate {
  type: ObjectiveType;
  targetId: string;
  weaponId?: string;
  weaponName?: string;
  label: string;
  current: number;
  target: number;
  remaining: number;
  priority: number;
  metadata?: Record<string, any>;
}

@Injectable()
export class ObjectivesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly catalog: CatalogService,
  ) {}

  /**
   * Recompute the user's automatic objectives from live progression data.
   * User-created CUSTOM objectives are never touched.
   */
  async recompute(userId: string) {
    const game = await this.catalog.getActiveGame();
    const candidates: ObjectiveCandidate[] = [];

    // ── Camo objectives (unfinished, nearest to completion) ──
    const camoChallenges = await this.prisma.camoChallenge.findMany({
      where: { weapon: { gameId: game.id, active: true } },
      include: {
        weapon: { select: { id: true, name: true } },
        progress: { where: { userId } },
      },
    });
    for (const c of camoChallenges) {
      const p = c.progress[0];
      const current = p?.currentValue ?? 0;
      const target = p?.targetValue ?? c.targetValue;
      if (current >= target) continue;
      const remaining = target - current;
      candidates.push({
        type: 'CAMO',
        targetId: c.id,
        weaponId: c.weapon.id,
        weaponName: c.weapon.name,
        label: `${c.weapon.name}: ${c.requirementType.replace(/_/g, ' ').toLowerCase()}`,
        current,
        target,
        remaining,
        // Nearer to completion => higher priority.
        priority: Math.max(0, 100 - remaining),
        metadata: { requirementType: c.requirementType, camoId: c.camoId },
      });
    }

    // ── Calling-card objectives ──
    const ccChallenges = await this.prisma.callingCardChallenge.findMany({
      where: { callingCard: { gameId: game.id } },
      include: { callingCard: { select: { id: true, name: true } }, progress: { where: { userId } } },
    });
    for (const c of ccChallenges) {
      const p = c.progress[0];
      const current = p?.currentValue ?? 0;
      if (current >= c.targetValue) continue;
      const remaining = c.targetValue - current;
      candidates.push({
        type: 'CALLING_CARD',
        targetId: c.id,
        label: `Calling card: ${c.callingCard.name} — ${c.requirementType.replace(/_/g, ' ').toLowerCase()}`,
        current,
        target: c.targetValue,
        remaining,
        priority: Math.max(0, 80 - remaining),
        metadata: { callingCardId: c.callingCardId },
      });
    }

    // ── Event objectives (time-pressured => boosted priority) ──
    const events = await this.prisma.event.findMany({
      where: { gameId: game.id, active: true },
      include: { challenges: { include: { progress: { where: { userId } } } } },
    });
    for (const e of events) {
      const endingSoon = e.endDate ? e.endDate.getTime() - Date.now() < 3 * 86400000 : false;
      for (const c of e.challenges) {
        const p = c.progress[0];
        const current = p?.currentValue ?? 0;
        if (current >= c.targetValue) continue;
        const remaining = c.targetValue - current;
        candidates.push({
          type: 'EVENT',
          targetId: c.id,
          label: `${e.name}: ${c.name}`,
          current,
          target: c.targetValue,
          remaining,
          priority: Math.max(0, 90 - remaining) + (endingSoon ? 30 : 0),
          metadata: { eventId: e.id, endingSoon, endDate: e.endDate },
        });
      }
    }

    // Persist: refresh automatic objectives, keep CUSTOM/COMPLETED.
    await this.prisma.userObjective.deleteMany({
      where: { userId, status: 'ACTIVE', objectiveType: { not: 'CUSTOM' } },
    });
    // Rank and keep the most relevant set.
    candidates.sort((a, b) => b.priority - a.priority);
    const top = candidates.slice(0, 60);
    if (top.length) {
      await this.prisma.userObjective.createMany({
        data: top.map((c) => ({
          userId,
          objectiveType: c.type,
          targetId: c.targetId,
          label: c.label,
          priority: Math.round(c.priority),
          status: 'ACTIVE' as const,
          metadata: { ...c.metadata, current: c.current, target: c.target, remaining: c.remaining, weaponId: c.weaponId, weaponName: c.weaponName } as Prisma.InputJsonValue,
        })),
      });
    }
    return { generated: top.length, total: candidates.length };
  }

  /** Active objectives with live remaining values, plus overlap analysis. */
  async list(userId: string, limit = 20) {
    let objectives = await this.prisma.userObjective.findMany({
      where: { userId, status: 'ACTIVE' },
      orderBy: [{ priority: 'desc' }, { createdAt: 'desc' }],
      take: limit,
    });
    if (objectives.length === 0) {
      await this.recompute(userId);
      objectives = await this.prisma.userObjective.findMany({
        where: { userId, status: 'ACTIVE' },
        orderBy: [{ priority: 'desc' }],
        take: limit,
      });
    }
    return {
      objectives: objectives.map((o) => {
        const meta = (o.metadata ?? {}) as Record<string, any>;
        return {
          id: o.id,
          type: o.objectiveType,
          label: o.label,
          priority: o.priority,
          status: o.status,
          weaponId: meta.weaponId ?? null,
          weaponName: meta.weaponName ?? null,
          current: meta.current ?? 0,
          target: meta.target ?? 0,
          remaining: meta.remaining ?? Math.max(0, (meta.target ?? 0) - (meta.current ?? 0)),
          progressPct: meta.target ? Math.min(100, Math.round(((meta.current ?? 0) / meta.target) * 100)) : 0,
          metadata: meta,
        };
      }),
    };
  }

  /**
   * Overlap analysis: which weapons simultaneously advance multiple objective
   * types (camo + event + calling card). This is the "optimise your grind" view.
   */
  async overlaps(userId: string) {
    const objectives = await this.prisma.userObjective.findMany({
      where: { userId, status: 'ACTIVE' },
    });
    const byWeapon = new Map<string, { weaponName: string; types: Set<string>; objectives: any[] }>();
    for (const o of objectives) {
      const meta = (o.metadata ?? {}) as Record<string, any>;
      const wid = meta.weaponId;
      if (!wid) continue;
      const cur = byWeapon.get(wid) ?? { weaponName: meta.weaponName ?? 'Weapon', types: new Set<string>(), objectives: [] as any[] };
      cur.types.add(o.objectiveType);
      cur.objectives.push({ id: o.id, type: o.objectiveType, label: o.label, remaining: meta.remaining ?? 0 });
      byWeapon.set(wid, cur);
    }
    return [...byWeapon.entries()]
      .filter(([, v]) => v.types.size >= 2)
      .map(([weaponId, v]) => ({
        weaponId,
        weaponName: v.weaponName,
        objectiveTypes: [...v.types],
        objectiveCount: v.objectives.length,
        objectives: v.objectives,
        // More overlapping types => stronger recommendation.
        score: v.types.size * 100 + v.objectives.length,
      }))
      .sort((a, b) => b.score - a.score);
  }

  async createCustom(userId: string, label: string, priority = 50) {
    return this.prisma.userObjective.create({
      data: { userId, objectiveType: 'CUSTOM', label, priority, status: 'ACTIVE' },
    });
  }

  async setStatus(userId: string, id: string, status: 'ACTIVE' | 'COMPLETED' | 'DISMISSED') {
    return this.prisma.userObjective.updateMany({
      where: { id, userId },
      data: { status, completedAt: status === 'COMPLETED' ? new Date() : null },
    });
  }
}
