import { Body, Controller, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { IsIn, IsInt, IsOptional, IsString, Max, Min } from 'class-validator';
import { Type } from 'class-transformer';
import { ObjectivesService } from './objectives.service';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';

class CreateObjectiveDto {
  @IsString() label!: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(0) @Max(100) priority?: number;
}

class UpdateObjectiveDto {
  @IsIn(['ACTIVE', 'COMPLETED', 'DISMISSED']) status!: 'ACTIVE' | 'COMPLETED' | 'DISMISSED';
}

@ApiTags('objectives')
@ApiBearerAuth()
@Controller('objectives')
export class ObjectivesController {
  constructor(private readonly objectives: ObjectivesService) {}

  @Get()
  list(@CurrentUser() user: AuthUser, @Query('limit') limit?: string) {
    return this.objectives.list(user.id, Number(limit ?? 20));
  }

  @Get('overlaps')
  overlaps(@CurrentUser() user: AuthUser) {
    return this.objectives.overlaps(user.id);
  }

  @Post('recompute')
  recompute(@CurrentUser() user: AuthUser) {
    return this.objectives.recompute(user.id);
  }

  @Post()
  create(@CurrentUser() user: AuthUser, @Body() dto: CreateObjectiveDto) {
    return this.objectives.createCustom(user.id, dto.label, dto.priority ?? 50);
  }

  @Patch(':id')
  update(@CurrentUser() user: AuthUser, @Param('id') id: string, @Body() dto: UpdateObjectiveDto) {
    return this.objectives.setStatus(user.id, id, dto.status);
  }
}
