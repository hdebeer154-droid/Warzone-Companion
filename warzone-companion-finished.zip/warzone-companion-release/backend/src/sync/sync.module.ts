import { Module } from '@nestjs/common';
import { SyncController } from './sync.controller';
import { SyncService } from './sync.service';
import { SyncWorker } from './sync.worker';
import { ObjectivesModule } from '../objectives/objectives.module';

@Module({
  imports: [ObjectivesModule],
  controllers: [SyncController],
  providers: [SyncService, SyncWorker],
  exports: [SyncService],
})
export class SyncModule {}
