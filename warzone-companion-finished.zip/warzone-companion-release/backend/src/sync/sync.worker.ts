import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { Job } from 'bullmq';
import { QueueService, QUEUES } from '../queue/queue.service';
import { SyncService } from './sync.service';

/**
 * Background worker for account synchronisation. Runs in-process for the
 * single-service deployment; in a scaled deployment this same class runs as a
 * dedicated worker process (BullMQ pulls jobs from Redis).
 */
@Injectable()
export class SyncWorker implements OnModuleInit {
  private readonly logger = new Logger(SyncWorker.name);

  constructor(
    private readonly queue: QueueService,
    private readonly sync: SyncService,
  ) {}

  onModuleInit(): void {
    this.queue.createWorker(QUEUES.SYNC, async (job: Job) => this.process(job), 2);
  }

  private async process(job: Job): Promise<unknown> {
    const { userId, accountId } = job.data as { userId: string; accountId?: string };
    this.logger.log(`Processing sync job ${job.id} for user ${userId}`);
    return this.sync.runForUser(userId, accountId);
  }
}
