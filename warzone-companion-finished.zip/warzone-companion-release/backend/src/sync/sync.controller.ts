import { Body, Controller, Get, Post, Query } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { IsBooleanString, IsOptional, IsString } from 'class-validator';
import { SyncService } from './sync.service';
import { QueueService, QUEUES } from '../queue/queue.service';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';

class TriggerSyncDto {
  @IsOptional() @IsString() accountId?: string;
  @IsOptional() @IsBooleanString() background?: string;
}

@ApiTags('sync')
@ApiBearerAuth()
@Controller('sync')
export class SyncController {
  constructor(
    private readonly sync: SyncService,
    private readonly queue: QueueService,
  ) {}

  @Post()
  async trigger(@CurrentUser() user: AuthUser, @Body() dto: TriggerSyncDto) {
    if (dto.background === 'true') {
      const job = await this.queue.addSync(user.id, dto.accountId, { reason: 'manual' });
      return { queued: true, jobId: job.id };
    }
    const results = await this.sync.runForUser(user.id, dto.accountId);
    return { queued: false, results };
  }

  @Get('runs')
  runs(@CurrentUser() user: AuthUser, @Query('limit') limit?: string) {
    return this.sync.listRuns(user.id, Number(limit ?? 20));
  }

  @Get('providers/health')
  health() {
    return this.sync.providerHealth();
  }

  @Get('queues')
  async queues() {
    return {
      sync: await this.queue.getCounts(QUEUES.SYNC),
      ocr: await this.queue.getCounts(QUEUES.OCR),
      notifications: await this.queue.getCounts(QUEUES.NOTIFICATIONS),
    };
  }
}
