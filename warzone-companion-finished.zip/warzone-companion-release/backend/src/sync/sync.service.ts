import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { RedisService } from '../redis/redis.service';
import { ProviderRegistry } from '../providers/provider.registry';
import { ProviderMatch, ProviderRef } from '../providers/provider.interface';
import { ActivityService } from '../activity/activity.service';
import { ObjectivesService } from '../objectives/objectives.service';
import { CatalogService } from '../catalog/catalog.service';

export interface SyncResult {
  accountId: string;
  providerKey: string;
  status: 'OK' | 'PARTIAL' | 'ERROR';
  changes: number;
  summary: Record<string, number>;
  error?: string;
  lastSyncAt?: Date;
}

@Injectable()
export class SyncService {
  private readonly logger = new Logger(SyncService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly redis: RedisService,
    private readonly registry: ProviderRegistry,
    private readonly activity: ActivityService,
    private readonly objectives: ObjectivesService,
    private readonly catalog: CatalogService,
  ) {}

  private healthKey(providerKey: string) {
    return `provider:health:${providerKey}`;
  }

  private async markProviderFailure(providerKey: string, error: string) {
    await this.redis.client.incr(`${this.healthKey(providerKey)}:failures`);
    await this.prisma.providerHealth.upsert({
      where: { providerKey },
      create: { providerKey, healthy: false, lastError: error, consecutiveFailures: 1 },
      update: { healthy: false, lastError: error, lastCheckedAt: new Date(), consecutiveFailures: { increment: 1 } },
    });
  }

  private async markProviderHealthy(providerKey: string, latencyMs: number) {
    await this.redis.client.del(`${this.healthKey(providerKey)}:failures`);
    await this.prisma.providerHealth.upsert({
      where: { providerKey },
      create: { providerKey, healthy: true, latencyMs, consecutiveFailures: 0 },
      update: { healthy: true, latencyMs, lastCheckedAt: new Date(), consecutiveFailures: 0, lastError: null },
    });
  }

  /** Sync every linked account for a user. */
  async runForUser(userId: string, onlyAccountId?: string): Promise<SyncResult[]> {
    const accounts = await this.prisma.codAccount.findMany({
      where: { userId, ...(onlyAccountId ? { id: onlyAccountId } : {}) },
    });
    const results: SyncResult[] = [];
    for (const account of accounts) {
      results.push(await this.syncAccount(userId, account.id));
    }
    return results;
  }

  /**
   * The 12-step synchronisation for a single account. Never destructive: on any
   * provider failure the existing data is preserved and only the status changes.
   */
  async syncAccount(userId: string, accountId: string): Promise<SyncResult> {
    const account = await this.prisma.codAccount.findFirst({ where: { id: accountId, userId } });
    if (!account) return { accountId, providerKey: 'unknown', status: 'ERROR', changes: 0, summary: {}, error: 'Account not found' };

    const providerKey = account.providerKey;
    const provider = this.registry.get(providerKey);
    const run = await this.prisma.syncRun.create({ data: { userId, accountId, providerKey, status: 'running' } });

    await this.prisma.codAccount.update({ where: { id: accountId }, data: { syncStatus: 'SYNCING' } });

    const ref: ProviderRef = {
      accountId,
      externalId: account.activisionUserId,
      platform: account.platform,
      platformUsername: account.platformUsername ?? account.activisionUsername,
      cursor: account.lastSyncCursor,
    };

    const summary: Record<string, number> = {};
    let changes = 0;

    try {
      // 1. Provider availability + rate limiting (avoid hammering upstreams).
      if (!(await provider.isAvailable())) throw new Error(`Provider '${providerKey}' is not available`);
      const allowed = await this.redis.rateLimit(`sync:${accountId}`, 30, 60);
      if (!allowed) throw new Error('Rate limit exceeded for this account; retry shortly');

      const started = Date.now();

      // 2. Identity.
      const identity = await provider.getIdentity(ref);
      // 3. Profile.
      const profileRes = await provider.getProfile(ref);
      // 4. Matches (incremental: only since last sync).
      const matchesRes = await provider.getMatches(ref, { since: account.lastSyncAt ?? undefined, limit: 20 });
      // 5. Weapon stats.
      const weaponRes = await provider.getWeaponStats(ref);
      // 6. Challenges.
      const challengeRes = await provider.getChallenges(ref);

      const latency = Date.now() - started;
      await this.markProviderHealthy(providerKey, latency);

      // 7-9. Normalise, diff, persist.
      const game = await this.catalog.getActiveGame();

      // Player profile (level/prestige/stats).
      const existingProfile = await this.prisma.playerProfile.findUnique({ where: { userId } });
      const p = profileRes.data;
      await this.prisma.playerProfile.upsert({
        where: { userId },
        create: {
          userId,
          codAccountId: accountId,
          level: p.level,
          prestige: p.prestige,
          xp: p.xp,
          totalMatches: p.totalMatches,
          wins: p.wins,
          kills: p.kills,
          deaths: p.deaths,
          assists: p.assists,
          damage: BigInt(p.damage),
        },
        update: {
          codAccountId: accountId,
          level: p.level,
          prestige: p.prestige,
          xp: p.xp,
          totalMatches: p.totalMatches,
          wins: p.wins,
          kills: p.kills,
          deaths: p.deaths,
          assists: p.assists,
          damage: BigInt(p.damage),
        },
      });
      if (existingProfile && p.level > existingProfile.level) {
        await this.activity.recordPlayerLevelUp(userId, existingProfile.level, p.level);
        changes += 1;
        summary.playerLevelUp = (summary.playerLevelUp ?? 0) + 1;
      }
      if (existingProfile && p.prestige > existingProfile.prestige) {
        await this.activity.recordPrestige(userId, p.prestige);
        changes += 1;
        summary.prestige = (summary.prestige ?? 0) + 1;
      }

      // Weapon progress.
      const weaponMap = new Map(
        (await this.prisma.weapon.findMany({ where: { gameId: game.id }, select: { id: true, slug: true, name: true } })).map((w) => [w.slug, w]),
      );
      for (const ws of weaponRes.data) {
        const weapon = weaponMap.get(ws.weaponSlug);
        if (!weapon) continue;
        const existing = await this.prisma.weaponProgress.findUnique({ where: { userId_weaponId: { userId, weaponId: weapon.id } } });
        await this.prisma.weaponProgress.upsert({
          where: { userId_weaponId: { userId, weaponId: weapon.id } },
          create: { userId, weaponId: weapon.id, level: ws.level, xp: ws.xp, kills: ws.kills, headshots: ws.headshots, matches: ws.matches, source: 'API' },
          update: { level: ws.level, xp: ws.xp, kills: ws.kills, headshots: ws.headshots, matches: ws.matches, source: 'API' },
        });
        if (existing && ws.level > existing.level) {
          await this.activity.recordWeaponLevelUp(userId, weapon.name, ws.level);
          changes += 1;
          summary.weaponLevelUp = (summary.weaponLevelUp ?? 0) + 1;
        }
      }

      // Matches (dedupe by externalMatchId; only insert new ones).
      const newMatches = await this.persistMatches(userId, game.id, matchesRes.data);
      changes += newMatches;
      summary.newMatches = newMatches;

      // Camo challenges.
      const camoChanges = await this.persistChallenges(userId, game.id, challengeRes.data);
      changes += camoChanges;
      summary.camoChanges = camoChanges;

      // 10. Activity summary.
      if (changes > 0) {
        await this.activity.recordSync(userId, `Synchronization complete — ${changes} change${changes === 1 ? '' : 's'} detected`, summary);
      }

      // 11. Objectives.
      await this.objectives.recompute(userId);

      // 12. Persist sync state.
      const now = new Date();
      await this.prisma.codAccount.update({
        where: { id: accountId },
        data: {
          syncStatus: 'OK',
          lastSyncAt: now,
          lastSyncCursor: matchesRes.cursor ?? account.lastSyncCursor,
          syncError: null,
          activisionUserId: account.activisionUserId ?? identity.externalId,
          activisionUsername: account.activisionUsername ?? identity.username,
        },
      });
      await this.prisma.syncRun.update({
        where: { id: run.id },
        data: { status: 'OK', finishedAt: now, changes, summary },
      });

      return { accountId, providerKey, status: 'OK', changes, summary, lastSyncAt: now };
    } catch (err) {
      const message = (err as Error).message;
      this.logger.warn(`Sync failed for account ${accountId}: ${message}`);
      await this.markProviderFailure(providerKey, message);
      // Non-destructive: keep all existing data, only reflect the failure.
      await this.prisma.codAccount.update({
        where: { id: accountId },
        data: { syncStatus: 'ERROR', syncError: message },
      });
      await this.prisma.syncRun.update({
        where: { id: run.id },
        data: { status: 'ERROR', finishedAt: new Date(), summary: { error: message } as any },
      });
      return { accountId, providerKey, status: 'ERROR', changes: 0, summary: {}, error: message };
    }
  }

  private async persistMatches(userId: string, gameId: string, matches: ProviderMatch[]): Promise<number> {
    let created = 0;
    for (const m of matches) {
      const existing = await this.prisma.match.findUnique({
        where: { userId_externalMatchId: { userId, externalMatchId: m.externalMatchId } },
      });
      if (existing) continue;
      const match = await this.prisma.match.create({
        data: {
          userId,
          gameId,
          externalMatchId: m.externalMatchId,
          mode: m.mode,
          map: m.map,
          playlist: m.playlist,
          startedAt: m.startedAt ? new Date(m.startedAt) : undefined,
          endedAt: m.endedAt ? new Date(m.endedAt) : undefined,
          kills: m.kills,
          deaths: m.deaths,
          assists: m.assists,
          placement: m.placement,
          damage: m.damage,
          xp: m.xp,
          rawData: (m.raw ?? m) as any,
        },
      });
      if (m.weapons?.length) {
        const slugs = m.weapons.map((w) => w.weaponSlug);
        const weapons = await this.prisma.weapon.findMany({ where: { gameId, slug: { in: slugs } }, select: { id: true, slug: true } });
        const bySlug = new Map(weapons.map((w) => [w.slug, w.id]));
        for (const ws of m.weapons) {
          const wid = bySlug.get(ws.weaponSlug);
          if (!wid) continue;
          await this.prisma.matchWeaponStat.create({
            data: { matchId: match.id, weaponId: wid, kills: ws.kills, headshots: ws.headshots, damage: ws.damage },
          });
        }
      }
      await this.activity.recordMatchCompleted(userId, {
        id: match.id,
        kills: match.kills,
        placement: match.placement,
        mode: match.mode,
        map: match.map,
      });
      created += 1;
    }
    return created;
  }

  private async persistChallenges(userId: string, gameId: string, challenges: { kind: string; key: string; currentValue: number; targetValue?: number }[]): Promise<number> {
    let changes = 0;
    const weapons = await this.prisma.weapon.findMany({ where: { gameId }, select: { id: true, slug: true, name: true } });
    const bySlug = new Map(weapons.map((w) => [w.slug, w]));
    for (const c of challenges) {
      if (c.kind !== 'CAMO') continue;
      const [slug, requirementRaw] = c.key.split(':');
      const weapon = bySlug.get(slug);
      if (!weapon) continue;
      const requirementType = (requirementRaw ?? '').toUpperCase();
      const challenge = await this.prisma.camoChallenge.findFirst({ where: { weaponId: weapon.id, requirementType } });
      if (!challenge) continue;
      const existing = await this.prisma.camoProgress.findUnique({
        where: { userId_camoChallengeId: { userId, camoChallengeId: challenge.id } },
      });
      const target = c.targetValue ?? challenge.targetValue;
      const completed = c.currentValue >= target;
      await this.prisma.camoProgress.upsert({
        where: { userId_camoChallengeId: { userId, camoChallengeId: challenge.id } },
        create: { userId, camoChallengeId: challenge.id, currentValue: c.currentValue, targetValue: target, completed, source: 'API' },
        update: { currentValue: c.currentValue, targetValue: target, completed, source: 'API' },
      });
      if (!existing || existing.currentValue !== c.currentValue) {
        await this.activity.recordCamoProgress(userId, weapon.name, requirementType, existing?.currentValue ?? 0, c.currentValue, target);
        changes += 1;
      }
    }
    return changes;
  }

  async listRuns(userId: string, limit = 20) {
    return this.prisma.syncRun.findMany({ where: { userId }, orderBy: { startedAt: 'desc' }, take: limit });
  }

  async providerHealth() {
    return this.prisma.providerHealth.findMany({ orderBy: { providerKey: 'asc' } });
  }
}
