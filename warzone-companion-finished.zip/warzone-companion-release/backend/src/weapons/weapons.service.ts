import { Injectable, NotFoundException } from '@nestjs/common';
import { Prisma, WeaponCategory } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { CatalogService } from '../catalog/catalog.service';
import { paginate } from '../common/dto/pagination.dto';
import { UpdateWeaponProgressDto, WeaponQueryDto } from './dto/weapons.dto';

export interface WeaponView {
  id: string;
  name: string;
  slug: string;
  category: WeaponCategory;
  imageUrl: string | null;
  maxLevel: number;
  isDlc: boolean;
  level: number;
  xp: number;
  xpIntoLevel: number;
  xpForNextLevel: number;
  xpToNextLevel: number;
  levelProgressPct: number;
  kills: number;
  headshots: number;
  matches: number;
  camoCompleted: number;
  camoTotal: number;
  camoCompletionPct: number;
  favourite: boolean;
  lastUpdatedAt: string | null;
}

@Injectable()
export class WeaponsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly catalog: CatalogService,
  ) {}

  /** Aggregate per-weapon completed camo challenge counts for a user. */
  private async camoCountsByWeapon(userId: string): Promise<Map<string, { completed: number }>> {
    const rows = await this.prisma.camoProgress.findMany({
      where: { userId },
      select: { completed: true, camoChallenge: { select: { weaponId: true } } },
    });
    const map = new Map<string, { completed: number }>();
    for (const r of rows) {
      const wid = r.camoChallenge.weaponId;
      const cur = map.get(wid) ?? { completed: 0 };
      if (r.completed) cur.completed += 1;
      map.set(wid, cur);
    }
    return map;
  }

  private async resolveGameId(gameId?: string): Promise<string> {
    if (gameId) return gameId;
    const game = await this.catalog.getActiveGame();
    return game.id;
  }

  private computeXp(levels: { level: number; xpRequired: number }[], level: number, xp: number) {
    const sorted = [...levels].sort((a, b) => a.level - b.level);
    const current = sorted.find((l) => l.level === level);
    const next = sorted.find((l) => l.level === level + 1);
    const base = current?.xpRequired ?? 0;
    const nextBase = next?.xpRequired ?? base;
    const span = Math.max(1, nextBase - base);
    const into = Math.max(0, xp - base);
    const toNext = Math.max(0, nextBase - xp);
    return {
      xpIntoLevel: into,
      xpForNextLevel: span,
      xpToNextLevel: next ? toNext : 0,
      levelProgressPct: next ? Math.min(100, Math.round((into / span) * 100)) : 100,
    };
  }

  async list(userId: string, q: WeaponQueryDto) {
    const gameId = await this.resolveGameId(q.gameId);
    const where: Prisma.WeaponWhereInput = {
      gameId,
      active: true,
      ...(q.category ? { category: q.category } : {}),
      ...(q.search ? { name: { contains: q.search, mode: 'insensitive' } } : {}),
    };

    const [weapons, camoCounts, favourites] = await Promise.all([
      this.prisma.weapon.findMany({
        where,
        include: {
          levels: { select: { level: true, xpRequired: true } },
          progress: { where: { userId } },
          _count: { select: { camoChallenges: true } },
        },
      }),
      this.camoCountsByWeapon(userId),
      this.prisma.weaponFavorite.findMany({ where: { userId }, select: { weaponId: true } }),
    ]);
    const favSet = new Set(favourites.map((f) => f.weaponId));

    let views: WeaponView[] = weapons.map((w) => {
      const p = w.progress[0];
      const level = p?.level ?? 1;
      const xp = p?.xp ?? 0;
      const xpInfo = this.computeXp(w.levels, level, xp);
      const camoCompleted = camoCounts.get(w.id)?.completed ?? 0;
      const camoTotal = w._count.camoChallenges;
      return {
        id: w.id,
        name: w.name,
        slug: w.slug,
        category: w.category,
        imageUrl: w.imageUrl,
        maxLevel: w.maxLevel,
        isDlc: w.isDlc,
        level,
        xp,
        ...xpInfo,
        kills: p?.kills ?? 0,
        headshots: p?.headshots ?? 0,
        matches: p?.matches ?? 0,
        camoCompleted,
        camoTotal,
        camoCompletionPct: camoTotal ? Math.round((camoCompleted / camoTotal) * 100) : 0,
        favourite: favSet.has(w.id),
        lastUpdatedAt: p?.updatedAt?.toISOString() ?? null,
      };
    });

    if (q.favouritesOnly === 'true') views = views.filter((v) => v.favourite);

    const dir = q.order === 'asc' ? 1 : -1;
    views.sort((a, b) => {
      switch (q.sort) {
        case 'completion':
          return (a.camoCompletionPct - b.camoCompletionPct) * dir;
        case 'recent':
          return ((a.lastUpdatedAt ?? '').localeCompare(b.lastUpdatedAt ?? '')) * dir;
        case 'favourite':
          return (Number(a.favourite) - Number(b.favourite)) * dir || b.level - a.level;
        case 'name':
          return a.name.localeCompare(b.name) * dir;
        case 'level':
        default:
          return (a.level - b.level) * dir;
      }
    });

    const total = views.length;
    const start = (q.page - 1) * q.pageSize;
    const items = views.slice(start, start + q.pageSize);
    return paginate(items, total, q.page, q.pageSize);
  }

  async categories(userId: string, gameId?: string) {
    const gid = await this.resolveGameId(gameId);
    const weapons = await this.prisma.weapon.findMany({
      where: { gameId: gid, active: true },
      select: { id: true, category: true, _count: { select: { camoChallenges: true } } },
    });
    const camoCounts = await this.camoCountsByWeapon(userId);
    const map = new Map<string, { total: number; completed: number; weapons: number }>();
    for (const w of weapons) {
      const cur = map.get(w.category) ?? { total: 0, completed: 0, weapons: 0 };
      cur.total += w._count.camoChallenges;
      cur.completed += camoCounts.get(w.id)?.completed ?? 0;
      cur.weapons += 1;
      map.set(w.category, cur);
    }
    return [...map.entries()].map(([category, v]) => ({
      category,
      weapons: v.weapons,
      camoCompleted: v.completed,
      camoTotal: v.total,
      completionPct: v.total ? Math.round((v.completed / v.total) * 100) : 0,
    }));
  }

  async detail(userId: string, idOrSlug: string) {
    const weapon = await this.prisma.weapon.findFirst({
      where: { OR: [{ id: this.isUuid(idOrSlug) ? idOrSlug : undefined }, { slug: idOrSlug }] },
      include: {
        levels: { orderBy: { level: 'asc' } },
        progress: { where: { userId } },
        favorites: { where: { userId } },
        camoChallenges: {
          include: {
            camo: { include: { camoSet: true } },
            progress: { where: { userId } },
          },
        },
      },
    });
    if (!weapon) throw new NotFoundException('Weapon not found');

    const p = weapon.progress[0];
    const level = p?.level ?? 1;
    const xp = p?.xp ?? 0;
    const xpInfo = this.computeXp(weapon.levels, level, xp);

    const camoChallenges = weapon.camoChallenges.map((c) => {
      const prog = c.progress[0];
      const current = prog?.currentValue ?? 0;
      const target = prog?.targetValue ?? c.targetValue;
      return {
        id: c.id,
        description: c.description,
        requirementType: c.requirementType,
        targetValue: target,
        gameMode: c.gameMode,
        camo: {
          id: c.camo.id,
          name: c.camo.name,
          imageUrl: c.camo.imageUrl,
          rarity: c.camo.rarity,
          set: c.camo.camoSet.name,
          setCategory: c.camo.camoSet.category,
        },
        currentValue: current,
        completed: prog?.completed ?? current >= target,
        source: prog?.source ?? 'CALCULATED',
        progressPct: target ? Math.min(100, Math.round((current / target) * 100)) : 0,
      };
    });

    const camoCompleted = camoChallenges.filter((c) => c.completed).length;

    return {
      id: weapon.id,
      name: weapon.name,
      slug: weapon.slug,
      category: weapon.category,
      imageUrl: weapon.imageUrl,
      maxLevel: weapon.maxLevel,
      isDlc: weapon.isDlc,
      level,
      xp,
      ...xpInfo,
      kills: p?.kills ?? 0,
      headshots: p?.headshots ?? 0,
      matches: p?.matches ?? 0,
      favourite: weapon.favorites.length > 0,
      camoCompleted,
      camoTotal: camoChallenges.length,
      camoCompletionPct: camoChallenges.length ? Math.round((camoCompleted / camoChallenges.length) * 100) : 0,
      levels: weapon.levels.map((l) => ({ level: l.level, xpRequired: l.xpRequired, unlockType: l.unlockType, unlockData: l.unlockData })),
      camoChallenges: camoChallenges.sort((a, b) => a.camo.set.localeCompare(b.camo.set) || a.camo.name.localeCompare(b.camo.name)),
    };
  }

  async toggleFavourite(userId: string, weaponId: string) {
    const existing = await this.prisma.weaponFavorite.findUnique({
      where: { userId_weaponId: { userId, weaponId } },
    });
    if (existing) {
      await this.prisma.weaponFavorite.delete({ where: { id: existing.id } });
      return { favourite: false };
    }
    await this.prisma.weaponFavorite.create({ data: { userId, weaponId } });
    return { favourite: true };
  }

  async updateProgress(userId: string, weaponId: string, dto: UpdateWeaponProgressDto) {
    const weapon = await this.prisma.weapon.findUnique({ where: { id: weaponId } });
    if (!weapon) throw new NotFoundException('Weapon not found');
    const data: Prisma.WeaponProgressUncheckedUpdateInput = {
      ...(dto.level !== undefined ? { level: Math.min(dto.level, weapon.maxLevel) } : {}),
      ...(dto.xp !== undefined ? { xp: dto.xp } : {}),
      ...(dto.kills !== undefined ? { kills: dto.kills } : {}),
      ...(dto.headshots !== undefined ? { headshots: dto.headshots } : {}),
      ...(dto.matches !== undefined ? { matches: dto.matches } : {}),
      source: 'MANUAL',
    };
    return this.prisma.weaponProgress.upsert({
      where: { userId_weaponId: { userId, weaponId } },
      create: {
        userId,
        weaponId,
        level: dto.level ?? 1,
        xp: dto.xp ?? 0,
        kills: dto.kills ?? 0,
        headshots: dto.headshots ?? 0,
        matches: dto.matches ?? 0,
        source: 'MANUAL',
      },
      update: data,
    });
  }

  private isUuid(v: string): boolean {
    return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
  }
}
