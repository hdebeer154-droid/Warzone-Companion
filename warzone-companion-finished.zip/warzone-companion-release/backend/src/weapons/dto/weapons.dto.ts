import { Type } from 'class-transformer';
import { IsBooleanString, IsEnum, IsIn, IsInt, IsOptional, IsString, Min } from 'class-validator';
import { WeaponCategory } from '@prisma/client';

export class WeaponQueryDto {
  @IsOptional() @IsString() search?: string;
  @IsOptional() @IsEnum(WeaponCategory) category?: WeaponCategory;
  @IsOptional() @IsString() gameId?: string;
  @IsOptional() @IsIn(['level', 'completion', 'recent', 'favourite', 'name']) sort: string = 'level';
  @IsOptional() @IsIn(['asc', 'desc']) order: 'asc' | 'desc' = 'desc';
  @IsOptional() @IsBooleanString() favouritesOnly?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) page: number = 1;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) pageSize: number = 50;
}

export class UpdateWeaponProgressDto {
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) level?: number;
  @IsOptional() @Type(() => Number) @IsInt() @Min(0) xp?: number;
  @IsOptional() @Type(() => Number) @IsInt() @Min(0) kills?: number;
  @IsOptional() @Type(() => Number) @IsInt() @Min(0) headshots?: number;
  @IsOptional() @Type(() => Number) @IsInt() @Min(0) matches?: number;
}
