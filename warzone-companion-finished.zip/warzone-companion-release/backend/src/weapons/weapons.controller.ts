import { Body, Controller, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { WeaponsService } from './weapons.service';
import { UpdateWeaponProgressDto, WeaponQueryDto } from './dto/weapons.dto';
import { CurrentUser, AuthUser } from '../common/decorators/current-user.decorator';

@ApiTags('weapons')
@ApiBearerAuth()
@Controller('weapons')
export class WeaponsController {
  constructor(private readonly weapons: WeaponsService) {}

  @Get()
  list(@CurrentUser() user: AuthUser, @Query() query: WeaponQueryDto) {
    return this.weapons.list(user.id, query);
  }

  @Get('categories')
  categories(@CurrentUser() user: AuthUser, @Query('gameId') gameId?: string) {
    return this.weapons.categories(user.id, gameId);
  }

  @Get(':id')
  detail(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    return this.weapons.detail(user.id, id);
  }

  @Post(':id/favourite')
  favourite(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    return this.weapons.toggleFavourite(user.id, id);
  }

  @Patch(':id/progress')
  updateProgress(@CurrentUser() user: AuthUser, @Param('id') id: string, @Body() dto: UpdateWeaponProgressDto) {
    return this.weapons.updateProgress(user.id, id, dto);
  }
}
