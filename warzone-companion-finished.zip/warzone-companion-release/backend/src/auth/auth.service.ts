import {
  BadRequestException,
  ConflictException,
  Injectable,
  Logger,
  UnauthorizedException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcryptjs';
import { createHash, randomBytes } from 'crypto';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { RedisService } from '../redis/redis.service';
import {
  ChangePasswordDto,
  LoginDto,
  RegisterDto,
  ResetPasswordDto,
  UpdateProfileDto,
} from './dto/auth.dto';

const BCRYPT_ROUNDS = 12;

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly jwt: JwtService,
    private readonly config: ConfigService,
    private readonly audit: AuditService,
    private readonly redis: RedisService,
  ) {}

  private hashToken(token: string): string {
    return createHash('sha256').update(token).digest('hex');
  }

  private async issueTokens(user: { id: string; email: string; username: string; role: string }, meta?: { userAgent?: string; ip?: string }) {
    const payload = { sub: user.id, email: user.email, username: user.username, role: user.role, typ: 'access' as const };
    const accessToken = await this.jwt.signAsync(payload, {
      secret: this.config.get<string>('jwt.accessSecret'),
      expiresIn: this.config.get<string>('jwt.accessTtl'),
    });

    const refreshToken = randomBytes(48).toString('hex');
    const ttl = this.config.get<string>('jwt.refreshTtl') ?? '30d';
    const expiresAt = new Date(Date.now() + this.parseTtlMs(ttl));

    await this.prisma.refreshToken.create({
      data: {
        userId: user.id,
        tokenHash: this.hashToken(refreshToken),
        userAgent: meta?.userAgent,
        ip: meta?.ip,
        expiresAt,
      },
    });

    return { accessToken, refreshToken, expiresAt, tokenType: 'Bearer' };
  }

  private parseTtlMs(ttl: string): number {
    const m = /^(\d+)([smhd])$/.exec(ttl.trim());
    if (!m) return 30 * 24 * 3600 * 1000;
    const value = parseInt(m[1], 10);
    const unit = m[2];
    const mult = unit === 's' ? 1000 : unit === 'm' ? 60000 : unit === 'h' ? 3600000 : 86400000;
    return value * mult;
  }

  async register(dto: RegisterDto, meta?: { userAgent?: string; ip?: string }) {
    const email = dto.email.toLowerCase().trim();
    const existing = await this.prisma.user.findFirst({
      where: { OR: [{ email }, { username: dto.username }] },
      select: { email: true, username: true },
    });
    if (existing) {
      throw new ConflictException(
        existing.email === email ? 'Email already registered' : 'Username already taken',
      );
    }

    const passwordHash = await bcrypt.hash(dto.password, BCRYPT_ROUNDS);
    const user = await this.prisma.user.create({
      data: {
        email,
        username: dto.username,
        displayName: dto.displayName?.trim() || dto.username,
        passwordHash,
        playerProfile: { create: {} },
        notificationPref: {
          create: [
            'CAMO_COMPLETED',
            'WEAPON_LEVEL',
            'EVENT_ENDING_SOON',
            'CHALLENGE_COMPLETED',
            'NEW_EVENT',
            'NEW_SEASON',
            'SYNC_FAILURE',
          ].map((category) => ({ category: category as any, enabled: true })),
        },
      },
    });

    const tokens = await this.issueTokens(user, meta);
    await this.audit.log({ userId: user.id, action: 'auth.register', entity: 'user', entityId: user.id, ip: meta?.ip });
    return { user: this.sanitize(user), ...tokens };
  }

  async login(dto: LoginDto, meta?: { userAgent?: string; ip?: string }) {
    const email = dto.email.toLowerCase().trim();
    const user = await this.prisma.user.findUnique({ where: { email } });
    // Constant-ish behaviour: always compare against a hash to reduce user enumeration timing.
    const hash = user?.passwordHash ?? '$2a$12$0000000000000000000000000000000000000000000000000000';
    const ok = await bcrypt.compare(dto.password, hash);
    if (!user || !ok) {
      throw new UnauthorizedException('Invalid email or password');
    }
    const tokens = await this.issueTokens(user, meta);
    await this.audit.log({ userId: user.id, action: 'auth.login', entity: 'user', entityId: user.id, ip: meta?.ip });
    return { user: this.sanitize(user), ...tokens };
  }

  async refresh(refreshToken: string, meta?: { userAgent?: string; ip?: string }) {
    const tokenHash = this.hashToken(refreshToken);
    const record = await this.prisma.refreshToken.findUnique({
      where: { tokenHash },
      include: { user: true },
    });
    if (!record || record.revokedAt || record.expiresAt < new Date()) {
      throw new UnauthorizedException('Invalid or expired refresh token');
    }
    // Rotate: revoke the old token and issue a fresh pair.
    await this.prisma.refreshToken.update({ where: { id: record.id }, data: { revokedAt: new Date() } });
    const tokens = await this.issueTokens(record.user, meta);
    return { user: this.sanitize(record.user), ...tokens };
  }

  async logout(refreshToken: string) {
    const tokenHash = this.hashToken(refreshToken);
    await this.prisma.refreshToken.updateMany({
      where: { tokenHash, revokedAt: null },
      data: { revokedAt: new Date() },
    });
    return { success: true };
  }

  async logoutAll(userId: string) {
    await this.prisma.refreshToken.updateMany({
      where: { userId, revokedAt: null },
      data: { revokedAt: new Date() },
    });
    return { success: true };
  }

  async forgotPassword(email: string) {
    const user = await this.prisma.user.findUnique({ where: { email: email.toLowerCase().trim() } });
    // Always respond success to avoid enumeration.
    if (!user) return { success: true };
    const token = randomBytes(32).toString('hex');
    await this.prisma.passwordResetToken.create({
      data: {
        userId: user.id,
        tokenHash: this.hashToken(token),
        expiresAt: new Date(Date.now() + 3600 * 1000),
      },
    });
    // In production this token is emailed. In dev we log it and cache it so it can be exercised.
    await this.redis.set(`pwdreset:${this.hashToken(token)}`, user.id, 3600);
    this.logger.warn(`Password reset token for ${email}: ${token}`);
    return { success: true, devToken: this.config.get('env') !== 'production' ? token : undefined };
  }

  async resetPassword(dto: ResetPasswordDto) {
    const tokenHash = this.hashToken(dto.token);
    const record = await this.prisma.passwordResetToken.findUnique({ where: { tokenHash } });
    if (!record || record.usedAt || record.expiresAt < new Date()) {
      throw new BadRequestException('Invalid or expired reset token');
    }
    const passwordHash = await bcrypt.hash(dto.password, BCRYPT_ROUNDS);
    await this.prisma.$transaction([
      this.prisma.user.update({ where: { id: record.userId }, data: { passwordHash } }),
      this.prisma.passwordResetToken.update({ where: { id: record.id }, data: { usedAt: new Date() } }),
      this.prisma.refreshToken.updateMany({
        where: { userId: record.userId, revokedAt: null },
        data: { revokedAt: new Date() },
      }),
    ]);
    await this.audit.log({ userId: record.userId, action: 'auth.password_reset', entity: 'user', entityId: record.userId });
    return { success: true };
  }

  async changePassword(userId: string, dto: ChangePasswordDto) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user) throw new UnauthorizedException();
    const ok = await bcrypt.compare(dto.currentPassword, user.passwordHash);
    if (!ok) throw new BadRequestException('Current password is incorrect');
    const passwordHash = await bcrypt.hash(dto.newPassword, BCRYPT_ROUNDS);
    await this.prisma.user.update({ where: { id: userId }, data: { passwordHash } });
    await this.audit.log({ userId, action: 'auth.password_change', entity: 'user', entityId: userId });
    return { success: true };
  }

  async me(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      include: { playerProfile: true, accounts: true },
    });
    if (!user) throw new UnauthorizedException();
    return this.sanitize(user);
  }

  async updateProfile(userId: string, dto: UpdateProfileDto) {
    const user = await this.prisma.user.update({
      where: { id: userId },
      data: { displayName: dto.displayName, avatarUrl: dto.avatarUrl },
    });
    return this.sanitize(user);
  }

  private sanitize(user: any) {
    const { passwordHash, ...rest } = user;
    return rest;
  }
}
