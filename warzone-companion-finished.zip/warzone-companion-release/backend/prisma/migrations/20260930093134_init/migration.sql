-- CreateEnum
CREATE TYPE "UserRole" AS ENUM ('USER', 'ADMIN');

-- CreateEnum
CREATE TYPE "Platform" AS ENUM ('ACTIVISION', 'BATTLENET', 'PSN', 'XBOX', 'STEAM', 'MOBILE', 'UNKNOWN');

-- CreateEnum
CREATE TYPE "SyncStatus" AS ENUM ('NEVER', 'PENDING', 'SYNCING', 'OK', 'PARTIAL', 'ERROR');

-- CreateEnum
CREATE TYPE "WeaponCategory" AS ENUM ('ASSAULT_RIFLE', 'SMG', 'SHOTGUN', 'LMG', 'MARKSMAN_RIFLE', 'SNIPER_RIFLE', 'PISTOL', 'LAUNCHER', 'MELEE', 'SPECIAL', 'OTHER');

-- CreateEnum
CREATE TYPE "CamoCategory" AS ENUM ('MILITARY', 'SPECIAL', 'GOLD', 'PLATINUM', 'DIAMOND', 'MASTERY', 'SEASONAL', 'EVENT', 'OTHER');

-- CreateEnum
CREATE TYPE "ProgressSource" AS ENUM ('API', 'OCR', 'MANUAL', 'CALCULATED');

-- CreateEnum
CREATE TYPE "ActivityType" AS ENUM ('MATCH_COMPLETED', 'WEAPON_LEVEL_UP', 'WEAPON_XP', 'CAMO_PROGRESS', 'CAMO_COMPLETED', 'CALLING_CARD_PROGRESS', 'CALLING_CARD_COMPLETED', 'EVENT_PROGRESS', 'EVENT_COMPLETED', 'PLAYER_LEVEL_UP', 'PRESTIGE', 'ACHIEVEMENT', 'SYNC');

-- CreateEnum
CREATE TYPE "ObjectiveType" AS ENUM ('CAMO', 'CALLING_CARD', 'EVENT', 'WEAPON_LEVEL', 'PLAYER_LEVEL', 'CUSTOM');

-- CreateEnum
CREATE TYPE "ObjectiveStatus" AS ENUM ('ACTIVE', 'COMPLETED', 'DISMISSED', 'EXPIRED');

-- CreateEnum
CREATE TYPE "OcrStatus" AS ENUM ('PENDING', 'PROCESSING', 'AWAITING_CONFIRMATION', 'APPLIED', 'REJECTED', 'FAILED');

-- CreateEnum
CREATE TYPE "NotificationCategory" AS ENUM ('CAMO_COMPLETED', 'WEAPON_LEVEL', 'EVENT_ENDING_SOON', 'CHALLENGE_COMPLETED', 'NEW_EVENT', 'NEW_SEASON', 'SYNC_FAILURE');

-- CreateTable
CREATE TABLE "users" (
    "id" UUID NOT NULL,
    "email" TEXT NOT NULL,
    "username" TEXT NOT NULL,
    "display_name" TEXT NOT NULL,
    "password_hash" TEXT NOT NULL,
    "avatar_url" TEXT,
    "role" "UserRole" NOT NULL DEFAULT 'USER',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "refresh_tokens" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "token_hash" TEXT NOT NULL,
    "user_agent" TEXT,
    "ip" TEXT,
    "expires_at" TIMESTAMP(3) NOT NULL,
    "revoked_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "refresh_tokens_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "password_reset_tokens" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "token_hash" TEXT NOT NULL,
    "expires_at" TIMESTAMP(3) NOT NULL,
    "used_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "password_reset_tokens_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "cod_accounts" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "activision_user_id" TEXT,
    "activision_username" TEXT,
    "platform" "Platform" NOT NULL DEFAULT 'UNKNOWN',
    "platform_username" TEXT,
    "platform_account_id" TEXT,
    "provider_key" TEXT NOT NULL DEFAULT 'mock',
    "linked_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "last_sync_at" TIMESTAMP(3),
    "last_sync_cursor" TEXT,
    "sync_status" "SyncStatus" NOT NULL DEFAULT 'NEVER',
    "sync_error" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "cod_accounts_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "player_profiles" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "cod_account_id" UUID,
    "level" INTEGER NOT NULL DEFAULT 1,
    "prestige" INTEGER NOT NULL DEFAULT 0,
    "xp" INTEGER NOT NULL DEFAULT 0,
    "total_matches" INTEGER NOT NULL DEFAULT 0,
    "wins" INTEGER NOT NULL DEFAULT 0,
    "kills" INTEGER NOT NULL DEFAULT 0,
    "deaths" INTEGER NOT NULL DEFAULT 0,
    "assists" INTEGER NOT NULL DEFAULT 0,
    "damage" BIGINT NOT NULL DEFAULT 0,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "player_profiles_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "games" (
    "id" UUID NOT NULL,
    "slug" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "version" TEXT,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "release_date" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "games_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "seasons" (
    "id" UUID NOT NULL,
    "game_id" UUID NOT NULL,
    "season_number" INTEGER NOT NULL,
    "name" TEXT NOT NULL,
    "start_date" TIMESTAMP(3),
    "end_date" TIMESTAMP(3),
    "active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "seasons_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "weapons" (
    "id" UUID NOT NULL,
    "game_id" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "category" "WeaponCategory" NOT NULL,
    "image_url" TEXT,
    "max_level" INTEGER NOT NULL DEFAULT 55,
    "dlc" BOOLEAN NOT NULL DEFAULT false,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "order_index" INTEGER NOT NULL DEFAULT 0,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "weapons_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "weapon_levels" (
    "id" UUID NOT NULL,
    "weapon_id" UUID NOT NULL,
    "level" INTEGER NOT NULL,
    "xp_required" INTEGER NOT NULL,
    "unlock_type" TEXT,
    "unlock_data" JSONB,

    CONSTRAINT "weapon_levels_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "weapon_progress" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "weapon_id" UUID NOT NULL,
    "level" INTEGER NOT NULL DEFAULT 1,
    "xp" INTEGER NOT NULL DEFAULT 0,
    "kills" INTEGER NOT NULL DEFAULT 0,
    "headshots" INTEGER NOT NULL DEFAULT 0,
    "matches" INTEGER NOT NULL DEFAULT 0,
    "source" "ProgressSource" NOT NULL DEFAULT 'MANUAL',
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "weapon_progress_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "weapon_favorites" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "weapon_id" UUID NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "weapon_favorites_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "camo_sets" (
    "id" UUID NOT NULL,
    "game_id" UUID NOT NULL,
    "season_id" UUID,
    "name" TEXT NOT NULL,
    "category" "CamoCategory" NOT NULL,
    "order_index" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "camo_sets_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "camos" (
    "id" UUID NOT NULL,
    "camo_set_id" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "image_url" TEXT,
    "rarity" TEXT,
    "order_index" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "camos_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "camo_challenges" (
    "id" UUID NOT NULL,
    "camo_id" UUID NOT NULL,
    "weapon_id" UUID NOT NULL,
    "description" TEXT NOT NULL,
    "requirement_type" TEXT NOT NULL,
    "target_value" INTEGER NOT NULL,
    "game_mode" TEXT,
    "metadata" JSONB,

    CONSTRAINT "camo_challenges_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "camo_progress" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "camo_challenge_id" UUID NOT NULL,
    "current_value" INTEGER NOT NULL DEFAULT 0,
    "target_value" INTEGER NOT NULL,
    "completed" BOOLEAN NOT NULL DEFAULT false,
    "source" "ProgressSource" NOT NULL DEFAULT 'MANUAL',
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "camo_progress_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "calling_cards" (
    "id" UUID NOT NULL,
    "game_id" UUID NOT NULL,
    "season_id" UUID,
    "name" TEXT NOT NULL,
    "category" TEXT,
    "description" TEXT,
    "image_url" TEXT,

    CONSTRAINT "calling_cards_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "calling_card_challenges" (
    "id" UUID NOT NULL,
    "calling_card_id" UUID NOT NULL,
    "description" TEXT NOT NULL,
    "requirement_type" TEXT NOT NULL,
    "target_value" INTEGER NOT NULL,

    CONSTRAINT "calling_card_challenges_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "calling_card_progress" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "challenge_id" UUID NOT NULL,
    "current_value" INTEGER NOT NULL DEFAULT 0,
    "completed" BOOLEAN NOT NULL DEFAULT false,
    "source" "ProgressSource" NOT NULL DEFAULT 'MANUAL',
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "calling_card_progress_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "events" (
    "id" UUID NOT NULL,
    "game_id" UUID NOT NULL,
    "season_id" UUID,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "start_date" TIMESTAMP(3),
    "end_date" TIMESTAMP(3),
    "image_url" TEXT,
    "active" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "events_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "event_rewards" (
    "id" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "image_url" TEXT,
    "reward_type" TEXT,

    CONSTRAINT "event_rewards_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "event_challenges" (
    "id" UUID NOT NULL,
    "event_id" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "requirement_type" TEXT NOT NULL,
    "target_value" INTEGER NOT NULL,
    "reward_id" UUID,

    CONSTRAINT "event_challenges_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "event_progress" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "event_challenge_id" UUID NOT NULL,
    "current_value" INTEGER NOT NULL DEFAULT 0,
    "completed" BOOLEAN NOT NULL DEFAULT false,
    "source" "ProgressSource" NOT NULL DEFAULT 'MANUAL',
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "event_progress_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "matches" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "game_id" UUID NOT NULL,
    "external_match_id" TEXT,
    "mode" TEXT,
    "map" TEXT,
    "playlist" TEXT,
    "started_at" TIMESTAMP(3),
    "ended_at" TIMESTAMP(3),
    "kills" INTEGER NOT NULL DEFAULT 0,
    "deaths" INTEGER NOT NULL DEFAULT 0,
    "assists" INTEGER NOT NULL DEFAULT 0,
    "placement" INTEGER,
    "damage" INTEGER NOT NULL DEFAULT 0,
    "xp" INTEGER NOT NULL DEFAULT 0,
    "raw_data" JSONB,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "matches_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "match_weapon_stats" (
    "id" UUID NOT NULL,
    "match_id" UUID NOT NULL,
    "weapon_id" UUID NOT NULL,
    "kills" INTEGER NOT NULL DEFAULT 0,
    "headshots" INTEGER NOT NULL DEFAULT 0,
    "damage" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "match_weapon_stats_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "activity_events" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "type" "ActivityType" NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "metadata" JSONB,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "read_at" TIMESTAMP(3),

    CONSTRAINT "activity_events_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "user_objectives" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "objective_type" "ObjectiveType" NOT NULL,
    "target_id" TEXT,
    "label" TEXT,
    "priority" INTEGER NOT NULL DEFAULT 0,
    "status" "ObjectiveStatus" NOT NULL DEFAULT 'ACTIVE',
    "metadata" JSONB,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "completed_at" TIMESTAMP(3),

    CONSTRAINT "user_objectives_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ocr_scans" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "image_url" TEXT,
    "status" "OcrStatus" NOT NULL DEFAULT 'PENDING',
    "raw_text" TEXT,
    "detections" JSONB,
    "applied_count" INTEGER NOT NULL DEFAULT 0,
    "error" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ocr_scans_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "notification_preferences" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "category" "NotificationCategory" NOT NULL,
    "enabled" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "notification_preferences_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "push_tokens" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "token" TEXT NOT NULL,
    "platform" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "push_tokens_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "provider_health" (
    "id" UUID NOT NULL,
    "provider_key" TEXT NOT NULL,
    "healthy" BOOLEAN NOT NULL DEFAULT true,
    "last_checked_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "last_error" TEXT,
    "latency_ms" INTEGER,
    "consecutive_failures" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "provider_health_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "sync_runs" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "account_id" UUID,
    "provider_key" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'running',
    "started_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "finished_at" TIMESTAMP(3),
    "changes" INTEGER NOT NULL DEFAULT 0,
    "summary" JSONB,

    CONSTRAINT "sync_runs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "audit_logs" (
    "id" UUID NOT NULL,
    "user_id" UUID,
    "action" TEXT NOT NULL,
    "entity" TEXT,
    "entity_id" TEXT,
    "metadata" JSONB,
    "ip" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "audit_logs_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "users_email_key" ON "users"("email");

-- CreateIndex
CREATE UNIQUE INDEX "users_username_key" ON "users"("username");

-- CreateIndex
CREATE UNIQUE INDEX "refresh_tokens_token_hash_key" ON "refresh_tokens"("token_hash");

-- CreateIndex
CREATE INDEX "refresh_tokens_user_id_idx" ON "refresh_tokens"("user_id");

-- CreateIndex
CREATE UNIQUE INDEX "password_reset_tokens_token_hash_key" ON "password_reset_tokens"("token_hash");

-- CreateIndex
CREATE INDEX "password_reset_tokens_user_id_idx" ON "password_reset_tokens"("user_id");

-- CreateIndex
CREATE INDEX "cod_accounts_user_id_idx" ON "cod_accounts"("user_id");

-- CreateIndex
CREATE UNIQUE INDEX "player_profiles_user_id_key" ON "player_profiles"("user_id");

-- CreateIndex
CREATE UNIQUE INDEX "player_profiles_cod_account_id_key" ON "player_profiles"("cod_account_id");

-- CreateIndex
CREATE UNIQUE INDEX "games_slug_key" ON "games"("slug");

-- CreateIndex
CREATE UNIQUE INDEX "seasons_game_id_season_number_key" ON "seasons"("game_id", "season_number");

-- CreateIndex
CREATE INDEX "weapons_category_idx" ON "weapons"("category");

-- CreateIndex
CREATE UNIQUE INDEX "weapons_game_id_slug_key" ON "weapons"("game_id", "slug");

-- CreateIndex
CREATE UNIQUE INDEX "weapon_levels_weapon_id_level_key" ON "weapon_levels"("weapon_id", "level");

-- CreateIndex
CREATE UNIQUE INDEX "weapon_progress_user_id_weapon_id_key" ON "weapon_progress"("user_id", "weapon_id");

-- CreateIndex
CREATE UNIQUE INDEX "weapon_favorites_user_id_weapon_id_key" ON "weapon_favorites"("user_id", "weapon_id");

-- CreateIndex
CREATE INDEX "camo_challenges_weapon_id_idx" ON "camo_challenges"("weapon_id");

-- CreateIndex
CREATE UNIQUE INDEX "camo_progress_user_id_camo_challenge_id_key" ON "camo_progress"("user_id", "camo_challenge_id");

-- CreateIndex
CREATE UNIQUE INDEX "calling_card_progress_user_id_challenge_id_key" ON "calling_card_progress"("user_id", "challenge_id");

-- CreateIndex
CREATE UNIQUE INDEX "event_progress_user_id_event_challenge_id_key" ON "event_progress"("user_id", "event_challenge_id");

-- CreateIndex
CREATE INDEX "matches_user_id_started_at_idx" ON "matches"("user_id", "started_at");

-- CreateIndex
CREATE UNIQUE INDEX "matches_user_id_external_match_id_key" ON "matches"("user_id", "external_match_id");

-- CreateIndex
CREATE INDEX "activity_events_user_id_created_at_idx" ON "activity_events"("user_id", "created_at");

-- CreateIndex
CREATE INDEX "user_objectives_user_id_status_idx" ON "user_objectives"("user_id", "status");

-- CreateIndex
CREATE INDEX "ocr_scans_user_id_idx" ON "ocr_scans"("user_id");

-- CreateIndex
CREATE UNIQUE INDEX "notification_preferences_user_id_category_key" ON "notification_preferences"("user_id", "category");

-- CreateIndex
CREATE UNIQUE INDEX "push_tokens_token_key" ON "push_tokens"("token");

-- CreateIndex
CREATE INDEX "push_tokens_user_id_idx" ON "push_tokens"("user_id");

-- CreateIndex
CREATE UNIQUE INDEX "provider_health_provider_key_key" ON "provider_health"("provider_key");

-- CreateIndex
CREATE INDEX "sync_runs_user_id_started_at_idx" ON "sync_runs"("user_id", "started_at");

-- CreateIndex
CREATE INDEX "audit_logs_user_id_created_at_idx" ON "audit_logs"("user_id", "created_at");

-- AddForeignKey
ALTER TABLE "refresh_tokens" ADD CONSTRAINT "refresh_tokens_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "password_reset_tokens" ADD CONSTRAINT "password_reset_tokens_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "cod_accounts" ADD CONSTRAINT "cod_accounts_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "player_profiles" ADD CONSTRAINT "player_profiles_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "player_profiles" ADD CONSTRAINT "player_profiles_cod_account_id_fkey" FOREIGN KEY ("cod_account_id") REFERENCES "cod_accounts"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "seasons" ADD CONSTRAINT "seasons_game_id_fkey" FOREIGN KEY ("game_id") REFERENCES "games"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "weapons" ADD CONSTRAINT "weapons_game_id_fkey" FOREIGN KEY ("game_id") REFERENCES "games"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "weapon_levels" ADD CONSTRAINT "weapon_levels_weapon_id_fkey" FOREIGN KEY ("weapon_id") REFERENCES "weapons"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "weapon_progress" ADD CONSTRAINT "weapon_progress_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "weapon_progress" ADD CONSTRAINT "weapon_progress_weapon_id_fkey" FOREIGN KEY ("weapon_id") REFERENCES "weapons"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "weapon_favorites" ADD CONSTRAINT "weapon_favorites_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "weapon_favorites" ADD CONSTRAINT "weapon_favorites_weapon_id_fkey" FOREIGN KEY ("weapon_id") REFERENCES "weapons"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "camo_sets" ADD CONSTRAINT "camo_sets_game_id_fkey" FOREIGN KEY ("game_id") REFERENCES "games"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "camo_sets" ADD CONSTRAINT "camo_sets_season_id_fkey" FOREIGN KEY ("season_id") REFERENCES "seasons"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "camos" ADD CONSTRAINT "camos_camo_set_id_fkey" FOREIGN KEY ("camo_set_id") REFERENCES "camo_sets"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "camo_challenges" ADD CONSTRAINT "camo_challenges_camo_id_fkey" FOREIGN KEY ("camo_id") REFERENCES "camos"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "camo_challenges" ADD CONSTRAINT "camo_challenges_weapon_id_fkey" FOREIGN KEY ("weapon_id") REFERENCES "weapons"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "camo_progress" ADD CONSTRAINT "camo_progress_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "camo_progress" ADD CONSTRAINT "camo_progress_camo_challenge_id_fkey" FOREIGN KEY ("camo_challenge_id") REFERENCES "camo_challenges"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "calling_cards" ADD CONSTRAINT "calling_cards_game_id_fkey" FOREIGN KEY ("game_id") REFERENCES "games"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "calling_cards" ADD CONSTRAINT "calling_cards_season_id_fkey" FOREIGN KEY ("season_id") REFERENCES "seasons"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "calling_card_challenges" ADD CONSTRAINT "calling_card_challenges_calling_card_id_fkey" FOREIGN KEY ("calling_card_id") REFERENCES "calling_cards"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "calling_card_progress" ADD CONSTRAINT "calling_card_progress_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "calling_card_progress" ADD CONSTRAINT "calling_card_progress_challenge_id_fkey" FOREIGN KEY ("challenge_id") REFERENCES "calling_card_challenges"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "events" ADD CONSTRAINT "events_game_id_fkey" FOREIGN KEY ("game_id") REFERENCES "games"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "events" ADD CONSTRAINT "events_season_id_fkey" FOREIGN KEY ("season_id") REFERENCES "seasons"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "event_challenges" ADD CONSTRAINT "event_challenges_event_id_fkey" FOREIGN KEY ("event_id") REFERENCES "events"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "event_challenges" ADD CONSTRAINT "event_challenges_reward_id_fkey" FOREIGN KEY ("reward_id") REFERENCES "event_rewards"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "event_progress" ADD CONSTRAINT "event_progress_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "event_progress" ADD CONSTRAINT "event_progress_event_challenge_id_fkey" FOREIGN KEY ("event_challenge_id") REFERENCES "event_challenges"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "matches" ADD CONSTRAINT "matches_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "matches" ADD CONSTRAINT "matches_game_id_fkey" FOREIGN KEY ("game_id") REFERENCES "games"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "match_weapon_stats" ADD CONSTRAINT "match_weapon_stats_match_id_fkey" FOREIGN KEY ("match_id") REFERENCES "matches"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "match_weapon_stats" ADD CONSTRAINT "match_weapon_stats_weapon_id_fkey" FOREIGN KEY ("weapon_id") REFERENCES "weapons"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "activity_events" ADD CONSTRAINT "activity_events_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_objectives" ADD CONSTRAINT "user_objectives_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ocr_scans" ADD CONSTRAINT "ocr_scans_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "notification_preferences" ADD CONSTRAINT "notification_preferences_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "audit_logs" ADD CONSTRAINT "audit_logs_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;
