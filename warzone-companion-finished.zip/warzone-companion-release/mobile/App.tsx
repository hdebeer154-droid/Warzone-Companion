import React, { useEffect, useRef } from 'react';
import { View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { QueryClientProvider } from '@tanstack/react-query';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { queryClient } from './src/lib/queryClient';
import { AuthProvider, useAuth } from './src/context/AuthContext';
import { RootNavigator } from './src/navigation/RootNavigator';
import {
  configureNotificationHandler,
  registerForPushNotifications,
} from './src/lib/notifications';
import { colors } from './src/theme';

// Configure the foreground notification handler once, as early as possible.
configureNotificationHandler();

/**
 * Registers the device for push notifications the first time the user becomes
 * authenticated. Kept inside the provider tree so it can read auth state.
 */
function PushRegistration() {
  const { status } = useAuth();
  const registered = useRef(false);

  useEffect(() => {
    if (status === 'authenticated' && !registered.current) {
      registered.current = true;
      // Best-effort: never blocks the UI.
      void registerForPushNotifications();
    }
    if (status === 'unauthenticated') {
      registered.current = false;
    }
  }, [status]);

  return null;
}

export default function App() {
  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <SafeAreaProvider>
        <QueryClientProvider client={queryClient}>
          <AuthProvider>
            <PushRegistration />
            <StatusBar style="light" />
            <RootNavigator />
          </AuthProvider>
        </QueryClientProvider>
      </SafeAreaProvider>
    </View>
  );
}
