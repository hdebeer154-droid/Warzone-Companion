import React, { useCallback, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { useQueryClient } from '@tanstack/react-query';

import { Screen } from '../components/Screen';
import { Card } from '../components/Card';
import { Button } from '../components/Button';
import { Badge } from '../components/Badge';
import { ProgressBar } from '../components/ProgressBar';
import { colors, fontSize, fontWeight, monoFont, radius, spacing } from '../theme';
import { ocrApi, type ImageUpload } from '../api/endpoints';
import { ApiError } from '../api/client';
import { requirementLabel } from '../lib/format';
import type { OcrDetection, OcrScanView } from '../api/types';

type Phase = 'idle' | 'uploading' | 'review' | 'applying' | 'done' | 'error';

export function ScannerScreen() {
  const qc = useQueryClient();
  const [phase, setPhase] = useState<Phase>('idle');
  const [scan, setScan] = useState<OcrScanView | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [previewUri, setPreviewUri] = useState<string | null>(null);
  const [accepted, setAccepted] = useState<Record<number, boolean>>({});

  const threshold = scan?.threshold ?? 0.95;

  const runScan = useCallback(
    async (image: ImageUpload) => {
      setPhase('uploading');
      setError(null);
      setScan(null);
      setPreviewUri(image.uri);
      try {
        const result = await ocrApi.scan(image);
        setScan(result);
        const dets = result.detections ?? [];
        const map: Record<number, boolean> = {};
        dets.forEach((d, i) => {
          map[i] = d.matched && d.confidence >= (result.threshold ?? 0.95);
        });
        setAccepted(map);
        setPhase(result.status === 'APPLIED' ? 'done' : 'review');
        if (result.status === 'APPLIED') qc.invalidateQueries();
      } catch (err) {
        setError(err instanceof ApiError ? err.message : 'Scan failed. Please try again.');
        setPhase('error');
      }
    },
    [qc],
  );

  const pickFromGallery = useCallback(async () => {
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) {
      setError('Photo library permission is required to scan a screenshot.');
      setPhase('error');
      return;
    }
    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      quality: 0.9,
    });
    if (res.canceled || !res.assets?.length) return;
    const asset = res.assets[0];
    await runScan({
      uri: asset.uri,
      name: asset.fileName ?? 'screenshot.png',
      type: asset.mimeType ?? 'image/png',
    });
  }, [runScan]);

  const takePhoto = useCallback(async () => {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) {
      setError('Camera permission is required to capture a screenshot.');
      setPhase('error');
      return;
    }
    const res = await ImagePicker.launchCameraAsync({ quality: 0.9 });
    if (res.canceled || !res.assets?.length) return;
    const asset = res.assets[0];
    await runScan({
      uri: asset.uri,
      name: asset.fileName ?? 'capture.png',
      type: asset.mimeType ?? 'image/png',
    });
  }, [runScan]);

  const applyConfirmed = useCallback(async () => {
    if (!scan) return;
    setPhase('applying');
    try {
      const dets = (scan.detections ?? []).filter((_, i) => accepted[i]);
      const result = await ocrApi.confirm(scan.id, dets);
      setScan(result);
      setPhase('done');
      qc.invalidateQueries();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not apply progress.');
      setPhase('error');
    }
  }, [scan, accepted, qc]);

  const rejectScan = useCallback(async () => {
    if (!scan) return;
    try {
      await ocrApi.reject(scan.id);
    } catch {
      // best effort
    }
    reset();
  }, [scan]);

  const reset = () => {
    setPhase('idle');
    setScan(null);
    setError(null);
    setPreviewUri(null);
    setAccepted({});
  };

  const detections = scan?.detections ?? [];
  const matchedCount = detections.filter((d) => d.matched).length;
  const acceptedCount = detections.filter((_, i) => accepted[i]).length;

  return (
    <Screen scroll contentStyle={styles.content}>
      {/* Intro */}
      <Card style={styles.intro}>
        <Text style={styles.introTitle}>Scan your progress</Text>
        <Text style={styles.introText}>
          Upload a screenshot of a weapon, camo or challenge screen. We read the text, match it to
          your account and propose updates. Nothing is applied without your confirmation.
        </Text>
      </Card>

      {phase === 'idle' ? (
        <View style={styles.actions}>
          <Pressable style={styles.primaryAction} onPress={takePhoto}>
            <View style={styles.actionIcon}>
              <Ionicons name="camera" size={26} color={colors.black} />
            </View>
            <View style={styles.actionText}>
              <Text style={styles.actionTitle}>TAKE SCREENSHOT</Text>
              <Text style={styles.actionSub}>Capture with your camera</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.black} />
          </Pressable>

          <Pressable style={styles.secondaryAction} onPress={pickFromGallery}>
            <View style={styles.actionIconAlt}>
              <Ionicons name="images" size={24} color={colors.primary} />
            </View>
            <View style={styles.actionText}>
              <Text style={styles.actionTitleAlt}>CHOOSE FROM GALLERY</Text>
              <Text style={styles.actionSubAlt}>Select an existing screenshot</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.textMuted} />
          </Pressable>
        </View>
      ) : null}

      {phase === 'uploading' ? (
        <Card style={styles.centerCard}>
          <ActivityIndicator color={colors.primary} size="large" />
          <Text style={styles.centerTitle}>Scanning screenshot…</Text>
          <Text style={styles.centerSub}>Preprocessing image and running OCR</Text>
        </Card>
      ) : null}

      {phase === 'error' ? (
        <Card style={styles.centerCard}>
          <Ionicons name="alert-circle" size={40} color={colors.danger} />
          <Text style={styles.centerTitle}>Scan failed</Text>
          <Text style={styles.centerSub}>{error}</Text>
          <Button label="Try again" variant="secondary" onPress={reset} style={styles.centerBtn} />
        </Card>
      ) : null}

      {(phase === 'review' || phase === 'applying' || phase === 'done') && scan ? (
        <>
          <View style={styles.resultHeader}>
            <View style={styles.resultCountWrap}>
              <Text style={styles.resultCount}>{matchedCount}</Text>
              <Text style={styles.resultCountLabel}>
                {matchedCount === 1 ? 'change found' : 'changes found'}
              </Text>
            </View>
            <Badge
              label={phase === 'done' ? 'Applied' : scan.status === 'AWAITING_CONFIRMATION' ? 'Needs review' : scan.status}
              color={phase === 'done' ? colors.success : colors.warning}
            />
          </View>

          {detections.length === 0 ? (
            <Card style={styles.centerCard}>
              <Ionicons name="search" size={36} color={colors.textMuted} />
              <Text style={styles.centerTitle}>Nothing recognised</Text>
              <Text style={styles.centerSub}>
                We couldn&apos;t find any progression in this screenshot. Try a clearer image.
              </Text>
            </Card>
          ) : (
            <Card padded={false} style={styles.listCard}>
              <View style={styles.listInner}>
                {detections.map((d, i) => (
                  <DetectionRow
                    key={`${d.kind}-${i}`}
                    detection={d}
                    threshold={threshold}
                    accepted={accepted[i] ?? false}
                    locked={phase !== 'review'}
                    onToggle={() => setAccepted((prev) => ({ ...prev, [i]: !prev[i] }))}
                  />
                ))}
              </View>
            </Card>
          )}

          {phase === 'done' ? (
            <View style={styles.doneBox}>
              <Ionicons name="checkmark-circle" size={22} color={colors.success} />
              <Text style={styles.doneText}>
                {scan.appliedCount > 0
                  ? `${scan.appliedCount} update${scan.appliedCount === 1 ? '' : 's'} applied to your progression.`
                  : 'No changes were applied.'}
              </Text>
            </View>
          ) : null}

          <View style={styles.footerActions}>
            {phase === 'review' ? (
              <>
                <Button
                  label={`UPDATE PROGRESS (${acceptedCount})`}
                  size="lg"
                  onPress={applyConfirmed}
                  disabled={acceptedCount === 0}
                  style={styles.flex}
                />
                <Button label="Discard" variant="ghost" size="lg" onPress={rejectScan} />
              </>
            ) : phase === 'applying' ? (
              <Button label="Applying…" size="lg" loading style={styles.flex} />
            ) : (
              <>
                <Button label="Scan another" variant="secondary" size="lg" onPress={reset} style={styles.flex} />
                <Button label="Done" size="lg" onPress={reset} />
              </>
            )}
          </View>
        </>
      ) : null}

      {/* Recent scans hint */}
      {phase === 'idle' ? (
        <Text style={styles.footnote}>
          Tip: crop the screenshot to just the progress panel for the most accurate results.
        </Text>
      ) : null}
    </Screen>
  );
}

function DetectionRow({
  detection,
  threshold,
  accepted,
  locked,
  onToggle,
}: {
  detection: OcrDetection;
  threshold: number;
  accepted: boolean;
  locked: boolean;
  onToggle: () => void;
}) {
  const high = detection.confidence >= threshold && detection.matched;
  const pct = Math.round(detection.confidence * 100);

  const title =
    detection.kind === 'WEAPON_LEVEL'
      ? `${detection.weaponName ?? 'Weapon'} → Level ${detection.level}`
      : detection.kind === 'CAMO_PROGRESS'
        ? `${detection.weaponName ?? 'Weapon'} · ${requirementLabel(detection.requirementType ?? '')}`
        : `${detection.kind.replace(/_/g, ' ')}`;

  const subtitle =
    detection.kind === 'CAMO_PROGRESS' && detection.currentValue != null
      ? `${detection.currentValue}${detection.targetValue != null ? `/${detection.targetValue}` : ''}`
      : detection.rawText;

  const progressPct =
    detection.kind === 'CAMO_PROGRESS' && detection.currentValue != null && detection.targetValue
      ? Math.min(100, Math.round((detection.currentValue / detection.targetValue) * 100))
      : high
        ? 100
        : 0;

  return (
    <Pressable onPress={locked ? undefined : onToggle} style={styles.detRow}>
      <View style={[styles.check, accepted ? styles.checkOn : styles.checkOff]}>
        {accepted ? <Ionicons name="checkmark" size={13} color={colors.black} /> : null}
      </View>
      <View style={styles.detBody}>
        <View style={styles.detTop}>
          <Text style={styles.detTitle} numberOfLines={2}>
            {title}
          </Text>
          <Badge
            label={`${pct}%`}
            color={high ? colors.success : pct >= 80 ? colors.warning : colors.danger}
          />
        </View>
        {subtitle ? (
          <Text style={styles.detSub} numberOfLines={1}>
            {subtitle}
          </Text>
        ) : null}
        <ProgressBar value={progressPct} color={high ? colors.success : colors.warning} height={4} />
        {!high ? (
          <Text style={styles.detWarn}>
            Low confidence — confirm manually before applying.
          </Text>
        ) : null}
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  content: { paddingBottom: spacing.huge, paddingTop: spacing.md },
  intro: { gap: spacing.sm },
  introTitle: { color: colors.text, fontSize: fontSize.subtitle, fontWeight: fontWeight.bold },
  introText: { color: colors.textSecondary, fontSize: fontSize.small, lineHeight: 19 },
  actions: { gap: spacing.md, marginTop: spacing.lg },
  primaryAction: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    backgroundColor: colors.primary,
    borderRadius: radius.lg,
    padding: spacing.lg,
  },
  secondaryAction: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.lg,
    padding: spacing.lg,
  },
  actionIcon: {
    width: 48,
    height: 48,
    borderRadius: radius.md,
    backgroundColor: 'rgba(0,0,0,0.18)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionIconAlt: {
    width: 48,
    height: 48,
    borderRadius: radius.md,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionText: { flex: 1 },
  actionTitle: { color: colors.black, fontSize: fontSize.bodyLg, fontWeight: fontWeight.heavy, letterSpacing: 0.8 },
  actionSub: { color: 'rgba(0,0,0,0.6)', fontSize: fontSize.small },
  actionTitleAlt: { color: colors.text, fontSize: fontSize.bodyLg, fontWeight: fontWeight.bold, letterSpacing: 0.8 },
  actionSubAlt: { color: colors.textMuted, fontSize: fontSize.small },
  centerCard: { alignItems: 'center', gap: spacing.sm, marginTop: spacing.lg, paddingVertical: spacing.xxl },
  centerTitle: { color: colors.text, fontSize: fontSize.subtitle, fontWeight: fontWeight.bold },
  centerSub: { color: colors.textMuted, fontSize: fontSize.small, textAlign: 'center', lineHeight: 19 },
  centerBtn: { marginTop: spacing.md, minWidth: 160 },
  resultHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: spacing.xl,
    marginBottom: spacing.md,
  },
  resultCountWrap: { flexDirection: 'row', alignItems: 'baseline', gap: spacing.sm },
  resultCount: { color: colors.primary, fontSize: fontSize.h1, fontWeight: fontWeight.heavy, fontFamily: monoFont },
  resultCountLabel: { color: colors.textSecondary, fontSize: fontSize.body },
  listCard: { padding: 0 },
  listInner: { paddingHorizontal: spacing.lg },
  detRow: {
    flexDirection: 'row',
    gap: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.divider,
  },
  check: {
    width: 22,
    height: 22,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 2,
  },
  checkOn: { backgroundColor: colors.success },
  checkOff: { borderWidth: 1.5, borderColor: colors.borderStrong },
  detBody: { flex: 1, gap: spacing.xs },
  detTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: spacing.sm },
  detTitle: { flex: 1, color: colors.text, fontSize: fontSize.body, fontWeight: fontWeight.semibold },
  detSub: { color: colors.textMuted, fontSize: fontSize.caption },
  detWarn: { color: colors.warning, fontSize: fontSize.micro, marginTop: 2 },
  doneBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    backgroundColor: colors.secondarySoft,
    borderRadius: radius.md,
    padding: spacing.lg,
    marginTop: spacing.lg,
  },
  doneText: { flex: 1, color: colors.text, fontSize: fontSize.body, fontWeight: fontWeight.semibold },
  footerActions: { flexDirection: 'row', gap: spacing.md, marginTop: spacing.xl },
  flex: { flex: 1 },
  footnote: {
    color: colors.textDim,
    fontSize: fontSize.caption,
    textAlign: 'center',
    marginTop: spacing.xl,
    lineHeight: 16,
  },
});
