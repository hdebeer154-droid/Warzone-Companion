import React, { useCallback } from 'react';
import { RefreshControl, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';

import { Screen } from '../components/Screen';
import { Card } from '../components/Card';
import { SectionHeader } from '../components/SectionHeader';
import { ProgressBar } from '../components/ProgressBar';
import { ChallengeRow } from '../components/ChallengeRow';
import { Badge } from '../components/Badge';
import { LoadingState, ErrorState } from '../components/StateViews';
import { useEvent } from '../hooks/queries';
import { colors, fontSize, fontWeight, monoFont, radius, spacing } from '../theme';
import { requirementLabel } from '../lib/format';
import type { RootStackParamList } from '../navigation/types';

type Props = NativeStackScreenProps<RootStackParamList, 'EventDetail'>;

export function EventDetailScreen({ route }: Props) {
  const { id } = route.params;
  const { data, isLoading, isError, error, refetch, isRefetching } = useEvent(id);

  const onRefresh = useCallback(() => refetch(), [refetch]);

  if (isLoading && !data) return <LoadingState label="Loading event…" />;
  if (isError && !data) {
    return (
      <ErrorState
        message={(error as Error)?.message ?? 'Unable to load event.'}
        onRetry={refetch}
      />
    );
  }
  if (!data) return null;

  const endingSoon = data.timeRemaining.endingSoon;
  const accent = colors.tierMastery;

  return (
    <Screen
      scroll
      contentStyle={styles.content}
      refreshControl={
        <RefreshControl refreshing={isRefetching} onRefresh={onRefresh} tintColor={colors.primary} />
      }
    >
      {/* Header */}
      <View style={styles.header}>
        <View style={[styles.emblem, endingSoon && styles.emblemEnding]}>
          <Ionicons name="sparkles" size={30} color={accent} />
        </View>
        <View style={styles.headerBody}>
          <Text style={styles.name}>{data.name}</Text>
          <View style={styles.badgeRow}>
            <Badge label={data.active ? 'Active' : 'Ended'} color={data.active ? colors.success : colors.textMuted} />
            {endingSoon ? <Badge label="Ending soon" color={colors.danger} /> : null}
          </View>
        </View>
      </View>

      {data.description ? <Text style={styles.description}>{data.description}</Text> : null}

      {/* Time remaining */}
      <Card style={styles.timeCard}>
        <View style={styles.timeRow}>
          <Ionicons name="time-outline" size={18} color={endingSoon ? colors.danger : colors.textSecondary} />
          <Text style={[styles.timeValue, endingSoon && { color: colors.danger }]}>
            {data.timeRemaining.human}
          </Text>
          <Text style={styles.timeLabel}>remaining</Text>
        </View>
        <Text style={styles.timeDates}>
          {formatDate(data.startDate)} — {formatDate(data.endDate)}
        </Text>
      </Card>

      {/* Completion */}
      <Card style={styles.progressCard}>
        <View style={styles.progressTop}>
          <Text style={styles.progressLabel}>EVENT COMPLETION</Text>
          <Text style={[styles.progressValue, { color: accent }]}>
            {data.completed}
            <Text style={styles.progressMax}>/{data.total}</Text>
          </Text>
        </View>
        <ProgressBar value={data.completionPct} color={accent} height={8} />
        <Text style={styles.progressFoot}>{data.completionPct}% complete</Text>
      </Card>

      {/* Challenges */}
      <SectionHeader title="Challenges" subtitle={`${data.completed}/${data.total} complete`} />
      <Card padded={false} style={styles.listCard}>
        <View style={styles.listInner}>
          {data.challenges.length === 0 ? (
            <Text style={styles.emptyText}>No challenges for this event.</Text>
          ) : (
            data.challenges.map((ch) => (
              <ChallengeRow
                key={ch.id}
                title={ch.name}
                subtitle={`${requirementLabel(ch.requirementType)}${ch.reward ? ` · Reward: ${ch.reward.name}` : ''}`}
                current={ch.currentValue}
                target={ch.targetValue}
                progressPct={ch.progressPct}
                completed={ch.completed}
                accent={accent}
                trailing={
                  ch.reward ? (
                    <View style={styles.rewardRow}>
                      <Ionicons name="gift-outline" size={13} color={colors.gold} />
                      <Text style={styles.rewardText}>{ch.reward.name}</Text>
                    </View>
                  ) : undefined
                }
              />
            ))
          )}
        </View>
      </Card>
    </Screen>
  );
}

function formatDate(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
}

const styles = StyleSheet.create({
  content: { paddingBottom: spacing.huge, paddingTop: spacing.md },
  header: { flexDirection: 'row', alignItems: 'center', gap: spacing.lg },
  emblem: {
    width: 64,
    height: 64,
    borderRadius: radius.lg,
    backgroundColor: 'rgba(199, 125, 255, 0.14)',
    borderWidth: 1,
    borderColor: colors.tierMastery,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emblemEnding: { borderColor: colors.danger, backgroundColor: 'rgba(255, 92, 92, 0.14)' },
  headerBody: { flex: 1, gap: spacing.xs },
  name: { color: colors.text, fontSize: fontSize.h2, fontWeight: fontWeight.heavy },
  badgeRow: { flexDirection: 'row', gap: spacing.sm, marginTop: spacing.xs },
  description: {
    color: colors.textSecondary,
    fontSize: fontSize.body,
    lineHeight: 20,
    marginTop: spacing.lg,
  },
  timeCard: { marginTop: spacing.lg, gap: spacing.xs },
  timeRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  timeValue: { color: colors.text, fontSize: fontSize.subtitle, fontWeight: fontWeight.heavy, fontFamily: monoFont },
  timeLabel: { color: colors.textMuted, fontSize: fontSize.body },
  timeDates: { color: colors.textMuted, fontSize: fontSize.caption },
  progressCard: { marginTop: spacing.md, gap: spacing.sm },
  progressTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline' },
  progressLabel: {
    color: colors.textMuted,
    fontSize: fontSize.micro,
    fontWeight: fontWeight.bold,
    letterSpacing: 1.2,
  },
  progressValue: { fontSize: fontSize.h2, fontWeight: fontWeight.heavy, fontFamily: monoFont },
  progressMax: { color: colors.textMuted, fontSize: fontSize.body },
  progressFoot: { color: colors.textMuted, fontSize: fontSize.caption },
  listCard: { padding: 0 },
  listInner: { paddingHorizontal: spacing.lg },
  emptyText: {
    color: colors.textMuted,
    fontSize: fontSize.body,
    paddingVertical: spacing.lg,
    textAlign: 'center',
  },
  rewardRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs, marginTop: spacing.xs },
  rewardText: { color: colors.gold, fontSize: fontSize.caption, fontWeight: fontWeight.semibold },
});
