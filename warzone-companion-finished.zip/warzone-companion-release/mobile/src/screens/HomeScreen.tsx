import React, { useCallback } from 'react';
import { Pressable, RefreshControl, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';

import { Screen } from '../components/Screen';
import { Card } from '../components/Card';
import { SectionHeader } from '../components/SectionHeader';
import { ProgressBar } from '../components/ProgressBar';
import { ObjectiveRow } from '../components/ObjectiveRow';
import { ActivityRow } from '../components/ActivityRow';
import { LoadingState, ErrorState } from '../components/StateViews';
import { useDashboard, useRunSync } from '../hooks/queries';
import { colors, fontSize, fontWeight, monoFont, radius, spacing } from '../theme';
import { progressColor } from '../lib/format';
import type { RootStackParamList } from '../navigation/types';

type Nav = NativeStackNavigationProp<RootStackParamList>;

export function HomeScreen() {
  const navigation = useNavigation<Nav>();
  const { data, isLoading, isError, error, refetch, isRefetching } = useDashboard();
  const runSync = useRunSync();

  const onRefresh = useCallback(() => {
    refetch();
  }, [refetch]);

  if (isLoading && !data) return <LoadingState label="Loading your dashboard…" />;
  if (isError && !data) {
    return <ErrorState message={(error as Error)?.message ?? 'Unable to load dashboard.'} onRetry={refetch} />;
  }
  if (!data) return null;

  const { header, nextObjectives, weaponCard, callingCard, event, recentActivity, sync } = data;
  const overallColor = progressColor(header.overallProgressionPct);

  return (
    <Screen
      scroll
      contentStyle={styles.content}
      refreshControl={
        <RefreshControl refreshing={isRefetching} onRefresh={onRefresh} tintColor={colors.primary} />
      }
    >
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerTop}>
          <View>
            <Text style={styles.appName}>WARZONE COMPANION</Text>
            <Text style={styles.operator}>{header.displayName}</Text>
          </View>
          <Pressable
            style={styles.syncPill}
            onPress={() => runSync.mutate(undefined)}
            disabled={runSync.isPending}
          >
            <Ionicons
              name={runSync.isPending ? 'sync' : 'sync-outline'}
              size={14}
              color={colors.primary}
            />
            <Text style={styles.syncPillText}>{runSync.isPending ? 'Syncing…' : 'Sync'}</Text>
          </Pressable>
        </View>

        <View style={styles.levelRow}>
          <View style={styles.levelBlock}>
            <Text style={styles.levelLabel}>PLAYER LEVEL</Text>
            <Text style={styles.levelValue}>{header.playerLevel}</Text>
          </View>
          <View style={styles.levelDivider} />
          <View style={styles.levelBlock}>
            <Text style={styles.levelLabel}>PRESTIGE</Text>
            <Text style={styles.levelValue}>{header.prestige}</Text>
          </View>
          <View style={styles.levelDivider} />
          <View style={[styles.levelBlock, styles.grow]}>
            <Text style={styles.levelLabel}>OVERALL PROGRESSION</Text>
            <View style={styles.overallRow}>
              <Text style={[styles.overallValue, { color: overallColor }]}>
                {header.overallProgressionPct}%
              </Text>
            </View>
            <ProgressBar value={header.overallProgressionPct} color={overallColor} height={5} />
          </View>
        </View>
      </View>

      {/* Scan progress CTA */}
      <Pressable style={styles.scanCta} onPress={() => navigation.navigate('Scanner')}>
        <Ionicons name="scan-outline" size={22} color={colors.black} />
        <View style={styles.scanCtaText}>
          <Text style={styles.scanCtaTitle}>SCAN PROGRESS</Text>
          <Text style={styles.scanCtaSub}>Upload a screenshot to update automatically</Text>
        </View>
        <Ionicons name="chevron-forward" size={20} color={colors.black} />
      </Pressable>

      {/* Next objectives */}
      <SectionHeader title="Next Objectives" />
      <Card padded={false} style={styles.listCard}>
        <View style={styles.listInner}>
          {nextObjectives.length === 0 ? (
            <Text style={styles.emptyText}>No active objectives. Nice work, operator.</Text>
          ) : (
            nextObjectives.map((o) => <ObjectiveRow key={o.id} objective={o} />)
          )}
        </View>
      </Card>

      {/* Weapon level */}
      {weaponCard ? (
        <>
          <SectionHeader title="Weapon Level" />
          <Card onPress={() => navigation.navigate('WeaponDetail', { weaponId: weaponCard.id })}>
            <View style={styles.weaponTop}>
              <Text style={styles.weaponName}>{weaponCard.name}</Text>
              <Text style={styles.weaponLevel}>
                {weaponCard.level} <Text style={styles.weaponArrow}>→</Text> {weaponCard.nextLevel}
              </Text>
            </View>
            <ProgressBar value={weaponCard.levelProgressPct} color={colors.secondary} height={6} />
            <View style={styles.weaponMeta}>
              <Text style={styles.weaponMetaText}>
                {weaponCard.xpToNextLevel.toLocaleString()} XP to next level
              </Text>
              <Text style={styles.weaponMetaText}>Camo {weaponCard.camoCompletionPct}%</Text>
            </View>
          </Card>
        </>
      ) : null}

      {/* Calling card + Event side by side */}
      <View style={styles.twoCol}>
        {callingCard ? (
          <Card
            style={styles.colCard}
            onPress={() => navigation.navigate('CallingCardDetail', { id: callingCard.id })}
          >
            <Text style={styles.colLabel}>CALLING CARD</Text>
            <Text style={styles.colTitle} numberOfLines={1}>
              {callingCard.name}
            </Text>
            <Text style={styles.colValue}>
              {callingCard.completed}
              <Text style={styles.colValueDim}>/{callingCard.total}</Text>
            </Text>
            <ProgressBar value={callingCard.completionPct} color={colors.info} height={5} />
          </Card>
        ) : null}

        {event ? (
          <Card
            style={styles.colCard}
            onPress={() => navigation.navigate('EventDetail', { id: event.id })}
          >
            <Text style={styles.colLabel}>EVENT</Text>
            <Text style={styles.colTitle} numberOfLines={1}>
              {event.name}
            </Text>
            <Text style={styles.colValue}>
              {event.completionPct}
              <Text style={styles.colValueDim}>%</Text>
            </Text>
            <ProgressBar value={event.completionPct} color={colors.tierMastery} height={5} />
            <Text style={[styles.colFoot, event.timeRemaining.endingSoon && { color: colors.danger }]}>
              {event.timeRemaining.human} left
            </Text>
          </Card>
        ) : null}
      </View>

      {/* Recent activity */}
      <SectionHeader title="Recent Activity" />
      <Card padded={false} style={styles.listCard}>
        <View style={styles.listInner}>
          {recentActivity.length === 0 ? (
            <Text style={styles.emptyText}>No recent activity yet.</Text>
          ) : (
            recentActivity.map((a) => <ActivityRow key={a.id} item={a} />)
          )}
        </View>
      </Card>

      {/* Sync footer */}
      <View style={styles.syncFooter}>
        <View style={[styles.dot, { backgroundColor: sync?.syncStatus === 'OK' ? colors.success : colors.warning }]} />
        <Text style={styles.syncFooterText}>
          {sync?.lastSyncHuman ?? 'Not synchronized yet'}
          {sync?.providerKey ? ` · via ${sync.providerKey}` : ''}
        </Text>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { paddingBottom: spacing.huge },
  header: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.lg,
    marginTop: spacing.md,
    gap: spacing.lg,
  },
  headerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  appName: {
    color: colors.textMuted,
    fontSize: fontSize.caption,
    fontWeight: fontWeight.bold,
    letterSpacing: 2.5,
  },
  operator: {
    color: colors.text,
    fontSize: fontSize.h1,
    fontWeight: fontWeight.heavy,
    letterSpacing: 1,
    marginTop: 2,
  },
  syncPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    backgroundColor: colors.primarySoft,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radius.pill,
  },
  syncPillText: {
    color: colors.primary,
    fontSize: fontSize.small,
    fontWeight: fontWeight.bold,
  },
  levelRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.lg },
  levelBlock: { gap: spacing.xs },
  grow: { flex: 1 },
  levelDivider: { width: 1, height: 34, backgroundColor: colors.border },
  levelLabel: {
    color: colors.textMuted,
    fontSize: fontSize.micro,
    fontWeight: fontWeight.bold,
    letterSpacing: 1.2,
  },
  levelValue: {
    color: colors.text,
    fontSize: fontSize.h2,
    fontWeight: fontWeight.heavy,
    fontFamily: monoFont,
  },
  overallRow: { flexDirection: 'row', justifyContent: 'flex-end' },
  overallValue: {
    fontSize: fontSize.h2,
    fontWeight: fontWeight.heavy,
    fontFamily: monoFont,
  },
  scanCta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    backgroundColor: colors.primary,
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginTop: spacing.lg,
  },
  scanCtaText: { flex: 1 },
  scanCtaTitle: {
    color: colors.black,
    fontSize: fontSize.bodyLg,
    fontWeight: fontWeight.heavy,
    letterSpacing: 1,
  },
  scanCtaSub: { color: 'rgba(0,0,0,0.65)', fontSize: fontSize.small, marginTop: 1 },
  listCard: { padding: 0 },
  listInner: { paddingHorizontal: spacing.lg },
  emptyText: {
    color: colors.textMuted,
    fontSize: fontSize.body,
    paddingVertical: spacing.lg,
    textAlign: 'center',
  },
  weaponTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  weaponName: { color: colors.text, fontSize: fontSize.subtitle, fontWeight: fontWeight.bold },
  weaponLevel: { color: colors.text, fontSize: fontSize.subtitle, fontWeight: fontWeight.heavy, fontFamily: monoFont },
  weaponArrow: { color: colors.textMuted },
  weaponMeta: { flexDirection: 'row', justifyContent: 'space-between', marginTop: spacing.sm },
  weaponMetaText: { color: colors.textMuted, fontSize: fontSize.caption },
  twoCol: { flexDirection: 'row', gap: spacing.md, marginTop: spacing.xl },
  colCard: { flex: 1, gap: spacing.sm },
  colLabel: {
    color: colors.textMuted,
    fontSize: fontSize.micro,
    fontWeight: fontWeight.bold,
    letterSpacing: 1.4,
  },
  colTitle: { color: colors.text, fontSize: fontSize.body, fontWeight: fontWeight.semibold },
  colValue: { color: colors.text, fontSize: fontSize.h2, fontWeight: fontWeight.heavy, fontFamily: monoFont },
  colValueDim: { color: colors.textMuted, fontSize: fontSize.body },
  colFoot: { color: colors.textMuted, fontSize: fontSize.caption },
  syncFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginTop: spacing.xl,
    justifyContent: 'center',
  },
  dot: { width: 7, height: 7, borderRadius: 4 },
  syncFooterText: { color: colors.textDim, fontSize: fontSize.caption },
});
