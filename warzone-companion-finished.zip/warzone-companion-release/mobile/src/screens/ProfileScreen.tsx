import React, { useCallback } from 'react';
import { Pressable, RefreshControl, StyleSheet, Switch, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Screen } from '../components/Screen';
import { Card } from '../components/Card';
import { SectionHeader } from '../components/SectionHeader';
import { StatTile, StatGrid } from '../components/Stat';
import { Badge } from '../components/Badge';
import { Button } from '../components/Button';
import { LoadingState, ErrorState } from '../components/StateViews';
import {
  useProfile,
  useNotificationPrefs,
  useSetNotificationPref,
  useRunSync,
  useProviders,
} from '../hooks/queries';
import { useAuth } from '../context/AuthContext';
import { colors, fontSize, fontWeight, monoFont, radius, spacing } from '../theme';
import { formatNumber } from '../lib/format';
import type { NotificationCategory } from '../api/types';

const NOTIF_LABELS: Record<NotificationCategory, string> = {
  CAMO_COMPLETED: 'Camo completed',
  WEAPON_LEVEL: 'Weapon level reached',
  EVENT_ENDING_SOON: 'Event ending soon',
  CHALLENGE_COMPLETED: 'Challenge completed',
  NEW_EVENT: 'New event',
  NEW_SEASON: 'New season',
  SYNC_FAILURE: 'Sync failure',
};

export function ProfileScreen() {
  const { user, signOut } = useAuth();
  const profile = useProfile();
  const prefs = useNotificationPrefs();
  const setPref = useSetNotificationPref();
  const providers = useProviders();
  const runSync = useRunSync();

  const onRefresh = useCallback(() => {
    profile.refetch();
    prefs.refetch();
    providers.refetch();
  }, [profile, prefs, providers]);

  if (profile.isLoading && !profile.data) {
    return <LoadingState label="Loading profile…" />;
  }
  if (profile.isError && !profile.data) {
    return (
      <ErrorState
        message={(profile.error as Error)?.message ?? 'Unable to load profile.'}
        onRetry={profile.refetch}
      />
    );
  }
  if (!profile.data) return null;

  const { identity, player, codUsername, platform, stats, recentPerformance, accounts, sync } =
    profile.data;

  const statusColor =
    sync?.syncStatus === 'OK'
      ? colors.success
      : sync?.syncStatus === 'ERROR'
        ? colors.danger
        : colors.warning;

  return (
    <Screen
      scroll
      contentStyle={styles.content}
      refreshControl={
        <RefreshControl
          refreshing={profile.isRefetching}
          onRefresh={onRefresh}
          tintColor={colors.primary}
        />
      }
    >
      {/* Identity */}
      <View style={styles.header}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>{identity.displayName.slice(0, 2).toUpperCase()}</Text>
        </View>
        <View style={styles.identity}>
          <Text style={styles.displayName}>{identity.displayName}</Text>
          <Text style={styles.username}>@{identity.username}</Text>
          <View style={styles.badgeRow}>
            <Badge label={identity.role} color={identity.role === 'ADMIN' ? colors.primary : colors.info} />
            {platform ? <Badge label={platform} color={colors.textSecondary} /> : null}
          </View>
        </View>
      </View>

      {/* Player card */}
      <Card style={styles.playerCard}>
        <View style={styles.playerTop}>
          <View style={styles.playerBlock}>
            <Text style={styles.playerLabel}>PLAYER LEVEL</Text>
            <Text style={styles.playerValue}>{player.level}</Text>
          </View>
          <View style={styles.playerDivider} />
          <View style={styles.playerBlock}>
            <Text style={styles.playerLabel}>PRESTIGE</Text>
            <Text style={styles.playerValue}>{player.prestige}</Text>
          </View>
          <View style={styles.playerDivider} />
          <View style={styles.playerBlock}>
            <Text style={styles.playerLabel}>TOTAL XP</Text>
            <Text style={styles.playerValue}>{formatNumber(player.xp)}</Text>
          </View>
        </View>
        <View style={styles.codRow}>
          <Ionicons name="game-controller-outline" size={14} color={colors.textMuted} />
          <Text style={styles.codText}>
            {codUsername ?? 'No COD account linked'}
            {platform ? ` · ${platform}` : ''}
          </Text>
        </View>
      </Card>

      {/* Overall stats */}
      <SectionHeader title="Overall Stats" />
      <StatGrid>
        <StatTile label="Matches" value={formatNumber(stats.totalMatches)} />
        <StatTile label="Wins" value={formatNumber(stats.wins)} accent={colors.success} />
        <StatTile label="Top 5" value={formatNumber(stats.top5)} />
        <StatTile label="Kills" value={formatNumber(stats.kills)} accent={colors.primary} />
        <StatTile label="Deaths" value={formatNumber(stats.deaths)} />
        <StatTile label="K/D" value={stats.kd.toFixed(2)} accent={colors.secondary} />
        <StatTile label="Win Rate" value={`${stats.winRate}%`} />
        <StatTile label="Avg Place" value={stats.avgPlacement.toFixed(1)} />
        <StatTile label="Damage" value={formatNumber(stats.damage)} />
      </StatGrid>

      {/* Recent performance */}
      <SectionHeader title="Recent Performance" />
      <Card padded={false} style={styles.listCard}>
        <View style={styles.listInner}>
          {recentPerformance.matches.length === 0 ? (
            <Text style={styles.emptyText}>No matches recorded yet.</Text>
          ) : (
            recentPerformance.matches.slice(0, 8).map((m) => (
              <View key={m.id} style={styles.matchRow}>
                <View style={styles.matchLeft}>
                  <Text style={styles.matchMode}>{m.mode}</Text>
                  <Text style={styles.matchMap}>{m.map}</Text>
                </View>
                <View style={styles.matchRight}>
                  <Text style={styles.matchKd}>
                    {m.kills}
                    <Text style={styles.matchKdDim}>/{m.deaths}</Text>
                  </Text>
                  <Text style={styles.matchPlacement}>#{m.placement}</Text>
                </View>
              </View>
            ))
          )}
        </View>
      </Card>

      {/* Connected accounts */}
      <SectionHeader title="Connected Accounts" />
      <Card style={styles.accountsCard}>
        {accounts.length === 0 ? (
          <Text style={styles.emptyText}>No accounts linked.</Text>
        ) : (
          accounts.map((a) => (
            <View key={a.id} style={styles.accountRow}>
              <View style={styles.accountLeft}>
                <Ionicons name="link-outline" size={16} color={colors.primary} />
                <View>
                  <Text style={styles.accountName}>{a.activisionUsername ?? a.platformUsername ?? 'COD account'}</Text>
                  <Text style={styles.accountMeta}>
                    {a.platform}
                    {a.providerKey ? ` · ${a.providerKey}` : ''}
                  </Text>
                </View>
              </View>
              <Badge
                label={a.syncStatus}
                color={a.syncStatus === 'OK' ? colors.success : a.syncStatus === 'ERROR' ? colors.danger : colors.warning}
              />
            </View>
          ))
        )}
        <Text style={styles.disclaimer}>
          We never ask for your Activision password. Accounts are linked by username only.
        </Text>
      </Card>

      {/* Sync status */}
      <SectionHeader title="Synchronization" />
      <Card style={styles.syncCard}>
        <View style={styles.syncTop}>
          <View style={styles.syncStatusWrap}>
            <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
            <Text style={styles.syncStatusText}>{sync?.syncStatus ?? 'NEVER'}</Text>
          </View>
          <Button
            label={runSync.isPending ? 'Syncing…' : 'Sync now'}
            size="md"
            variant="secondary"
            loading={runSync.isPending}
            onPress={() => runSync.mutate(undefined)}
          />
        </View>
        <Text style={styles.syncHuman}>{sync?.lastSyncHuman ?? 'Not synchronized yet'}</Text>
        {sync?.syncError ? <Text style={styles.syncError}>{sync.syncError}</Text> : null}

        <View style={styles.providerList}>
          {(providers.data ?? []).map((p) => (
            <View key={p.id} style={styles.providerRow}>
              <View style={[styles.statusDot, { backgroundColor: p.healthy ? colors.success : colors.danger }]} />
              <Text style={styles.providerName}>{p.providerKey}</Text>
              <Text style={styles.providerMeta}>
                {p.healthy ? 'healthy' : 'down'}
                {p.latencyMs != null ? ` · ${p.latencyMs}ms` : ''}
              </Text>
            </View>
          ))}
        </View>
      </Card>

      {/* Notification settings */}
      <SectionHeader title="Notifications" />
      <Card padded={false} style={styles.listCard}>
        <View style={styles.listInner}>
          {(prefs.data ?? []).map((p, idx) => (
            <View
              key={p.category}
              style={[styles.prefRow, idx === 0 && styles.prefRowFirst]}
            >
              <Text style={styles.prefLabel}>{NOTIF_LABELS[p.category] ?? p.category}</Text>
              <Switch
                value={p.enabled}
                onValueChange={(v) => setPref.mutate({ category: p.category, enabled: v })}
                trackColor={{ false: colors.surfacePressed, true: colors.primaryDark }}
                thumbColor={p.enabled ? colors.primary : colors.textDim}
              />
            </View>
          ))}
        </View>
      </Card>

      {/* Settings / sign out */}
      <SectionHeader title="Account" />
      <Card style={styles.settingsCard}>
        <Pressable style={styles.settingRow} onPress={() => signOut()}>
          <Ionicons name="log-out-outline" size={18} color={colors.danger} />
          <Text style={styles.settingDanger}>Sign out</Text>
        </Pressable>
      </Card>

      <Text style={styles.version}>Warzone Companion · v1.0.0</Text>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { paddingBottom: spacing.huge },
  header: { flexDirection: 'row', alignItems: 'center', gap: spacing.lg, marginTop: spacing.md },
  avatar: {
    width: 64,
    height: 64,
    borderRadius: radius.lg,
    backgroundColor: colors.primarySoft,
    borderWidth: 1,
    borderColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: { color: colors.primary, fontSize: fontSize.h2, fontWeight: fontWeight.heavy },
  identity: { flex: 1, gap: spacing.xs },
  displayName: { color: colors.text, fontSize: fontSize.h2, fontWeight: fontWeight.heavy },
  username: { color: colors.textMuted, fontSize: fontSize.body },
  badgeRow: { flexDirection: 'row', gap: spacing.sm, marginTop: spacing.xs },
  playerCard: { marginTop: spacing.lg, gap: spacing.md },
  playerTop: { flexDirection: 'row', alignItems: 'center', gap: spacing.lg },
  playerBlock: { flex: 1, gap: spacing.xs },
  playerDivider: { width: 1, height: 34, backgroundColor: colors.border },
  playerLabel: {
    color: colors.textMuted,
    fontSize: fontSize.micro,
    fontWeight: fontWeight.bold,
    letterSpacing: 1.2,
  },
  playerValue: {
    color: colors.text,
    fontSize: fontSize.h2,
    fontWeight: fontWeight.heavy,
    fontFamily: monoFont,
  },
  codRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.divider,
    paddingTop: spacing.md,
  },
  codText: { color: colors.textSecondary, fontSize: fontSize.small },
  listCard: { padding: 0 },
  listInner: { paddingHorizontal: spacing.lg },
  emptyText: {
    color: colors.textMuted,
    fontSize: fontSize.body,
    paddingVertical: spacing.lg,
    textAlign: 'center',
  },
  matchRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.divider,
  },
  matchLeft: { gap: 2 },
  matchMode: { color: colors.text, fontSize: fontSize.body, fontWeight: fontWeight.semibold },
  matchMap: { color: colors.textMuted, fontSize: fontSize.caption },
  matchRight: { alignItems: 'flex-end' },
  matchKd: { color: colors.text, fontSize: fontSize.bodyLg, fontWeight: fontWeight.bold, fontFamily: monoFont },
  matchKdDim: { color: colors.textMuted, fontWeight: fontWeight.regular },
  matchPlacement: { color: colors.textMuted, fontSize: fontSize.caption },
  accountsCard: { gap: spacing.md },
  accountRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  accountLeft: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  accountName: { color: colors.text, fontSize: fontSize.body, fontWeight: fontWeight.semibold },
  accountMeta: { color: colors.textMuted, fontSize: fontSize.caption },
  disclaimer: {
    color: colors.textDim,
    fontSize: fontSize.caption,
    lineHeight: 16,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.divider,
    paddingTop: spacing.md,
  },
  syncCard: { gap: spacing.md },
  syncTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  syncStatusWrap: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  statusDot: { width: 8, height: 8, borderRadius: 4 },
  syncStatusText: {
    color: colors.text,
    fontSize: fontSize.body,
    fontWeight: fontWeight.bold,
    letterSpacing: 1,
  },
  syncHuman: { color: colors.textMuted, fontSize: fontSize.small },
  syncError: { color: colors.danger, fontSize: fontSize.small },
  providerList: {
    gap: spacing.sm,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.divider,
    paddingTop: spacing.md,
  },
  providerRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  providerName: { color: colors.textSecondary, fontSize: fontSize.small, flex: 1 },
  providerMeta: { color: colors.textDim, fontSize: fontSize.caption },
  prefRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.divider,
  },
  prefRowFirst: { paddingTop: spacing.md },
  prefLabel: { color: colors.text, fontSize: fontSize.body },
  settingsCard: { padding: 0 },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    padding: spacing.lg,
  },
  settingDanger: { color: colors.danger, fontSize: fontSize.body, fontWeight: fontWeight.semibold },
  version: {
    color: colors.textDim,
    fontSize: fontSize.caption,
    textAlign: 'center',
    marginTop: spacing.xl,
  },
});
