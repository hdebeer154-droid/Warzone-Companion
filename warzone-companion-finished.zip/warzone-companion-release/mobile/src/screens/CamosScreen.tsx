import React, { useCallback, useMemo, useState } from 'react';
import { Pressable, RefreshControl, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';

import { Screen } from '../components/Screen';
import { Card } from '../components/Card';
import { SectionHeader } from '../components/SectionHeader';
import { ProgressBar } from '../components/ProgressBar';
import { WeaponCard } from '../components/WeaponCard';
import { LoadingState, ErrorState, EmptyState } from '../components/StateViews';
import { useCamoOverview, useCamoSets, useWeapons } from '../hooks/queries';
import { colors, fontSize, fontWeight, monoFont, radius, spacing } from '../theme';
import { categoryLabel, progressColor, rarityColor } from '../lib/format';
import type { RootStackParamList } from '../navigation/types';
import type { CamoSetSummary } from '../api/types';

type Nav = NativeStackNavigationProp<RootStackParamList>;

export function CamosScreen() {
  const navigation = useNavigation<Nav>();
  const overview = useCamoOverview();
  const sets = useCamoSets();
  const weapons = useWeapons({ sort: 'completion', pageSize: 50 });
  const [expandedSet, setExpandedSet] = useState<string | null>(null);

  const onRefresh = useCallback(() => {
    overview.refetch();
    sets.refetch();
    weapons.refetch();
  }, [overview, sets, weapons]);

  const isRefreshing = overview.isRefetching || sets.isRefetching || weapons.isRefetching;

  const categories = useMemo(() => {
    const list = overview.data?.byCategory ?? [];
    return [...list].sort((a, b) => b.completionPct - a.completionPct);
  }, [overview.data]);

  if (overview.isLoading && !overview.data) {
    return <LoadingState label="Loading camo progression…" />;
  }
  if (overview.isError && !overview.data) {
    return (
      <ErrorState
        message={(overview.error as Error)?.message ?? 'Unable to load camo progression.'}
        onRetry={overview.refetch}
      />
    );
  }

  const overall = overview.data?.overall;
  const overallColor = progressColor(overall?.completionPct ?? 0);
  const weaponItems = weapons.data?.items ?? [];

  return (
    <Screen
      scroll
      contentStyle={styles.content}
      refreshControl={
        <RefreshControl refreshing={isRefreshing} onRefresh={onRefresh} tintColor={colors.primary} />
      }
    >
      <View style={styles.header}>
        <Text style={styles.kicker}>CAMO PROGRESSION</Text>
        <View style={styles.overallRow}>
          <Text style={[styles.overallValue, { color: overallColor }]}>
            {overall?.completionPct ?? 0}%
          </Text>
          <Text style={styles.overallCount}>
            {overall?.completed ?? 0}
            <Text style={styles.overallCountDim}>/{overall?.total ?? 0} camos</Text>
          </Text>
        </View>
        <ProgressBar value={overall?.completionPct ?? 0} color={overallColor} height={8} />
      </View>

      {/* Per-category completion */}
      <SectionHeader title="By Category" subtitle={`${categories.length} categories`} />
      <Card padded={false} style={styles.listCard}>
        <View style={styles.listInner}>
          {categories.length === 0 ? (
            <Text style={styles.emptyText}>No camo data yet.</Text>
          ) : (
            categories.map((c) => {
              const color = progressColor(c.completionPct);
              return (
                <View key={c.category} style={styles.categoryRow}>
                  <View style={styles.categoryTop}>
                    <Text style={styles.categoryName}>{categoryLabel(c.category)}</Text>
                    <Text style={[styles.categoryCount, { color }]}>
                      {c.completed}
                      <Text style={styles.categoryCountDim}>/{c.total}</Text>
                    </Text>
                  </View>
                  <ProgressBar value={c.completionPct} color={color} height={5} />
                </View>
              );
            })
          )}
        </View>
      </Card>

      {/* Camo sets */}
      <SectionHeader title="Camo Sets" subtitle="Tap a set to expand" />
      {(sets.data ?? []).map((set) => (
        <CamoSetBlock
          key={set.id}
          set={set}
          expanded={expandedSet === set.id}
          onToggle={() => setExpandedSet((prev) => (prev === set.id ? null : set.id))}
        />
      ))}

      {/* Weapons */}
      <SectionHeader title="Weapons" subtitle="Select a weapon for its camos" />
      <View style={styles.weaponList}>
        {weaponItems.length === 0 ? (
          <EmptyState title="No weapons yet" message="Weapons will appear once your account is synced." />
        ) : (
          weaponItems.map((w) => (
            <WeaponCard
              key={w.id}
              weapon={w}
              onPress={() => navigation.navigate('WeaponDetail', { weaponId: w.id })}
            />
          ))
        )}
      </View>
    </Screen>
  );
}

function CamoSetBlock({
  set,
  expanded,
  onToggle,
}: {
  set: CamoSetSummary;
  expanded: boolean;
  onToggle: () => void;
}) {
  const color = rarityColor(set.category);
  return (
    <Card style={styles.setCard} onPress={onToggle}>
      <View style={styles.setTop}>
        <View style={styles.setTitleWrap}>
          <Text style={styles.setName}>{set.name}</Text>
          <Text style={styles.setCategory}>{set.category}</Text>
        </View>
        <View style={styles.setRight}>
          <Text style={[styles.setPct, { color }]}>{set.completionPct}%</Text>
          <Ionicons name={expanded ? 'chevron-up' : 'chevron-down'} size={16} color={colors.textMuted} />
        </View>
      </View>
      <ProgressBar value={set.completionPct} color={color} height={5} />
      <Text style={styles.setCount}>
        {set.completed}/{set.total} camos complete
      </Text>

      {expanded ? (
        <View style={styles.setCamos}>
          {set.camos.map((camo) => {
            const camoColor = rarityColor(set.category);
            const done = camo.completed >= camo.challengeCount && camo.challengeCount > 0;
            return (
              <View key={camo.id} style={styles.camoRow}>
                <View style={[styles.camoDot, { backgroundColor: done ? camoColor : colors.surfacePressed }]}>
                  {done ? <Ionicons name="checkmark" size={11} color={colors.black} /> : null}
                </View>
                <Text style={styles.camoName} numberOfLines={1}>
                  {camo.name}
                </Text>
                <Text style={styles.camoCount}>
                  {camo.completed}/{camo.challengeCount}
                </Text>
              </View>
            );
          })}
        </View>
      ) : null}
    </Card>
  );
}

const styles = StyleSheet.create({
  content: { paddingBottom: spacing.huge },
  header: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.lg,
    marginTop: spacing.md,
    gap: spacing.md,
  },
  kicker: {
    color: colors.textMuted,
    fontSize: fontSize.caption,
    fontWeight: fontWeight.bold,
    letterSpacing: 2.5,
  },
  overallRow: { flexDirection: 'row', alignItems: 'flex-end', gap: spacing.md },
  overallValue: {
    fontSize: fontSize.display,
    fontWeight: fontWeight.heavy,
    fontFamily: monoFont,
    letterSpacing: -1,
  },
  overallCount: { color: colors.textSecondary, fontSize: fontSize.body, marginBottom: 6 },
  overallCountDim: { color: colors.textMuted },
  listCard: { padding: 0 },
  listInner: { paddingHorizontal: spacing.lg },
  emptyText: {
    color: colors.textMuted,
    fontSize: fontSize.body,
    paddingVertical: spacing.lg,
    textAlign: 'center',
  },
  categoryRow: {
    paddingVertical: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.divider,
    gap: spacing.sm,
  },
  categoryTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  categoryName: { color: colors.text, fontSize: fontSize.body, fontWeight: fontWeight.semibold },
  categoryCount: { fontSize: fontSize.body, fontWeight: fontWeight.bold, fontFamily: monoFont },
  categoryCountDim: { color: colors.textMuted, fontWeight: fontWeight.regular },
  setCard: { marginBottom: spacing.md, gap: spacing.sm },
  setTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  setTitleWrap: { flex: 1 },
  setName: { color: colors.text, fontSize: fontSize.bodyLg, fontWeight: fontWeight.bold },
  setCategory: {
    color: colors.textMuted,
    fontSize: fontSize.micro,
    fontWeight: fontWeight.bold,
    letterSpacing: 1.2,
    marginTop: 1,
  },
  setRight: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  setPct: { fontSize: fontSize.subtitle, fontWeight: fontWeight.heavy, fontFamily: monoFont },
  setCount: { color: colors.textMuted, fontSize: fontSize.caption },
  setCamos: {
    marginTop: spacing.sm,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.divider,
    paddingTop: spacing.sm,
    gap: spacing.sm,
  },
  camoRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  camoDot: {
    width: 18,
    height: 18,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
  },
  camoName: { flex: 1, color: colors.textSecondary, fontSize: fontSize.small },
  camoCount: { color: colors.textMuted, fontSize: fontSize.caption, fontFamily: monoFont },
  weaponList: { gap: spacing.md },
});
