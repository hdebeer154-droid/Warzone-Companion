import React, { useCallback, useMemo, useState } from 'react';
import { Pressable, RefreshControl, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';

import { Screen } from '../components/Screen';
import { Card } from '../components/Card';
import { SectionHeader } from '../components/SectionHeader';
import { ProgressBar } from '../components/ProgressBar';
import { ChallengeRow } from '../components/ChallengeRow';
import { Badge } from '../components/Badge';
import { StatTile, StatGrid } from '../components/Stat';
import { LoadingState, ErrorState } from '../components/StateViews';
import { useWeapon, useToggleFavourite } from '../hooks/queries';
import { colors, fontSize, fontWeight, monoFont, radius, spacing } from '../theme';
import { categoryLabel, formatNumber, progressColor, rarityColor, requirementLabel } from '../lib/format';
import type { RootStackParamList } from '../navigation/types';

type Props = NativeStackScreenProps<RootStackParamList, 'WeaponDetail'>;

export function WeaponDetailScreen({ route }: Props) {
  const { weaponId } = route.params;
  const { data, isLoading, isError, error, refetch, isRefetching } = useWeapon(weaponId);
  const toggleFavourite = useToggleFavourite();
  const [tab, setTab] = useState<'CAMOS' | 'LEVELS'>('CAMOS');

  const groupedCamos = useMemo(() => {
    const map = new Map<string, NonNullable<typeof data>['camoChallenges']>();
    (data?.camoChallenges ?? []).forEach((c) => {
      const key = c.camo.set;
      const arr = map.get(key) ?? [];
      arr.push(c);
      map.set(key, arr);
    });
    return Array.from(map.entries());
  }, [data]);

  const onRefresh = useCallback(() => refetch(), [refetch]);

  if (isLoading && !data) return <LoadingState label="Loading weapon…" />;
  if (isError && !data) {
    return (
      <ErrorState
        message={(error as Error)?.message ?? 'Unable to load weapon.'}
        onRetry={refetch}
      />
    );
  }
  if (!data) return null;

  const levelColor = progressColor(data.levelProgressPct);
  const camoColor = progressColor(data.camoCompletionPct);

  return (
    <Screen
      scroll
      contentStyle={styles.content}
      refreshControl={
        <RefreshControl refreshing={isRefetching} onRefresh={onRefresh} tintColor={colors.primary} />
      }
    >
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.thumb}>
          <Text style={styles.thumbGlyph}>{data.name.slice(0, 2).toUpperCase()}</Text>
        </View>
        <View style={styles.headerBody}>
          <Text style={styles.name}>{data.name}</Text>
          <Text style={styles.category}>{categoryLabel(data.category)}</Text>
          <View style={styles.headerBadges}>
            {data.isDlc ? <Badge label="DLC" color={colors.primary} /> : null}
            {data.favourite ? <Badge label="Favourite" color={colors.primary} /> : null}
          </View>
        </View>
        <Pressable
          style={styles.favBtn}
          onPress={() => toggleFavourite.mutate(data.id)}
          hitSlop={10}
        >
          <Ionicons
            name={data.favourite ? 'star' : 'star-outline'}
            size={24}
            color={data.favourite ? colors.primary : colors.textDim}
          />
        </Pressable>
      </View>

      {/* Level + camo progress */}
      <Card style={styles.progressCard}>
        <View style={styles.progressBlock}>
          <View style={styles.progressTop}>
            <Text style={styles.progressLabel}>WEAPON LEVEL</Text>
            <Text style={[styles.progressValue, { color: levelColor }]}>
              {data.level}
              <Text style={styles.progressMax}>/{data.maxLevel}</Text>
            </Text>
          </View>
          <ProgressBar value={data.levelProgressPct} color={levelColor} height={7} />
          <Text style={styles.progressFoot}>
            {formatNumber(data.xpToNextLevel)} XP to next level · {formatNumber(data.xp)} total XP
          </Text>
        </View>

        <View style={styles.progressBlock}>
          <View style={styles.progressTop}>
            <Text style={styles.progressLabel}>CAMO COMPLETION</Text>
            <Text style={[styles.progressValue, { color: camoColor }]}>
              {data.camoCompleted}
              <Text style={styles.progressMax}>/{data.camoTotal}</Text>
            </Text>
          </View>
          <ProgressBar value={data.camoCompletionPct} color={camoColor} height={7} />
          <Text style={styles.progressFoot}>{data.camoCompletionPct}% of camo challenges complete</Text>
        </View>
      </Card>

      {/* Stats */}
      <SectionHeader title="Performance" />
      <StatGrid>
        <StatTile label="Kills" value={formatNumber(data.kills)} accent={colors.primary} />
        <StatTile label="Headshots" value={formatNumber(data.headshots)} />
        <StatTile label="Matches" value={formatNumber(data.matches)} />
      </StatGrid>

      {/* Tabs */}
      <View style={styles.tabs}>
        <Pressable
          style={[styles.tab, tab === 'CAMOS' && styles.tabActive]}
          onPress={() => setTab('CAMOS')}
        >
          <Text style={[styles.tabText, tab === 'CAMOS' && styles.tabTextActive]}>
            CAMO CHALLENGES
          </Text>
        </Pressable>
        <Pressable
          style={[styles.tab, tab === 'LEVELS' && styles.tabActive]}
          onPress={() => setTab('LEVELS')}
        >
          <Text style={[styles.tabText, tab === 'LEVELS' && styles.tabTextActive]}>LEVEL REWARDS</Text>
        </Pressable>
      </View>

      {tab === 'CAMOS' ? (
        groupedCamos.length === 0 ? (
          <Card>
            <Text style={styles.emptyText}>No camo challenges for this weapon.</Text>
          </Card>
        ) : (
          groupedCamos.map(([setName, challenges]) => {
            const setCategory = challenges[0]?.camo.setCategory ?? 'MILITARY';
            const color = rarityColor(setCategory);
            const done = challenges.filter((c) => c.completed).length;
            return (
              <View key={setName} style={styles.setBlock}>
                <View style={styles.setHeader}>
                  <View style={[styles.setDot, { backgroundColor: color }]} />
                  <Text style={styles.setName}>{setName}</Text>
                  <Text style={styles.setCount}>
                    {done}/{challenges.length}
                  </Text>
                </View>
                <Card padded={false} style={styles.listCard}>
                  <View style={styles.listInner}>
                    {challenges.map((c) => (
                      <ChallengeRow
                        key={c.id}
                        title={c.camo.name}
                        subtitle={`${requirementLabel(c.requirementType)} · ${c.source}`}
                        current={c.currentValue}
                        target={c.targetValue}
                        progressPct={c.progressPct}
                        completed={c.completed}
                        accent={color}
                      />
                    ))}
                  </View>
                </Card>
              </View>
            );
          })
        )
      ) : (
        <Card padded={false} style={styles.listCard}>
          <View style={styles.listInner}>
            {data.levels.map((lvl) => (
              <View key={lvl.level} style={styles.levelRow}>
                <View style={[styles.levelBadge, lvl.unlocked && styles.levelBadgeOn]}>
                  <Text style={[styles.levelBadgeText, lvl.unlocked && styles.levelBadgeTextOn]}>
                    {lvl.level}
                  </Text>
                </View>
                <View style={styles.levelBody}>
                  <Text style={styles.levelReward}>
                    {lvl.rewardName ?? `Level ${lvl.level}`}
                  </Text>
                  <Text style={styles.levelMeta}>
                    {lvl.rewardType ? `${lvl.rewardType} · ` : ''}
                    {formatNumber(lvl.xpRequired)} XP
                  </Text>
                </View>
                {lvl.unlocked ? (
                  <Ionicons name="checkmark-circle" size={18} color={colors.success} />
                ) : (
                  <Ionicons name="lock-closed" size={16} color={colors.textDim} />
                )}
              </View>
            ))}
          </View>
        </Card>
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { paddingBottom: spacing.huge, paddingTop: spacing.md },
  header: { flexDirection: 'row', alignItems: 'center', gap: spacing.lg },
  thumb: {
    width: 64,
    height: 64,
    borderRadius: radius.lg,
    backgroundColor: colors.surfaceElevated,
    borderWidth: 1,
    borderColor: colors.borderStrong,
    alignItems: 'center',
    justifyContent: 'center',
  },
  thumbGlyph: {
    color: colors.textMuted,
    fontSize: fontSize.h2,
    fontWeight: fontWeight.heavy,
    fontFamily: monoFont,
  },
  headerBody: { flex: 1, gap: 2 },
  name: { color: colors.text, fontSize: fontSize.h2, fontWeight: fontWeight.heavy },
  category: { color: colors.textMuted, fontSize: fontSize.small },
  headerBadges: { flexDirection: 'row', gap: spacing.sm, marginTop: spacing.xs },
  favBtn: { padding: 4 },
  progressCard: { marginTop: spacing.lg, gap: spacing.xl },
  progressBlock: { gap: spacing.sm },
  progressTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline' },
  progressLabel: {
    color: colors.textMuted,
    fontSize: fontSize.micro,
    fontWeight: fontWeight.bold,
    letterSpacing: 1.2,
  },
  progressValue: { fontSize: fontSize.h2, fontWeight: fontWeight.heavy, fontFamily: monoFont },
  progressMax: { color: colors.textMuted, fontSize: fontSize.body },
  progressFoot: { color: colors.textMuted, fontSize: fontSize.caption },
  tabs: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginTop: spacing.xl,
    marginBottom: spacing.md,
  },
  tab: {
    flex: 1,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
  },
  tabActive: { backgroundColor: colors.primarySoft, borderColor: colors.primary },
  tabText: {
    color: colors.textMuted,
    fontSize: fontSize.small,
    fontWeight: fontWeight.bold,
    letterSpacing: 0.8,
  },
  tabTextActive: { color: colors.primary },
  setBlock: { marginBottom: spacing.lg },
  setHeader: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.sm },
  setDot: { width: 8, height: 8, borderRadius: 4 },
  setName: { flex: 1, color: colors.text, fontSize: fontSize.body, fontWeight: fontWeight.bold },
  setCount: { color: colors.textMuted, fontSize: fontSize.small, fontFamily: monoFont },
  listCard: { padding: 0 },
  listInner: { paddingHorizontal: spacing.lg },
  emptyText: { color: colors.textMuted, fontSize: fontSize.body, textAlign: 'center' },
  levelRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.divider,
  },
  levelBadge: {
    width: 34,
    height: 34,
    borderRadius: radius.sm,
    backgroundColor: colors.surfaceElevated,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  levelBadgeOn: { backgroundColor: colors.secondarySoft, borderColor: colors.secondary },
  levelBadgeText: { color: colors.textMuted, fontSize: fontSize.small, fontWeight: fontWeight.bold, fontFamily: monoFont },
  levelBadgeTextOn: { color: colors.secondary },
  levelBody: { flex: 1, gap: 2 },
  levelReward: { color: colors.text, fontSize: fontSize.body, fontWeight: fontWeight.semibold },
  levelMeta: { color: colors.textMuted, fontSize: fontSize.caption },
});
