import React, { useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';

import { colors, fontSize, fontWeight, monoFont, radius, spacing } from '../theme';
import { Button } from '../components/Button';
import { useAuth } from '../context/AuthContext';
import { ApiError } from '../api/client';
import type { RootStackParamList } from '../navigation/types';

type Props = NativeStackScreenProps<RootStackParamList, 'Login'>;

export function LoginScreen({ navigation }: Props) {
  const { signIn } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onSubmit = async () => {
    setLoading(true);
    setError(null);
    try {
      await signIn(email.trim(), password);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Unable to sign in. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const fillDemo = () => {
    setEmail('fenrir@warzone.gg');
    setPassword('Fenrir#2025');
  };

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <View style={styles.brand}>
            <Text style={styles.kicker}>TACTICAL PROGRESSION TRACKER</Text>
            <Text style={styles.title}>WARZONE</Text>
            <Text style={styles.titleAccent}>COMPANION</Text>
          </View>

          <View style={styles.form}>
            <Text style={styles.label}>EMAIL</Text>
            <TextInput
              style={styles.input}
              value={email}
              onChangeText={setEmail}
              autoCapitalize="none"
              keyboardType="email-address"
              placeholder="operator@warzone.gg"
              placeholderTextColor={colors.textDim}
            />

            <Text style={styles.label}>PASSWORD</Text>
            <TextInput
              style={styles.input}
              value={password}
              onChangeText={setPassword}
              secureTextEntry
              placeholder="••••••••"
              placeholderTextColor={colors.textDim}
            />

            {error ? <Text style={styles.error}>{error}</Text> : null}

            <Button label="SIGN IN" onPress={onSubmit} loading={loading} size="lg" style={styles.cta} />

            <Pressable onPress={fillDemo} style={styles.demoBtn}>
              <Text style={styles.demoText}>Use demo account (FENRIR)</Text>
            </Pressable>
          </View>

          <View style={styles.footer}>
            <Text style={styles.footerText}>No account yet?</Text>
            <Pressable onPress={() => navigation.navigate('Register')} hitSlop={8}>
              <Text style={styles.footerLink}>Create one</Text>
            </Pressable>
          </View>

          <Text style={styles.disclaimer}>
            We never ask for your Activision password. Progress is tracked via secure account
            linking, screenshots and manual entry.
          </Text>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  flex: { flex: 1 },
  content: {
    flexGrow: 1,
    padding: spacing.xxl,
    justifyContent: 'center',
    gap: spacing.xxl,
  },
  brand: { gap: spacing.xs },
  kicker: {
    color: colors.textMuted,
    fontSize: fontSize.caption,
    fontWeight: fontWeight.bold,
    letterSpacing: 3,
  },
  title: {
    color: colors.text,
    fontSize: fontSize.display,
    fontWeight: fontWeight.heavy,
    letterSpacing: 2,
    lineHeight: 42,
  },
  titleAccent: {
    color: colors.primary,
    fontSize: fontSize.display,
    fontWeight: fontWeight.heavy,
    letterSpacing: 2,
    lineHeight: 42,
  },
  form: { gap: spacing.sm },
  label: {
    color: colors.textMuted,
    fontSize: fontSize.micro,
    fontWeight: fontWeight.bold,
    letterSpacing: 1.5,
    marginTop: spacing.md,
  },
  input: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    color: colors.text,
    fontSize: fontSize.bodyLg,
  },
  error: {
    color: colors.danger,
    fontSize: fontSize.small,
    marginTop: spacing.sm,
  },
  cta: { marginTop: spacing.lg },
  demoBtn: { alignSelf: 'center', marginTop: spacing.md },
  demoText: {
    color: colors.primary,
    fontSize: fontSize.small,
    fontWeight: fontWeight.semibold,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: spacing.sm,
  },
  footerText: { color: colors.textMuted, fontSize: fontSize.body },
  footerLink: { color: colors.primary, fontSize: fontSize.body, fontWeight: fontWeight.bold },
  disclaimer: {
    color: colors.textDim,
    fontSize: fontSize.caption,
    textAlign: 'center',
    lineHeight: 17,
    fontFamily: monoFont,
  },
});
