import React, { useCallback } from 'react';
import { RefreshControl, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';

import { Screen } from '../components/Screen';
import { Card } from '../components/Card';
import { SectionHeader } from '../components/SectionHeader';
import { StatTile, StatGrid } from '../components/Stat';
import { Badge } from '../components/Badge';
import { ProgressBar } from '../components/ProgressBar';
import { LoadingState, ErrorState } from '../components/StateViews';
import { useMatch } from '../hooks/queries';
import { colors, fontSize, fontWeight, monoFont, radius, spacing } from '../theme';
import { categoryLabel, formatNumber } from '../lib/format';
import type { RootStackParamList } from '../navigation/types';

type Props = NativeStackScreenProps<RootStackParamList, 'MatchDetail'>;

function placementColor(placement: number): string {
  if (placement === 1) return colors.gold;
  if (placement <= 3) return colors.success;
  if (placement <= 10) return colors.primary;
  return colors.textMuted;
}

function formatDate(iso: string | null): string {
  if (!iso) return 'Unknown time';
  const d = new Date(iso);
  return d.toLocaleString(undefined, {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function MatchDetailScreen({ route }: Props) {
  const { matchId } = route.params;
  const { data, isLoading, isError, error, refetch, isRefetching } = useMatch(matchId);

  const onRefresh = useCallback(() => refetch(), [refetch]);

  if (isLoading && !data) return <LoadingState label="Loading match…" />;
  if (isError && !data) {
    return (
      <ErrorState message={(error as Error)?.message ?? 'Unable to load match.'} onRetry={refetch} />
    );
  }
  if (!data) return null;

  const topDamage = Math.max(1, ...data.weaponStats.map((w) => w.damage));
  const won = data.placement === 1;

  return (
    <Screen
      scroll
      contentStyle={styles.content}
      refreshControl={
        <RefreshControl refreshing={isRefetching} onRefresh={onRefresh} tintColor={colors.primary} />
      }
    >
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerTop}>
          <View>
            <Text style={styles.mode}>{data.mode}</Text>
            <Text style={styles.map}>{data.map}</Text>
            <Text style={styles.date}>{formatDate(data.startedAt)}</Text>
          </View>
          <View style={styles.placementWrap}>
            <Text style={[styles.placement, { color: placementColor(data.placement) }]}>
              #{data.placement}
            </Text>
            {won ? <Badge label="Victory" color={colors.gold} /> : null}
          </View>
        </View>
        {data.playlist ? (
          <View style={styles.playlistRow}>
            <Ionicons name="albums-outline" size={13} color={colors.textMuted} />
            <Text style={styles.playlist}>{data.playlist}</Text>
          </View>
        ) : null}
      </View>

      {/* Core stats */}
      <SectionHeader title="Scoreboard" />
      <StatGrid>
        <StatTile label="Kills" value={data.kills} accent={colors.primary} />
        <StatTile label="Deaths" value={data.deaths} />
        <StatTile label="Assists" value={data.assists} />
        <StatTile label="K/D" value={data.kd.toFixed(2)} accent={colors.secondary} />
        <StatTile label="Damage" value={formatNumber(data.damage)} />
        <StatTile label="XP" value={formatNumber(data.xp)} />
      </StatGrid>

      {/* Weapon breakdown */}
      <SectionHeader title="Weapon Breakdown" subtitle={`${data.weaponStats.length} weapons used`} />
      <Card padded={false} style={styles.listCard}>
        <View style={styles.listInner}>
          {data.weaponStats.length === 0 ? (
            <Text style={styles.emptyText}>No weapon data recorded for this match.</Text>
          ) : (
            data.weaponStats.map((w, i) => (
              <View key={`${w.weapon.id}-${i}`} style={styles.weaponRow}>
                <View style={styles.weaponTop}>
                  <View style={styles.weaponNameWrap}>
                    <Text style={styles.weaponName}>{w.weapon.name}</Text>
                    <Text style={styles.weaponCategory}>{categoryLabel(w.weapon.category)}</Text>
                  </View>
                  <Text style={styles.weaponKills}>
                    {w.kills}
                    <Text style={styles.weaponKillsDim}> kills</Text>
                  </Text>
                </View>
                <ProgressBar value={(w.damage / topDamage) * 100} color={colors.primary} height={5} />
                <View style={styles.weaponMeta}>
                  <Text style={styles.weaponMetaText}>{formatNumber(w.damage)} damage</Text>
                  <Text style={styles.weaponMetaText}>{w.headshots} headshots</Text>
                </View>
              </View>
            ))
          )}
        </View>
      </Card>

      {/* Match id */}
      <Text style={styles.matchId}>Match ID · {data.externalMatchId}</Text>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { paddingBottom: spacing.huge, paddingTop: spacing.md },
  header: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.lg,
    gap: spacing.md,
  },
  headerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  mode: { color: colors.text, fontSize: fontSize.h2, fontWeight: fontWeight.heavy },
  map: { color: colors.textSecondary, fontSize: fontSize.body, marginTop: 2 },
  date: { color: colors.textMuted, fontSize: fontSize.caption, marginTop: 2 },
  placementWrap: { alignItems: 'flex-end', gap: spacing.sm },
  placement: { fontSize: fontSize.display, fontWeight: fontWeight.heavy, fontFamily: monoFont, letterSpacing: -1 },
  playlistRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.divider,
    paddingTop: spacing.md,
  },
  playlist: { color: colors.textMuted, fontSize: fontSize.small },
  listCard: { padding: 0 },
  listInner: { paddingHorizontal: spacing.lg },
  emptyText: {
    color: colors.textMuted,
    fontSize: fontSize.body,
    paddingVertical: spacing.lg,
    textAlign: 'center',
  },
  weaponRow: {
    paddingVertical: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.divider,
    gap: spacing.sm,
  },
  weaponTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  weaponNameWrap: { flex: 1 },
  weaponName: { color: colors.text, fontSize: fontSize.bodyLg, fontWeight: fontWeight.semibold },
  weaponCategory: { color: colors.textMuted, fontSize: fontSize.caption },
  weaponKills: { color: colors.text, fontSize: fontSize.bodyLg, fontWeight: fontWeight.bold, fontFamily: monoFont },
  weaponKillsDim: { color: colors.textMuted, fontSize: fontSize.caption, fontWeight: fontWeight.regular },
  weaponMeta: { flexDirection: 'row', justifyContent: 'space-between' },
  weaponMetaText: { color: colors.textMuted, fontSize: fontSize.caption },
  matchId: {
    color: colors.textDim,
    fontSize: fontSize.caption,
    textAlign: 'center',
    marginTop: spacing.xl,
    fontFamily: monoFont,
  },
});
