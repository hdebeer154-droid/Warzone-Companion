import React, { useCallback } from 'react';
import { RefreshControl, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';

import { Screen } from '../components/Screen';
import { Card } from '../components/Card';
import { SectionHeader } from '../components/SectionHeader';
import { ProgressBar } from '../components/ProgressBar';
import { ChallengeRow } from '../components/ChallengeRow';
import { Badge } from '../components/Badge';
import { LoadingState, ErrorState } from '../components/StateViews';
import { useCallingCard } from '../hooks/queries';
import { colors, fontSize, fontWeight, monoFont, radius, spacing } from '../theme';
import { progressColor, requirementLabel } from '../lib/format';
import type { RootStackParamList } from '../navigation/types';

type Props = NativeStackScreenProps<RootStackParamList, 'CallingCardDetail'>;

export function CallingCardDetailScreen({ route }: Props) {
  const { id } = route.params;
  const { data, isLoading, isError, error, refetch, isRefetching } = useCallingCard(id);

  const onRefresh = useCallback(() => refetch(), [refetch]);

  if (isLoading && !data) return <LoadingState label="Loading calling card…" />;
  if (isError && !data) {
    return (
      <ErrorState
        message={(error as Error)?.message ?? 'Unable to load calling card.'}
        onRetry={refetch}
      />
    );
  }
  if (!data) return null;

  const color = progressColor(data.completionPct);

  return (
    <Screen
      scroll
      contentStyle={styles.content}
      refreshControl={
        <RefreshControl refreshing={isRefetching} onRefresh={onRefresh} tintColor={colors.primary} />
      }
    >
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.emblem}>
          <Ionicons name="albums" size={30} color={colors.info} />
        </View>
        <View style={styles.headerBody}>
          <Text style={styles.name}>{data.name}</Text>
          <Text style={styles.category}>{data.category}</Text>
          <View style={styles.badgeRow}>
            <Badge label={data.unlocked ? 'Unlocked' : 'Locked'} color={data.unlocked ? colors.success : colors.textMuted} />
          </View>
        </View>
      </View>

      {data.description ? <Text style={styles.description}>{data.description}</Text> : null}

      {/* Completion */}
      <Card style={styles.progressCard}>
        <View style={styles.progressTop}>
          <Text style={styles.progressLabel}>COMPLETION</Text>
          <Text style={[styles.progressValue, { color }]}>
            {data.completed}
            <Text style={styles.progressMax}>/{data.total}</Text>
          </Text>
        </View>
        <ProgressBar value={data.completionPct} color={color} height={8} />
        <Text style={styles.progressFoot}>{data.completionPct}% complete</Text>
      </Card>

      {/* Challenges */}
      <SectionHeader title="Challenges" subtitle={`${data.completed}/${data.total} complete`} />
      <Card padded={false} style={styles.listCard}>
        <View style={styles.listInner}>
          {data.challenges.length === 0 ? (
            <Text style={styles.emptyText}>No challenges for this calling card.</Text>
          ) : (
            data.challenges.map((ch) => (
              <ChallengeRow
                key={ch.id}
                title={ch.description}
                subtitle={`${requirementLabel(ch.requirementType)} · ${ch.source}`}
                current={ch.currentValue}
                target={ch.targetValue}
                progressPct={ch.progressPct}
                completed={ch.completed}
                accent={colors.info}
              />
            ))
          )}
        </View>
      </Card>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { paddingBottom: spacing.huge, paddingTop: spacing.md },
  header: { flexDirection: 'row', alignItems: 'center', gap: spacing.lg },
  emblem: {
    width: 64,
    height: 64,
    borderRadius: radius.lg,
    backgroundColor: 'rgba(76, 154, 255, 0.14)',
    borderWidth: 1,
    borderColor: colors.info,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerBody: { flex: 1, gap: spacing.xs },
  name: { color: colors.text, fontSize: fontSize.h2, fontWeight: fontWeight.heavy },
  category: {
    color: colors.textMuted,
    fontSize: fontSize.micro,
    fontWeight: fontWeight.bold,
    letterSpacing: 1.4,
  },
  badgeRow: { flexDirection: 'row', gap: spacing.sm, marginTop: spacing.xs },
  description: {
    color: colors.textSecondary,
    fontSize: fontSize.body,
    lineHeight: 20,
    marginTop: spacing.lg,
  },
  progressCard: { marginTop: spacing.lg, gap: spacing.sm },
  progressTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline' },
  progressLabel: {
    color: colors.textMuted,
    fontSize: fontSize.micro,
    fontWeight: fontWeight.bold,
    letterSpacing: 1.2,
  },
  progressValue: { fontSize: fontSize.h2, fontWeight: fontWeight.heavy, fontFamily: monoFont },
  progressMax: { color: colors.textMuted, fontSize: fontSize.body },
  progressFoot: { color: colors.textMuted, fontSize: fontSize.caption },
  listCard: { padding: 0 },
  listInner: { paddingHorizontal: spacing.lg },
  emptyText: {
    color: colors.textMuted,
    fontSize: fontSize.body,
    paddingVertical: spacing.lg,
    textAlign: 'center',
  },
});
