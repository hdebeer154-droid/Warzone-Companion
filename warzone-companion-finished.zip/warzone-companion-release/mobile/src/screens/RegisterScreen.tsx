import React, { useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';

import { colors, fontSize, fontWeight, radius, spacing } from '../theme';
import { Button } from '../components/Button';
import { useAuth } from '../context/AuthContext';
import { ApiError } from '../api/client';
import type { RootStackParamList } from '../navigation/types';

type Props = NativeStackScreenProps<RootStackParamList, 'Register'>;

export function RegisterScreen({ navigation }: Props) {
  const { signUp } = useAuth();
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onSubmit = async () => {
    setLoading(true);
    setError(null);
    try {
      await signUp({
        email: email.trim(),
        username: username.trim(),
        password,
        displayName: displayName.trim() || username.trim(),
      });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Unable to create your account.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <View style={styles.brand}>
            <Text style={styles.kicker}>CREATE OPERATOR</Text>
            <Text style={styles.title}>JOIN THE</Text>
            <Text style={styles.titleAccent}>COMPANION</Text>
          </View>

          <View style={styles.form}>
            <Text style={styles.label}>EMAIL</Text>
            <TextInput
              style={styles.input}
              value={email}
              onChangeText={setEmail}
              autoCapitalize="none"
              keyboardType="email-address"
              placeholder="operator@warzone.gg"
              placeholderTextColor={colors.textDim}
            />

            <Text style={styles.label}>USERNAME</Text>
            <TextInput
              style={styles.input}
              value={username}
              onChangeText={setUsername}
              autoCapitalize="none"
              placeholder="ghost_actual"
              placeholderTextColor={colors.textDim}
            />

            <Text style={styles.label}>DISPLAY NAME (OPTIONAL)</Text>
            <TextInput
              style={styles.input}
              value={displayName}
              onChangeText={setDisplayName}
              placeholder="Ghost"
              placeholderTextColor={colors.textDim}
            />

            <Text style={styles.label}>PASSWORD</Text>
            <TextInput
              style={styles.input}
              value={password}
              onChangeText={setPassword}
              secureTextEntry
              placeholder="At least 8 characters"
              placeholderTextColor={colors.textDim}
            />

            {error ? <Text style={styles.error}>{error}</Text> : null}

            <Button
              label="CREATE ACCOUNT"
              onPress={onSubmit}
              loading={loading}
              size="lg"
              style={styles.cta}
            />
          </View>

          <View style={styles.footer}>
            <Text style={styles.footerText}>Already have an account?</Text>
            <Pressable onPress={() => navigation.navigate('Login')} hitSlop={8}>
              <Text style={styles.footerLink}>Sign in</Text>
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  flex: { flex: 1 },
  content: { flexGrow: 1, padding: spacing.xxl, justifyContent: 'center', gap: spacing.xl },
  brand: { gap: spacing.xs },
  kicker: {
    color: colors.textMuted,
    fontSize: fontSize.caption,
    fontWeight: fontWeight.bold,
    letterSpacing: 3,
  },
  title: {
    color: colors.text,
    fontSize: fontSize.h1,
    fontWeight: fontWeight.heavy,
    letterSpacing: 2,
  },
  titleAccent: {
    color: colors.primary,
    fontSize: fontSize.h1,
    fontWeight: fontWeight.heavy,
    letterSpacing: 2,
  },
  form: { gap: spacing.xs },
  label: {
    color: colors.textMuted,
    fontSize: fontSize.micro,
    fontWeight: fontWeight.bold,
    letterSpacing: 1.5,
    marginTop: spacing.md,
  },
  input: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    color: colors.text,
    fontSize: fontSize.bodyLg,
  },
  error: { color: colors.danger, fontSize: fontSize.small, marginTop: spacing.sm },
  cta: { marginTop: spacing.lg },
  footer: { flexDirection: 'row', justifyContent: 'center', gap: spacing.sm },
  footerText: { color: colors.textMuted, fontSize: fontSize.body },
  footerLink: { color: colors.primary, fontSize: fontSize.body, fontWeight: fontWeight.bold },
});
