import React, { useCallback, useMemo, useState } from 'react';
import { Pressable, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';

import { Screen } from '../components/Screen';
import { Card } from '../components/Card';
import { ChallengeRow } from '../components/ChallengeRow';
import { LoadingState, ErrorState, EmptyState } from '../components/StateViews';
import {
  useAllCamoChallenges,
  useCallingCards,
  useEvents,
} from '../hooks/queries';
import { colors, fontSize, fontWeight, radius, spacing } from '../theme';
import { requirementLabel } from '../lib/format';
import type { RootStackParamList } from '../navigation/types';

type Nav = NativeStackNavigationProp<RootStackParamList>;

type FilterKey = 'ALL' | 'CAMOS' | 'CALLING_CARDS' | 'EVENTS' | 'NEAR' | 'COMPLETED';
type Kind = 'CAMO' | 'CALLING_CARD' | 'EVENT';

interface UnifiedChallenge {
  id: string;
  kind: Kind;
  title: string;
  subtitle?: string;
  current: number;
  target: number;
  progressPct: number;
  completed: boolean;
  accent: string;
  onPress?: () => void;
}

const FILTERS: { key: FilterKey; label: string }[] = [
  { key: 'ALL', label: 'All' },
  { key: 'CAMOS', label: 'Camos' },
  { key: 'CALLING_CARDS', label: 'Calling Cards' },
  { key: 'EVENTS', label: 'Events' },
  { key: 'NEAR', label: 'Near Completion' },
  { key: 'COMPLETED', label: 'Completed' },
];

const KIND_COLOR: Record<Kind, string> = {
  CAMO: colors.tierGold,
  CALLING_CARD: colors.info,
  EVENT: colors.tierMastery,
};

export function ChallengesScreen() {
  const navigation = useNavigation<Nav>();
  const [filter, setFilter] = useState<FilterKey>('ALL');

  const camos = useAllCamoChallenges();
  const callingCards = useCallingCards();
  const events = useEvents();

  const onRefresh = useCallback(() => {
    camos.refetch();
    callingCards.refetch();
    events.refetch();
  }, [camos, callingCards, events]);

  const isRefreshing = camos.isRefetching || callingCards.isRefetching || events.isRefetching;
  const isLoading = camos.isLoading || callingCards.isLoading || events.isLoading;

  const all: UnifiedChallenge[] = useMemo(() => {
    const list: UnifiedChallenge[] = [];

    (camos.data ?? []).forEach((c) => {
      list.push({
        id: `camo-${c.id}`,
        kind: 'CAMO',
        title: c.camo.name,
        subtitle: `${c.weaponName} · ${requirementLabel(c.requirementType)}`,
        current: c.currentValue,
        target: c.targetValue,
        progressPct: c.progressPct,
        completed: c.completed,
        accent: KIND_COLOR.CAMO,
        onPress: () => navigation.navigate('WeaponDetail', { weaponId: c.weaponId }),
      });
    });

    (callingCards.data ?? []).forEach((card) => {
      card.challenges.forEach((ch) => {
        list.push({
          id: `cc-${ch.id}`,
          kind: 'CALLING_CARD',
          title: ch.description,
          subtitle: card.name,
          current: ch.currentValue,
          target: ch.targetValue,
          progressPct: ch.progressPct,
          completed: ch.completed,
          accent: KIND_COLOR.CALLING_CARD,
          onPress: () => navigation.navigate('CallingCardDetail', { id: card.id }),
        });
      });
    });

    (events.data ?? []).forEach((ev) => {
      ev.challenges.forEach((ch) => {
        list.push({
          id: `ev-${ch.id}`,
          kind: 'EVENT',
          title: ch.name,
          subtitle: ev.name,
          current: ch.currentValue,
          target: ch.targetValue,
          progressPct: ch.progressPct,
          completed: ch.completed,
          accent: KIND_COLOR.EVENT,
          onPress: () => navigation.navigate('EventDetail', { id: ev.id }),
        });
      });
    });

    return list;
  }, [camos.data, callingCards.data, events.data, navigation]);

  const filtered = useMemo(() => {
    let list = all;
    if (filter === 'CAMOS') list = list.filter((c) => c.kind === 'CAMO');
    else if (filter === 'CALLING_CARDS') list = list.filter((c) => c.kind === 'CALLING_CARD');
    else if (filter === 'EVENTS') list = list.filter((c) => c.kind === 'EVENT');
    else if (filter === 'NEAR')
      list = list.filter((c) => !c.completed && c.progressPct >= 50).sort((a, b) => b.progressPct - a.progressPct);
    else if (filter === 'COMPLETED') list = list.filter((c) => c.completed);

    if (filter === 'ALL') {
      list = [...list].sort((a, b) => Number(a.completed) - Number(b.completed) || b.progressPct - a.progressPct);
    }
    return list;
  }, [all, filter]);

  const completedCount = all.filter((c) => c.completed).length;
  const nearCount = all.filter((c) => !c.completed && c.progressPct >= 50).length;

  if (isLoading && all.length === 0) {
    return <LoadingState label="Loading challenges…" />;
  }
  if (camos.isError && callingCards.isError && events.isError && all.length === 0) {
    return (
      <ErrorState
        message="Unable to load challenges."
        onRetry={onRefresh}
      />
    );
  }

  return (
    <Screen
      scroll
      contentStyle={styles.content}
      refreshControl={
        <RefreshControl refreshing={isRefreshing} onRefresh={onRefresh} tintColor={colors.primary} />
      }
    >
      <View style={styles.header}>
        <Text style={styles.kicker}>OBJECTIVES</Text>
        <Text style={styles.title}>Challenges</Text>
        <View style={styles.summaryRow}>
          <Summary label="Tracked" value={all.length} color={colors.text} />
          <Summary label="Near" value={nearCount} color={colors.primary} />
          <Summary label="Complete" value={completedCount} color={colors.success} />
        </View>
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.filterRow}
      >
        {FILTERS.map((f) => {
          const active = f.key === filter;
          return (
            <Pressable
              key={f.key}
              onPress={() => setFilter(f.key)}
              style={[styles.chip, active && styles.chipActive]}
            >
              <Text style={[styles.chipText, active && styles.chipTextActive]}>{f.label}</Text>
            </Pressable>
          );
        })}
      </ScrollView>

      <Card padded={false} style={styles.listCard}>
        <View style={styles.listInner}>
          {filtered.length === 0 ? (
            <EmptyState
              title="Nothing here"
              message="No challenges match this filter yet."
            />
          ) : (
            filtered.map((c) => (
              <Pressable key={c.id} onPress={c.onPress} disabled={!c.onPress}>
                <ChallengeRow
                  title={c.title}
                  subtitle={c.subtitle}
                  current={c.current}
                  target={c.target}
                  progressPct={c.progressPct}
                  completed={c.completed}
                  accent={c.accent}
                  trailing={
                    <View style={styles.kindRow}>
                      <View style={[styles.kindDot, { backgroundColor: c.accent }]} />
                      <Text style={styles.kindLabel}>
                        {c.kind === 'CALLING_CARD' ? 'CALLING CARD' : c.kind}
                      </Text>
                      {c.onPress ? (
                        <Ionicons name="chevron-forward" size={12} color={colors.textDim} />
                      ) : null}
                    </View>
                  }
                />
              </Pressable>
            ))
          )}
        </View>
      </Card>
    </Screen>
  );
}

function Summary({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <View style={styles.summary}>
      <Text style={[styles.summaryValue, { color }]}>{value}</Text>
      <Text style={styles.summaryLabel}>{label.toUpperCase()}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  content: { paddingBottom: spacing.huge },
  header: { marginTop: spacing.md, gap: spacing.md },
  kicker: {
    color: colors.textMuted,
    fontSize: fontSize.caption,
    fontWeight: fontWeight.bold,
    letterSpacing: 2.5,
  },
  title: { color: colors.text, fontSize: fontSize.h1, fontWeight: fontWeight.heavy },
  summaryRow: { flexDirection: 'row', gap: spacing.xxl },
  summary: { gap: 2 },
  summaryValue: { fontSize: fontSize.h2, fontWeight: fontWeight.heavy },
  summaryLabel: {
    color: colors.textMuted,
    fontSize: fontSize.micro,
    fontWeight: fontWeight.bold,
    letterSpacing: 1.2,
  },
  filterRow: { gap: spacing.sm, paddingVertical: spacing.lg, paddingRight: spacing.lg },
  chip: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radius.pill,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
  },
  chipActive: { backgroundColor: colors.primarySoft, borderColor: colors.primary },
  chipText: { color: colors.textMuted, fontSize: fontSize.small, fontWeight: fontWeight.semibold },
  chipTextActive: { color: colors.primary },
  listCard: { padding: 0 },
  listInner: { paddingHorizontal: spacing.lg },
  kindRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs, marginTop: spacing.xs },
  kindDot: { width: 6, height: 6, borderRadius: 3 },
  kindLabel: {
    color: colors.textDim,
    fontSize: fontSize.micro,
    fontWeight: fontWeight.bold,
    letterSpacing: 1,
  },
});
