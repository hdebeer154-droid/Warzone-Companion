import React, { useCallback, useMemo, useState } from 'react';
import {
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';

import { Screen } from '../components/Screen';
import { WeaponCard } from '../components/WeaponCard';
import { LoadingState, ErrorState, EmptyState } from '../components/StateViews';
import { useWeapons, useWeaponCategories, useToggleFavourite } from '../hooks/queries';
import { colors, fontSize, fontWeight, radius, spacing } from '../theme';
import { categoryLabel } from '../lib/format';
import type { RootStackParamList } from '../navigation/types';
import type { WeaponCategory } from '../api/types';

type Nav = NativeStackNavigationProp<RootStackParamList>;
type SortKey = 'level' | 'completion' | 'recent' | 'favourite' | 'name';

const SORTS: { key: SortKey; label: string }[] = [
  { key: 'level', label: 'Level' },
  { key: 'completion', label: 'Completion' },
  { key: 'recent', label: 'Recent' },
  { key: 'favourite', label: 'Favourite' },
  { key: 'name', label: 'Name' },
];

export function WeaponsScreen() {
  const navigation = useNavigation<Nav>();
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState<WeaponCategory | 'ALL'>('ALL');
  const [sort, setSort] = useState<SortKey>('level');
  const [favouritesOnly, setFavouritesOnly] = useState(false);

  const categoriesQuery = useWeaponCategories();
  const weaponsQuery = useWeapons({
    search: search.trim() || undefined,
    category: category === 'ALL' ? undefined : category,
    sort,
    favouritesOnly: favouritesOnly || undefined,
    pageSize: 60,
  });
  const toggleFavourite = useToggleFavourite();

  const onRefresh = useCallback(() => {
    weaponsQuery.refetch();
    categoriesQuery.refetch();
  }, [weaponsQuery, categoriesQuery]);

  const categoryChips = useMemo(() => {
    const present = (categoriesQuery.data ?? [])
      .filter((c) => c.weapons > 0)
      .map((c) => c.category);
    return ['ALL', ...present] as (WeaponCategory | 'ALL')[];
  }, [categoriesQuery.data]);

  const items = weaponsQuery.data?.items ?? [];
  const total = weaponsQuery.data?.total ?? 0;

  return (
    <Screen
      scroll
      contentStyle={styles.content}
      refreshControl={
        <RefreshControl
          refreshing={weaponsQuery.isRefetching}
          onRefresh={onRefresh}
          tintColor={colors.primary}
        />
      }
    >
      <View style={styles.header}>
        <Text style={styles.kicker}>ARSENAL</Text>
        <Text style={styles.title}>Weapons</Text>
        <Text style={styles.subtitle}>
          {total} {total === 1 ? 'weapon' : 'weapons'} tracked
        </Text>
      </View>

      {/* Search */}
      <View style={styles.searchRow}>
        <Ionicons name="search" size={16} color={colors.textMuted} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search weapons"
          placeholderTextColor={colors.textDim}
          value={search}
          onChangeText={setSearch}
          autoCorrect={false}
          autoCapitalize="none"
        />
        {search.length > 0 ? (
          <Pressable onPress={() => setSearch('')} hitSlop={8}>
            <Ionicons name="close-circle" size={16} color={colors.textMuted} />
          </Pressable>
        ) : null}
      </View>

      {/* Category chips */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.chipRow}
      >
        {categoryChips.map((c) => {
          const active = c === category;
          return (
            <Pressable
              key={c}
              onPress={() => setCategory(c)}
              style={[styles.chip, active && styles.chipActive]}
            >
              <Text style={[styles.chipText, active && styles.chipTextActive]}>
                {c === 'ALL' ? 'ALL' : categoryLabel(c)}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>

      {/* Sort + favourites */}
      <View style={styles.sortRow}>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.sortScroll}
        >
          {SORTS.map((s) => {
            const active = s.key === sort;
            return (
              <Pressable
                key={s.key}
                onPress={() => setSort(s.key)}
                style={[styles.sortChip, active && styles.sortChipActive]}
              >
                <Text style={[styles.sortText, active && styles.sortTextActive]}>{s.label}</Text>
              </Pressable>
            );
          })}
        </ScrollView>
        <Pressable
          onPress={() => setFavouritesOnly((v) => !v)}
          style={[styles.favToggle, favouritesOnly && styles.favToggleActive]}
        >
          <Ionicons
            name={favouritesOnly ? 'star' : 'star-outline'}
            size={16}
            color={favouritesOnly ? colors.primary : colors.textMuted}
          />
        </Pressable>
      </View>

      {/* List */}
      {weaponsQuery.isLoading && !weaponsQuery.data ? (
        <LoadingState label="Loading weapons…" />
      ) : weaponsQuery.isError && !weaponsQuery.data ? (
        <ErrorState
          message={(weaponsQuery.error as Error)?.message ?? 'Unable to load weapons.'}
          onRetry={weaponsQuery.refetch}
        />
      ) : items.length === 0 ? (
        <EmptyState
          title="No weapons found"
          message="Try a different category, sort or search term."
        />
      ) : (
        <View style={styles.list}>
          {items.map((w) => (
            <WeaponCard
              key={w.id}
              weapon={w}
              onPress={() => navigation.navigate('WeaponDetail', { weaponId: w.id })}
              onToggleFavourite={() => toggleFavourite.mutate(w.id)}
            />
          ))}
        </View>
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { paddingBottom: spacing.huge },
  header: { marginTop: spacing.md, gap: spacing.xs },
  kicker: {
    color: colors.textMuted,
    fontSize: fontSize.caption,
    fontWeight: fontWeight.bold,
    letterSpacing: 2.5,
  },
  title: { color: colors.text, fontSize: fontSize.h1, fontWeight: fontWeight.heavy },
  subtitle: { color: colors.textMuted, fontSize: fontSize.small },
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    height: 44,
    marginTop: spacing.lg,
  },
  searchInput: { flex: 1, color: colors.text, fontSize: fontSize.body, padding: 0 },
  chipRow: { gap: spacing.sm, paddingVertical: spacing.md, paddingRight: spacing.lg },
  chip: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radius.pill,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
  },
  chipActive: { backgroundColor: colors.primarySoft, borderColor: colors.primary },
  chipText: {
    color: colors.textMuted,
    fontSize: fontSize.small,
    fontWeight: fontWeight.semibold,
  },
  chipTextActive: { color: colors.primary },
  sortRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.lg },
  sortScroll: { gap: spacing.sm, paddingRight: spacing.sm },
  sortChip: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: radius.sm,
  },
  sortChipActive: { backgroundColor: colors.surfaceElevated },
  sortText: {
    color: colors.textDim,
    fontSize: fontSize.small,
    fontWeight: fontWeight.semibold,
    letterSpacing: 0.4,
  },
  sortTextActive: { color: colors.text },
  favToggle: {
    width: 36,
    height: 32,
    borderRadius: radius.sm,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
  },
  favToggleActive: { borderColor: colors.primary, backgroundColor: colors.primarySoft },
  list: { gap: spacing.md },
});
