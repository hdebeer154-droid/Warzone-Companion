/**
 * TypeScript mirrors of the Warzone Companion backend API contract.
 *
 * These are hand-kept in sync with the NestJS DTOs/views. The mobile app only
 * ever consumes our own backend — never a protected third-party game API.
 */

export type Platform =
  | 'BATTLENET'
  | 'ACTIVISION'
  | 'STEAM'
  | 'PSN'
  | 'XBOX'
  | 'UNKNOWN';

export type SyncStatus = 'OK' | 'PENDING' | 'SYNCING' | 'ERROR' | 'NEVER';

export type WeaponCategory =
  | 'ASSAULT_RIFLE'
  | 'SMG'
  | 'SHOTGUN'
  | 'LMG'
  | 'MARKSMAN_RIFLE'
  | 'SNIPER_RIFLE'
  | 'PISTOL'
  | 'MELEE'
  | 'LAUNCHER'
  | 'OTHER';

export type ProgressSource = 'API' | 'OCR' | 'MANUAL' | 'CALCULATED';

export type ActivityType =
  | 'CAMO_PROGRESS'
  | 'CAMO_COMPLETED'
  | 'WEAPON_LEVEL'
  | 'MATCH_COMPLETED'
  | 'CALLING_CARD_PROGRESS'
  | 'CALLING_CARD_COMPLETED'
  | 'EVENT_PROGRESS'
  | 'EVENT_COMPLETED'
  | 'PLAYER_LEVEL'
  | 'PRESTIGE'
  | 'SYNC'
  | 'OBJECTIVE'
  | 'SYSTEM';

export type ObjectiveType =
  | 'CAMO'
  | 'CALLING_CARD'
  | 'EVENT'
  | 'WEAPON_LEVEL'
  | 'CUSTOM'
  | 'OTHER';

export type ObjectiveStatus = 'ACTIVE' | 'COMPLETED' | 'PAUSED' | 'ARCHIVED';

export type NotificationCategory =
  | 'CAMO_COMPLETED'
  | 'WEAPON_LEVEL'
  | 'EVENT_ENDING_SOON'
  | 'CHALLENGE_COMPLETED'
  | 'NEW_EVENT'
  | 'NEW_SEASON'
  | 'SYNC_FAILURE';

/** Standard response envelope. */
export interface ApiEnvelope<T> {
  success: boolean;
  data: T;
}

export interface ApiError {
  success: false;
  statusCode: number;
  code?: string;
  message: string | string[];
  path?: string;
  timestamp?: string;
}

export interface Page<T> {
  items: T[];
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
  hasMore: boolean;
}

// ── Auth ────────────────────────────────────────────────────────────────────
export interface AuthUser {
  id: string;
  email: string;
  username: string;
  displayName: string;
  avatarUrl: string | null;
  role: 'USER' | 'ADMIN';
  createdAt?: string;
}

export interface AuthSession {
  user: AuthUser;
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}

// ── Profile ─────────────────────────────────────────────────────────────────
export interface PlayerStats {
  totalMatches: number;
  wins: number;
  top5: number;
  kills: number;
  deaths: number;
  assists: number;
  damage: number;
  xp: number;
  kd: number;
  winRate: number;
  avgPlacement: number;
}

export interface RecentMatch {
  id: string;
  kills: number;
  deaths: number;
  placement: number;
  damage: number;
  xp: number;
  mode: string;
  map: string;
  startedAt: string;
}

export interface ProfileView {
  identity: AuthUser;
  player: { level: number; prestige: number; xp: number };
  codUsername: string | null;
  platform: Platform | null;
  stats: PlayerStats;
  recentPerformance: { matches: RecentMatch[] };
  accounts: CodAccount[];
  sync: SyncState | null;
}

// ── Accounts & Sync ───────────────────────────────────────────────────────────
export interface CodAccount {
  id: string;
  userId: string;
  activisionUserId: string | null;
  activisionUsername: string | null;
  platform: Platform;
  platformUsername: string | null;
  syncStatus: SyncStatus;
  syncError: string | null;
  lastSyncAt: string | null;
  lastSyncHuman?: string;
  providerKey?: string;
}

export interface SyncState {
  id: string;
  providerKey: string;
  platform: Platform;
  activisionUsername: string | null;
  syncStatus: SyncStatus;
  lastSyncAt: string | null;
  lastSyncHuman: string;
  syncError: string | null;
}

export interface ProviderHealth {
  id: string;
  providerKey: string;
  healthy: boolean;
  lastCheckedAt: string | null;
  lastError: string | null;
  latencyMs: number | null;
  consecutiveFailures: number;
}

export interface SyncResult {
  accountId: string;
  providerKey: string;
  status: 'OK' | 'PARTIAL' | 'ERROR';
  changes: number;
  summary: Record<string, number>;
  error?: string;
  lastSyncAt?: string;
}

export interface SyncRunSummary {
  queued: boolean;
  results: SyncResult[];
}

// ── Weapons ───────────────────────────────────────────────────────────────────
export interface WeaponView {
  id: string;
  name: string;
  slug: string;
  category: WeaponCategory;
  imageUrl: string | null;
  maxLevel: number;
  isDlc: boolean;
  level: number;
  xp: number;
  xpIntoLevel: number;
  xpForNextLevel: number;
  xpToNextLevel: number;
  levelProgressPct: number;
  kills: number;
  headshots: number;
  matches: number;
  camoCompleted: number;
  camoTotal: number;
  camoCompletionPct: number;
  favourite: boolean;
  lastUpdatedAt: string | null;
}

export interface WeaponLevelInfo {
  level: number;
  xpRequired: number;
  rewardName: string | null;
  rewardType: string | null;
  unlocked: boolean;
}

export interface CamoChallengeView {
  id: string;
  description: string;
  requirementType: string;
  targetValue: number;
  gameMode: string | null;
  camo: {
    id: string;
    name: string;
    imageUrl: string | null;
    rarity: string;
    set: string;
    setCategory: string;
  };
  currentValue: number;
  completed: boolean;
  source: ProgressSource;
  progressPct: number;
}

export interface WeaponDetailView extends WeaponView {
  levels: WeaponLevelInfo[];
  camoChallenges: CamoChallengeView[];
}

export interface WeaponCategorySummary {
  category: WeaponCategory;
  weapons: number;
  camoCompleted: number;
  camoTotal: number;
  completionPct: number;
}

// ── Camos ─────────────────────────────────────────────────────────────────────
export interface CamoProgressBucket {
  completed: number;
  total: number;
  completionPct: number;
}

export interface CamoOverview {
  overall: CamoProgressBucket;
  byCategory: (CamoProgressBucket & { category: WeaponCategory })[];
}

export interface CamoSetSummary {
  id: string;
  name: string;
  category: string;
  orderIndex: number;
  camoCount: number;
  completed: number;
  total: number;
  completionPct: number;
  camos: {
    id: string;
    name: string;
    imageUrl: string | null;
    rarity: string;
    challengeCount: number;
    completed: number;
  }[];
}

// ── Calling cards ─────────────────────────────────────────────────────────────
export interface ChallengeProgressView {
  id: string;
  description: string;
  requirementType: string;
  targetValue: number;
  currentValue: number;
  completed: boolean;
  source: ProgressSource;
  progressPct: number;
}

export interface CallingCardView {
  id: string;
  name: string;
  category: string;
  description: string | null;
  imageUrl: string | null;
  completed: number;
  total: number;
  completionPct: number;
  unlocked: boolean;
  challenges: ChallengeProgressView[];
}

// ── Events ────────────────────────────────────────────────────────────────────
export interface EventReward {
  id: string;
  name: string;
  imageUrl: string | null;
  rewardType: string;
}

export interface EventChallengeView {
  id: string;
  name: string;
  description: string;
  requirementType: string;
  targetValue: number;
  currentValue: number;
  completed: boolean;
  progressPct: number;
  reward: EventReward | null;
}

export interface EventView {
  id: string;
  name: string;
  description: string | null;
  imageUrl: string | null;
  startDate: string;
  endDate: string;
  active: boolean;
  timeRemaining: { ms: number; human: string; endingSoon: boolean };
  completed: number;
  total: number;
  completionPct: number;
  challenges: EventChallengeView[];
}

// ── Matches ───────────────────────────────────────────────────────────────────
export interface MatchWeaponStat {
  weapon: { id: string; name: string; slug: string; category: WeaponCategory };
  kills: number;
  headshots: number;
  damage: number;
}

export interface MatchView {
  id: string;
  externalMatchId: string;
  mode: string;
  map: string;
  playlist: string | null;
  startedAt: string | null;
  endedAt: string | null;
  kills: number;
  deaths: number;
  assists: number;
  placement: number;
  damage: number;
  xp: number;
  kd: number;
  weaponStats: MatchWeaponStat[];
}

// ── Activity ──────────────────────────────────────────────────────────────────
export interface ActivityItem {
  id: string;
  userId: string;
  type: ActivityType;
  title: string;
  description: string | null;
  metadata: Record<string, unknown> | null;
  createdAt: string;
  readAt: string | null;
}

// ── Objectives ────────────────────────────────────────────────────────────────
export interface ObjectiveView {
  id: string;
  type: ObjectiveType;
  label: string;
  priority: number;
  status: ObjectiveStatus;
  weaponId: string | null;
  weaponName: string | null;
  current: number;
  target: number;
  remaining: number;
  progressPct: number;
  metadata: Record<string, unknown> | null;
}

export interface ObjectiveOverlap {
  weaponId: string;
  weaponName: string;
  objectives: ObjectiveView[];
  count: number;
}

// ── Dashboard ─────────────────────────────────────────────────────────────────
export interface DashboardView {
  header: {
    appName: string;
    displayName: string;
    username: string;
    avatarUrl: string | null;
    playerLevel: number;
    prestige: number;
    overallProgressionPct: number;
  };
  nextObjectives: ObjectiveView[];
  weaponCard: {
    id: string;
    name: string;
    category: WeaponCategory;
    imageUrl: string | null;
    level: number;
    nextLevel: number;
    levelProgressPct: number;
    xpToNextLevel: number;
    camoCompletionPct: number;
  } | null;
  callingCard: {
    id: string;
    name: string;
    completed: number;
    total: number;
    completionPct: number;
  } | null;
  event: {
    id: string;
    name: string;
    completionPct: number;
    timeRemaining: { ms: number; human: string; endingSoon: boolean };
    endDate: string;
  } | null;
  recentActivity: ActivityItem[];
  sync: SyncState | null;
}

// ── Notifications ─────────────────────────────────────────────────────────────
export interface NotificationPreference {
  category: NotificationCategory;
  enabled: boolean;
}

// ── OCR ───────────────────────────────────────────────────────────────────────
export type OcrStatus =
  | 'PENDING'
  | 'PROCESSING'
  | 'AWAITING_CONFIRMATION'
  | 'REVIEW'
  | 'APPLIED'
  | 'REJECTED'
  | 'FAILED';

export type DetectionKind =
  | 'WEAPON_LEVEL'
  | 'CAMO_PROGRESS'
  | 'EVENT_PROGRESS'
  | 'CALLING_CARD_PROGRESS'
  | 'PLAYER_LEVEL';

export interface OcrDetection {
  kind: DetectionKind;
  rawText: string;
  weaponId?: string;
  weaponName?: string;
  camoId?: string;
  camoName?: string;
  requirementType?: string;
  currentValue?: number;
  targetValue?: number;
  level?: number;
  confidence: number;
  matched: boolean;
}

export interface OcrScanView {
  id: string;
  userId: string;
  status: OcrStatus;
  imageUrl: string | null;
  rawText: string | null;
  detections: OcrDetection[] | null;
  appliedCount: number;
  error: string | null;
  createdAt: string;
  updatedAt: string;
  /** Present on the initial scan response. */
  threshold?: number;
}


// ── Catalog ───────────────────────────────────────────────────────────────────
export interface GameView {
  id: string;
  name: string;
  slug: string;
  active: boolean;
  imageUrl: string | null;
}

export interface SeasonView {
  id: string;
  name: string;
  number: number;
  active: boolean;
  startDate: string | null;
  endDate: string | null;
  gameId: string;
}
