import { API_BASE_URL, REQUEST_TIMEOUT } from './config';
import { tokenStore } from '../lib/tokenStore';
import type { ApiEnvelope, AuthSession } from './types';

export class ApiError extends Error {
  status: number;
  code?: string;
  details?: unknown;

  constructor(message: string, status: number, code?: string, details?: unknown) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

export interface RequestOptions {
  method?: 'GET' | 'POST' | 'PATCH' | 'PUT' | 'DELETE';
  body?: unknown;
  /** Skip the Authorization header (used by auth endpoints). */
  auth?: boolean;
  /** Skip the automatic refresh-on-401 behaviour. */
  skipRefresh?: boolean;
  signal?: AbortSignal;
}

type Listener = () => void;
const unauthorizedListeners = new Set<Listener>();

/** Subscribe to "session expired" events so the UI can redirect to login. */
export function onUnauthorized(listener: Listener): () => void {
  unauthorizedListeners.add(listener);
  return () => unauthorizedListeners.delete(listener);
}

function emitUnauthorized(): void {
  unauthorizedListeners.forEach((l) => {
    try {
      l();
    } catch {
      // ignore listener errors
    }
  });
}

let refreshPromise: Promise<boolean> | null = null;

async function performRefresh(): Promise<boolean> {
  const { refreshToken } = await tokenStore.load();
  if (!refreshToken) return false;
  try {
    const res = await fetch(`${API_BASE_URL}/auth/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken }),
    });
    if (!res.ok) return false;
    const json = (await res.json()) as ApiEnvelope<AuthSession>;
    if (!json.success || !json.data?.accessToken) return false;
    await tokenStore.save(json.data.accessToken, json.data.refreshToken);
    return true;
  } catch {
    return false;
  }
}

/** Single-flight refresh so concurrent 401s trigger only one refresh call. */
async function refreshSession(): Promise<boolean> {
  if (!refreshPromise) {
    refreshPromise = performRefresh().finally(() => {
      refreshPromise = null;
    });
  }
  return refreshPromise;
}

function buildUrl(path: string): string {
  if (/^https?:\/\//.test(path)) return path;
  return `${API_BASE_URL}${path.startsWith('/') ? path : `/${path}`}`;
}

async function parseError(res: Response): Promise<ApiError> {
  let message = `Request failed (${res.status})`;
  let code: string | undefined;
  let details: unknown;
  try {
    const json = await res.json();
    details = json;
    // Nest's global exception filter returns { error: { message, code, ... } },
    // while a few endpoints may return the fields at the top level.
    const apiError = json?.error && typeof json.error === 'object' ? json.error : json;
    code = apiError?.code;
    const m = apiError?.message;
    if (Array.isArray(m)) message = m.join(', ');
    else if (typeof m === 'string') message = m;
  } catch {
    // non-JSON body
  }
  return new ApiError(message, res.status, code, details);
}

export async function request<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const { method = 'GET', body, auth = true, skipRefresh = false, signal } = options;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT);
  const onAbort = () => controller.abort();
  if (signal) signal.addEventListener('abort', onAbort);

  const headers: Record<string, string> = { Accept: 'application/json' };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (auth) {
    const { accessToken } = await tokenStore.load();
    if (accessToken) headers.Authorization = `Bearer ${accessToken}`;
  }

  let res: Response;
  try {
    res = await fetch(buildUrl(path), {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    });
  } catch (err) {
    clearTimeout(timeout);
    if (signal) signal.removeEventListener('abort', onAbort);
    if ((err as Error)?.name === 'AbortError') {
      throw new ApiError('The request timed out. Check your connection and try again.', 0, 'TIMEOUT');
    }
    throw new ApiError('Network unavailable. Showing your last synced data.', 0, 'NETWORK');
  } finally {
    clearTimeout(timeout);
    if (signal) signal.removeEventListener('abort', onAbort);
  }

  if (res.status === 401 && auth && !skipRefresh) {
    const refreshed = await refreshSession();
    if (refreshed) {
      return request<T>(path, { ...options, skipRefresh: true });
    }
    await tokenStore.clear();
    emitUnauthorized();
    throw new ApiError('Your session has expired. Please sign in again.', 401, 'UNAUTHORIZED');
  }

  if (!res.ok) {
    throw await parseError(res);
  }

  if (res.status === 204) {
    return undefined as T;
  }

  const json = (await res.json()) as ApiEnvelope<T> | T;
  if (json && typeof json === 'object' && 'success' in (json as object) && 'data' in (json as object)) {
    return (json as ApiEnvelope<T>).data;
  }
  return json as T;
}

export const api = {
  get: <T>(path: string, opts?: Omit<RequestOptions, 'method' | 'body'>) =>
    request<T>(path, { ...opts, method: 'GET' }),
  post: <T>(path: string, body?: unknown, opts?: Omit<RequestOptions, 'method' | 'body'>) =>
    request<T>(path, { ...opts, method: 'POST', body }),
  patch: <T>(path: string, body?: unknown, opts?: Omit<RequestOptions, 'method' | 'body'>) =>
    request<T>(path, { ...opts, method: 'PATCH', body }),
  del: <T>(path: string, opts?: Omit<RequestOptions, 'method' | 'body'>) =>
    request<T>(path, { ...opts, method: 'DELETE' }),
  postForm: <T>(path: string, form: FormData) => requestMultipart<T>(path, form),
};

/**
 * Multipart upload (used for OCR screenshots).
 * Does not set Content-Type so the runtime can attach the multipart boundary.
 */
async function requestMultipart<T>(path: string, form: FormData, retry = false): Promise<T> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT * 2);

  const headers: Record<string, string> = { Accept: 'application/json' };
  const { accessToken } = await tokenStore.load();
  if (accessToken) headers.Authorization = `Bearer ${accessToken}`;

  let res: Response;
  try {
    res = await fetch(buildUrl(path), { method: 'POST', headers, body: form, signal: controller.signal });
  } catch (err) {
    if ((err as Error)?.name === 'AbortError') {
      throw new ApiError('The upload timed out. Try a smaller screenshot.', 0, 'TIMEOUT');
    }
    throw new ApiError('Network unavailable. Please try again.', 0, 'NETWORK');
  } finally {
    clearTimeout(timeout);
  }

  if (res.status === 401 && !retry) {
    const refreshed = await refreshSession();
    if (refreshed) return requestMultipart<T>(path, form, true);
    await tokenStore.clear();
    emitUnauthorized();
    throw new ApiError('Your session has expired. Please sign in again.', 401, 'UNAUTHORIZED');
  }

  if (!res.ok) throw await parseError(res);
  if (res.status === 204) return undefined as T;

  const json = (await res.json()) as ApiEnvelope<T> | T;
  if (json && typeof json === 'object' && 'success' in (json as object) && 'data' in (json as object)) {
    return (json as ApiEnvelope<T>).data;
  }
  return json as T;
}
