import { api } from './client';
import type {
  ActivityItem,
  AuthSession,
  AuthUser,
  CallingCardView,
  CamoChallengeView,
  CamoOverview,
  CamoSetSummary,
  CodAccount,
  DashboardView,
  EventView,
  MatchView,
  NotificationCategory,
  NotificationPreference,
  ObjectiveOverlap,
  ObjectiveView,
  OcrDetection,
  OcrScanView,
  Page,
  PlayerStats,
  ProfileView,
  ProviderHealth,
  SyncResult,
  SyncRunSummary,
  WeaponCategorySummary,
  WeaponDetailView,
  WeaponView,
} from './types';

// ── Auth ──────────────────────────────────────────────────────────────────────
export const authApi = {
  login: (email: string, password: string) =>
    api.post<AuthSession>('/auth/login', { email, password }, { auth: false }),
  register: (input: { email: string; username: string; password: string; displayName?: string }) =>
    api.post<AuthSession>('/auth/register', input, { auth: false }),
  me: () => api.get<AuthUser>('/auth/me'),
  logout: (refreshToken: string) => api.post<void>('/auth/logout', { refreshToken }, { auth: false }),
  logoutAll: () => api.post<void>('/auth/logout-all'),
  forgotPassword: (email: string) => api.post<{ sent: boolean }>('/auth/forgot-password', { email }, { auth: false }),
  resetPassword: (token: string, password: string) =>
    api.post<{ reset: boolean }>('/auth/reset-password', { token, password }, { auth: false }),
  changePassword: (currentPassword: string, newPassword: string) =>
    api.post<{ changed: boolean }>('/auth/change-password', { currentPassword, newPassword }),
  updateProfile: (input: { displayName?: string; avatarUrl?: string }) =>
    api.patch<AuthUser>('/auth/me', input),
};

// ── Dashboard ─────────────────────────────────────────────────────────────────
export const dashboardApi = {
  get: () => api.get<DashboardView>('/dashboard'),
};

// ── Profile ───────────────────────────────────────────────────────────────────
export const profileApi = {
  get: () => api.get<ProfileView>('/profile'),
};

// ── Weapons ───────────────────────────────────────────────────────────────────
export interface WeaponQuery {
  category?: string;
  search?: string;
  sort?: 'level' | 'completion' | 'recent' | 'favourite' | 'name';
  favouritesOnly?: boolean;
  page?: number;
  pageSize?: number;
}

function toQuery(params: object): string {
  const usp = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v === undefined || v === null || v === '') return;
    usp.append(k, String(v));
  });
  const q = usp.toString();
  return q ? `?${q}` : '';
}

export const weaponsApi = {
  list: (query: WeaponQuery = {}) => api.get<Page<WeaponView>>(`/weapons${toQuery(query)}`),
  categories: () => api.get<WeaponCategorySummary[]>('/weapons/categories'),
  detail: (id: string) => api.get<WeaponDetailView>(`/weapons/${id}`),
  toggleFavourite: (id: string) => api.post<{ favourite: boolean }>(`/weapons/${id}/favourite`),
  updateProgress: (id: string, input: { level?: number; xp?: number; kills?: number; headshots?: number }) =>
    api.patch<WeaponView>(`/weapons/${id}/progress`, input),
};

// ── Camos ─────────────────────────────────────────────────────────────────────
export const camosApi = {
  overview: () => api.get<CamoOverview>('/camos/overview'),
  sets: () => api.get<CamoSetSummary[]>('/camos/sets'),
  weaponCamos: (weaponId: string) => api.get<CamoChallengeView[]>(`/camos/weapons/${weaponId}`),
  updateProgress: (challengeId: string, currentValue: number, source?: string) =>
    api.patch<CamoChallengeView>(`/camos/progress/${challengeId}`, { currentValue, source }),
};

// ── Calling cards ─────────────────────────────────────────────────────────────
export const callingCardsApi = {
  list: () => api.get<CallingCardView[]>('/calling-cards'),
  detail: (id: string) => api.get<CallingCardView>(`/calling-cards/${id}`),
};

// ── Events ────────────────────────────────────────────────────────────────────
export const eventsApi = {
  list: () => api.get<EventView[]>('/events'),
  detail: (id: string) => api.get<EventView>(`/events/${id}`),
};

// ── Matches ───────────────────────────────────────────────────────────────────
export const matchesApi = {
  list: (page = 1, pageSize = 20) =>
    api.get<Page<MatchView>>(`/matches?page=${page}&pageSize=${pageSize}`),
  detail: (id: string) => api.get<MatchView>(`/matches/${id}`),
  stats: () => api.get<PlayerStats>('/matches/stats'),
};

// ── Activity ──────────────────────────────────────────────────────────────────
export const activityApi = {
  list: (page = 1, pageSize = 30) =>
    api.get<Page<ActivityItem>>(`/activity?page=${page}&pageSize=${pageSize}`),
  unreadCount: () => api.get<{ count: number }>('/activity/unread-count'),
  markRead: (id: string) => api.post<{ ok: boolean }>(`/activity/${id}/read`),
  markAllRead: () => api.post<{ ok: boolean }>('/activity/read-all'),
};

// ── Objectives ────────────────────────────────────────────────────────────────
export const objectivesApi = {
  list: () => api.get<{ objectives: ObjectiveView[] }>('/objectives'),
  overlaps: () => api.get<ObjectiveOverlap[]>('/objectives/overlaps'),
  recompute: () => api.post<{ objectives: ObjectiveView[] }>('/objectives/recompute'),
  create: (input: { label: string; target: number; type?: string }) =>
    api.post<ObjectiveView>('/objectives', input),
  setStatus: (id: string, status: string) => api.patch<ObjectiveView>(`/objectives/${id}`, { status }),
};

// ── Accounts & Sync ───────────────────────────────────────────────────────────
export const accountsApi = {
  list: () => api.get<CodAccount[]>('/accounts'),
  link: (input: { platform: string; activisionUsername: string; activisionUserId?: string }) =>
    api.post<CodAccount>('/accounts', input),
  unlink: (id: string) => api.del<{ ok: boolean }>(`/accounts/${id}`),
};

export const syncApi = {
  run: (accountId?: string) => api.post<SyncRunSummary>('/sync', accountId ? { accountId } : {}),
  runs: () => api.get<SyncResult[]>('/sync/runs'),
  providers: () => api.get<ProviderHealth[]>('/sync/providers/health'),
  queues: () => api.get<Record<string, { waiting: number; active: number; failed: number }>>('/sync/queues'),
};

// ── Notifications ─────────────────────────────────────────────────────────────
export const notificationsApi = {
  preferences: () => api.get<NotificationPreference[]>('/notifications/preferences'),
  setPreference: (category: NotificationCategory, enabled: boolean) =>
    api.patch<NotificationPreference>(`/notifications/preferences`, { category, enabled }),
  registerPushToken: (token: string, platform: string) =>
    api.post<{ ok: boolean }>('/notifications/push-token', { token, platform }),
};

// ── OCR ───────────────────────────────────────────────────────────────────────
export interface ImageUpload {
  uri: string;
  name: string;
  type: string;
}

export const ocrApi = {
  /** Upload a screenshot (multipart/form-data) for scanning. */
  scan: (image: ImageUpload) => {
    const form = new FormData();
    // React Native's FormData accepts { uri, name, type } for file parts.
    form.append('image', image as unknown as Blob);
    return api.postForm<OcrScanView>('/ocr/scan', form);
  },
  /** Deterministic scan from raw text (used for demos / manual entry). */
  scanText: (text: string) => {
    const form = new FormData();
    form.append('text', text);
    return api.postForm<OcrScanView>('/ocr/scan', form);
  },
  list: (page = 1, pageSize = 20) =>
    api.get<Page<OcrScanView>>(`/ocr/scans?page=${page}&pageSize=${pageSize}`),
  get: (id: string) => api.get<OcrScanView>(`/ocr/scans/${id}`),
  confirm: (id: string, detections?: OcrDetection[]) =>
    api.post<OcrScanView>(`/ocr/scans/${id}/confirm`, detections ? { detections } : {}),
  reject: (id: string) => api.post<OcrScanView>(`/ocr/scans/${id}/reject`),
};

export { toQuery };
