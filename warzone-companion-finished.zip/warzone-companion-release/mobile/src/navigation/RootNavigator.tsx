import React from 'react';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { colors } from '../theme';
import { useAuth } from '../context/AuthContext';
import { LoadingState } from '../components/StateViews';
import type { RootStackParamList } from './types';
import { MainTabs } from './MainTabs';
import { LoginScreen } from '../screens/LoginScreen';
import { RegisterScreen } from '../screens/RegisterScreen';
import { ScannerScreen } from '../screens/ScannerScreen';
import { WeaponDetailScreen } from '../screens/WeaponDetailScreen';
import { MatchDetailScreen } from '../screens/MatchDetailScreen';
import { CallingCardDetailScreen } from '../screens/CallingCardDetailScreen';
import { EventDetailScreen } from '../screens/EventDetailScreen';

const Stack = createNativeStackNavigator<RootStackParamList>();

const navTheme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    background: colors.background,
    card: colors.backgroundAlt,
    border: colors.border,
    primary: colors.primary,
    text: colors.text,
  },
};

export function RootNavigator() {
  const { status } = useAuth();

  if (status === 'loading') {
    return <LoadingState label="Preparing Warzone Companion…" />;
  }

  return (
    <NavigationContainer theme={navTheme}>
      <Stack.Navigator
        screenOptions={{
          headerStyle: { backgroundColor: colors.backgroundAlt },
          headerTintColor: colors.text,
          headerTitleStyle: { fontWeight: '700' },
          contentStyle: { backgroundColor: colors.background },
        }}
      >
        {status === 'authenticated' ? (
          <>
            <Stack.Screen name="Tabs" component={MainTabs} options={{ headerShown: false }} />
            <Stack.Screen name="Scanner" component={ScannerScreen} options={{ title: 'Scan Progress' }} />
            <Stack.Screen
              name="WeaponDetail"
              component={WeaponDetailScreen}
              options={{ title: 'Weapon' }}
            />
            <Stack.Screen
              name="MatchDetail"
              component={MatchDetailScreen}
              options={{ title: 'Match' }}
            />
            <Stack.Screen
              name="CallingCardDetail"
              component={CallingCardDetailScreen}
              options={{ title: 'Calling Card' }}
            />
            <Stack.Screen
              name="EventDetail"
              component={EventDetailScreen}
              options={{ title: 'Event' }}
            />
          </>
        ) : (
          <>
            <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
            <Stack.Screen name="Register" component={RegisterScreen} options={{ headerShown: false }} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
