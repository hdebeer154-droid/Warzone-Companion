import type { WeaponCategory } from '../api/types';
import { colors } from '../theme';

export const CATEGORY_LABEL: Record<WeaponCategory, string> = {
  ASSAULT_RIFLE: 'Assault Rifle',
  SMG: 'SMG',
  SHOTGUN: 'Shotgun',
  LMG: 'LMG',
  MARKSMAN_RIFLE: 'Marksman Rifle',
  SNIPER_RIFLE: 'Sniper',
  PISTOL: 'Pistol',
  MELEE: 'Melee',
  LAUNCHER: 'Launcher',
  OTHER: 'Other',
};

export const CATEGORY_SHORT: Record<WeaponCategory, string> = {
  ASSAULT_RIFLE: 'AR',
  SMG: 'SMG',
  SHOTGUN: 'SG',
  LMG: 'LMG',
  MARKSMAN_RIFLE: 'MR',
  SNIPER_RIFLE: 'SR',
  PISTOL: 'PIST',
  MELEE: 'MELEE',
  LAUNCHER: 'LNCH',
  OTHER: 'OTHER',
};

export function categoryLabel(category: WeaponCategory | string): string {
  return CATEGORY_LABEL[category as WeaponCategory] ?? String(category);
}

/** Human-readable label for a challenge requirement type. */
export function requirementLabel(type: string): string {
  const map: Record<string, string> = {
    KILLS: 'Kills',
    HEADSHOTS: 'Headshots',
    LONGSHOTS: 'Longshot kills',
    ADS_KILLS: 'ADS kills',
    HIPFIRE_KILLS: 'Hipfire kills',
    KILLS_AFTER_RELOAD: 'Kills after reload',
    POINT_BLANK_KILLS: 'Point blank kills',
    MOUNTED_KILLS: 'Mounted kills',
    KILLS_WITH_SUPPRESSOR: 'Kills with suppressor',
    COMPLETE_MILITARY_SPECIAL: 'Complete Military & Special',
    KILLS_WITH_GOLD: 'Kills with Gold',
    KILLS_WITH_PLATINUM: 'Kills with Platinum',
    KILLS_WITH_DIAMOND: 'Kills with Diamond',
    WINS: 'Wins',
    CANDY_COLLECTED: 'Candy collected',
  };
  return map[type] ?? type.replace(/_/g, ' ').toLowerCase();
}

/** Colour for a camo rarity / set category. */
export function rarityColor(setCategory: string): string {
  const map: Record<string, string> = {
    MILITARY: colors.tierMilitary,
    SPECIAL: colors.tierSpecial,
    GOLD: colors.tierGold,
    PLATINUM: colors.tierPlatinum,
    DIAMOND: colors.tierDiamond,
    MASTERY: colors.tierMastery,
    SEASONAL: colors.secondary,
    EVENT: colors.tierMastery,
  };
  return map[setCategory] ?? colors.primary;
}

export function formatNumber(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}k`;
  return String(n);
}

export function progressColor(pct: number): string {
  if (pct >= 100) return colors.success;
  if (pct >= 75) return colors.secondary;
  if (pct >= 40) return colors.primary;
  return colors.warning;
}
