import AsyncStorage from '@react-native-async-storage/async-storage';

/**
 * Lightweight persistent cache so the app keeps working offline.
 *
 * Every successful API response is written here; when the network is
 * unavailable we fall back to the last cached payload rather than showing an
 * empty screen. Progression data is NEVER destroyed by a failed sync.
 */
const PREFIX = 'wz.cache.';
/** Default freshness window: 10 minutes. */
const DEFAULT_TTL = 10 * 60 * 1000;

interface CacheEntry<T> {
  value: T;
  savedAt: number;
}

export async function readCache<T>(key: string): Promise<{ value: T; savedAt: number } | null> {
  try {
    const raw = await AsyncStorage.getItem(PREFIX + key);
    if (!raw) return null;
    const entry = JSON.parse(raw) as CacheEntry<T>;
    return { value: entry.value, savedAt: entry.savedAt };
  } catch {
    return null;
  }
}

export async function writeCache<T>(key: string, value: T): Promise<void> {
  try {
    const entry: CacheEntry<T> = { value, savedAt: Date.now() };
    await AsyncStorage.setItem(PREFIX + key, JSON.stringify(entry));
  } catch {
    // ignore cache write failures
  }
}

export async function clearCache(): Promise<void> {
  try {
    const keys = await AsyncStorage.getAllKeys();
    const ours = keys.filter((k) => k.startsWith(PREFIX));
    if (ours.length) await AsyncStorage.multiRemove(ours);
  } catch {
    // ignore
  }
}

export function isFresh(savedAt: number, ttl = DEFAULT_TTL): boolean {
  return Date.now() - savedAt < ttl;
}

/**
 * Wrap a network fetcher with cache-first-on-failure semantics.
 * On success the fresh payload is cached; on failure the last cached payload
 * is returned (if any) so the UI stays populated.
 */
export function withCache<T>(key: string, fetcher: () => Promise<T>) {
  return async (): Promise<T> => {
    try {
      const value = await fetcher();
      await writeCache(key, value);
      return value;
    } catch (err) {
      const cached = await readCache<T>(key);
      if (cached) return cached.value;
      throw err;
    }
  };
}
