import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';

import { onUnauthorized } from '../api/client';
import { authApi } from '../api/endpoints';
import type { AuthUser } from '../api/types';
import { clearCache } from '../lib/cache';
import { queryClient } from '../lib/queryClient';
import { tokenStore } from '../lib/tokenStore';

interface AuthState {
  user: AuthUser | null;
  status: 'loading' | 'authenticated' | 'unauthenticated';
  error: string | null;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (input: { email: string; username: string; password: string; displayName?: string }) => Promise<void>;
  signOut: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthState | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [status, setStatus] = useState<AuthState['status']>('loading');
  const [error, setError] = useState<string | null>(null);

  const bootstrap = useCallback(async () => {
    const { accessToken } = await tokenStore.load();
    if (!accessToken) {
      setStatus('unauthenticated');
      return;
    }
    try {
      const me = await authApi.me();
      setUser(me);
      setStatus('authenticated');
    } catch {
      // Token invalid/expired and refresh failed → treat as signed out.
      await tokenStore.clear();
      setUser(null);
      setStatus('unauthenticated');
    }
  }, []);

  useEffect(() => {
    bootstrap();
  }, [bootstrap]);

  useEffect(() => {
    return onUnauthorized(() => {
      setUser(null);
      setStatus('unauthenticated');
      queryClient.clear();
    });
  }, []);

  const signIn = useCallback(async (email: string, password: string) => {
    setError(null);
    const session = await authApi.login(email, password);
    await tokenStore.save(session.accessToken, session.refreshToken);
    setUser(session.user);
    setStatus('authenticated');
  }, []);

  const signUp = useCallback(
    async (input: { email: string; username: string; password: string; displayName?: string }) => {
      setError(null);
      const session = await authApi.register(input);
      await tokenStore.save(session.accessToken, session.refreshToken);
      setUser(session.user);
      setStatus('authenticated');
    },
    [],
  );

  const signOut = useCallback(async () => {
    try {
      const { refreshToken } = await tokenStore.load();
      if (refreshToken) await authApi.logout(refreshToken);
    } catch {
      // best effort
    }
    await tokenStore.clear();
    await clearCache();
    queryClient.clear();
    setUser(null);
    setStatus('unauthenticated');
  }, []);

  const refreshUser = useCallback(async () => {
    try {
      const me = await authApi.me();
      setUser(me);
    } catch {
      // ignore
    }
  }, []);

  const value = useMemo<AuthState>(
    () => ({ user, status, error, signIn, signUp, signOut, refreshUser }),
    [user, status, error, signIn, signUp, signOut, refreshUser],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
}
