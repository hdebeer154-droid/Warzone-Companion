import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

import type { ActivityItem, ActivityType } from '../api/types';
import { colors, fontSize, fontWeight, spacing } from '../theme';

const TYPE_META: Record<ActivityType, { color: string; glyph: string }> = {
  CAMO_PROGRESS: { color: colors.tierGold, glyph: '◆' },
  CAMO_COMPLETED: { color: colors.tierGold, glyph: '★' },
  WEAPON_LEVEL: { color: colors.secondary, glyph: '▲' },
  MATCH_COMPLETED: { color: colors.info, glyph: '⬢' },
  CALLING_CARD_PROGRESS: { color: colors.info, glyph: '▣' },
  CALLING_CARD_COMPLETED: { color: colors.info, glyph: '★' },
  EVENT_PROGRESS: { color: colors.tierMastery, glyph: '✦' },
  EVENT_COMPLETED: { color: colors.tierMastery, glyph: '★' },
  PLAYER_LEVEL: { color: colors.primary, glyph: '⬆' },
  PRESTIGE: { color: colors.primary, glyph: '✪' },
  SYNC: { color: colors.textMuted, glyph: '⟳' },
  OBJECTIVE: { color: colors.primary, glyph: '◎' },
  SYSTEM: { color: colors.textMuted, glyph: '•' },
};

function timeAgo(iso: string): string {
  const then = new Date(iso).getTime();
  const diff = Date.now() - then;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d ago`;
  return new Date(iso).toLocaleDateString();
}

export function ActivityRow({ item }: { item: ActivityItem }) {
  const meta = TYPE_META[item.type] ?? TYPE_META.SYSTEM;
  return (
    <View style={styles.row}>
      <View style={[styles.glyphWrap, { borderColor: meta.color }]}>
        <Text style={[styles.glyph, { color: meta.color }]}>{meta.glyph}</Text>
      </View>
      <View style={styles.body}>
        <Text style={styles.title} numberOfLines={2}>
          {item.title}
        </Text>
        {item.description && item.description !== item.title ? (
          <Text style={styles.desc} numberOfLines={2}>
            {item.description}
          </Text>
        ) : null}
      </View>
      <Text style={styles.time}>{timeAgo(item.createdAt)}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.divider,
  },
  glyphWrap: {
    width: 30,
    height: 30,
    borderRadius: 15,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.surfaceElevated,
  },
  glyph: { fontSize: 14, fontWeight: fontWeight.bold },
  body: { flex: 1, gap: 2 },
  title: {
    color: colors.text,
    fontSize: fontSize.body,
    fontWeight: fontWeight.semibold,
    lineHeight: 19,
  },
  desc: {
    color: colors.textMuted,
    fontSize: fontSize.small,
    lineHeight: 17,
  },
  time: {
    color: colors.textDim,
    fontSize: fontSize.micro,
    marginTop: 2,
  },
});
