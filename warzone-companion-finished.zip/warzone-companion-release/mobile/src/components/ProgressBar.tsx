import React from 'react';
import { StyleSheet, View, ViewStyle } from 'react-native';

import { colors, radius } from '../theme';

interface ProgressBarProps {
  value: number; // 0..100
  color?: string;
  trackColor?: string;
  height?: number;
  style?: ViewStyle;
  /** Render discrete segments instead of a smooth fill (tactical look). */
  segments?: number;
}

export function ProgressBar({
  value,
  color = colors.primary,
  trackColor = colors.surfacePressed,
  height = 8,
  style,
  segments,
}: ProgressBarProps) {
  const clamped = Math.max(0, Math.min(100, value));

  if (segments && segments > 1) {
    const filled = Math.round((clamped / 100) * segments);
    return (
      <View style={[styles.segRow, style]}>
        {Array.from({ length: segments }).map((_, i) => (
          <View
            key={i}
            style={[
              styles.segment,
              { height, backgroundColor: i < filled ? color : trackColor },
            ]}
          />
        ))}
      </View>
    );
  }

  return (
    <View style={[styles.track, { height, backgroundColor: trackColor, borderRadius: height / 2 }, style]}>
      <View
        style={{
          width: `${clamped}%`,
          height: '100%',
          backgroundColor: color,
          borderRadius: height / 2,
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  track: {
    width: '100%',
    overflow: 'hidden',
  },
  segRow: {
    flexDirection: 'row',
    width: '100%',
    gap: 3,
  },
  segment: {
    flex: 1,
    borderRadius: radius.xs,
  },
});
