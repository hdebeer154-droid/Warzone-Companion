import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { colors, fontSize, fontWeight, spacing } from '../theme';

interface SectionHeaderProps {
  title: string;
  action?: string;
  onAction?: () => void;
  subtitle?: string;
}

/** Small uppercase section label used across the app (tactical style). */
export function SectionHeader({ title, action, onAction, subtitle }: SectionHeaderProps) {
  return (
    <View style={styles.wrap}>
      <View style={styles.left}>
        <View style={styles.tick} />
        <Text style={styles.title}>{title.toUpperCase()}</Text>
      </View>
      {action ? (
        <Pressable onPress={onAction} hitSlop={8}>
          <Text style={styles.action}>{action}</Text>
        </Pressable>
      ) : null}
      {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: spacing.xl,
    marginBottom: spacing.md,
  },
  left: { flexDirection: 'row', alignItems: 'center' },
  tick: {
    width: 3,
    height: 14,
    backgroundColor: colors.primary,
    marginRight: spacing.sm,
    borderRadius: 2,
  },
  title: {
    color: colors.textSecondary,
    fontSize: fontSize.small,
    fontWeight: fontWeight.bold,
    letterSpacing: 1.6,
  },
  action: {
    color: colors.primary,
    fontSize: fontSize.small,
    fontWeight: fontWeight.semibold,
    letterSpacing: 0.5,
  },
  subtitle: {
    color: colors.textMuted,
    fontSize: fontSize.caption,
  },
});
