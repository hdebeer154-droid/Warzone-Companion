import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import type { WeaponView } from '../api/types';
import { colors, fontSize, fontWeight, monoFont, radius, spacing } from '../theme';
import { categoryLabel, progressColor } from '../lib/format';
import { ProgressBar } from './ProgressBar';

interface WeaponCardProps {
  weapon: WeaponView;
  onPress?: () => void;
  onToggleFavourite?: () => void;
}

export function WeaponCard({ weapon, onPress, onToggleFavourite }: WeaponCardProps) {
  const camoColor = progressColor(weapon.camoCompletionPct);

  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.card, pressed && styles.pressed]}>
      <View style={styles.thumb}>
        <Text style={styles.thumbGlyph}>{weapon.name.slice(0, 2).toUpperCase()}</Text>
      </View>

      <View style={styles.body}>
        <View style={styles.titleRow}>
          <View style={styles.titleText}>
            <Text style={styles.name} numberOfLines={1}>
              {weapon.name}
            </Text>
            <Text style={styles.category}>{categoryLabel(weapon.category)}</Text>
          </View>
          {onToggleFavourite ? (
            <Pressable onPress={onToggleFavourite} hitSlop={10} style={styles.favBtn}>
              <Ionicons
                name={weapon.favourite ? 'star' : 'star-outline'}
                size={18}
                color={weapon.favourite ? colors.primary : colors.textDim}
              />
            </Pressable>
          ) : null}
        </View>

        <View style={styles.metaRow}>
          <Text style={styles.level}>
            LVL <Text style={styles.levelValue}>{weapon.level}</Text>
            <Text style={styles.levelMax}>/{weapon.maxLevel}</Text>
          </Text>
          <Text style={styles.camoText}>
            Camo <Text style={{ color: camoColor }}>{weapon.camoCompletionPct}%</Text>
          </Text>
        </View>

        <ProgressBar value={weapon.levelProgressPct} color={colors.secondary} height={4} />
        <View style={styles.barSpacer} />
        <ProgressBar value={weapon.camoCompletionPct} color={camoColor} height={4} />
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    gap: spacing.md,
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
  },
  pressed: { opacity: 0.85 },
  thumb: {
    width: 54,
    height: 54,
    borderRadius: radius.md,
    backgroundColor: colors.surfaceElevated,
    borderWidth: 1,
    borderColor: colors.borderStrong,
    alignItems: 'center',
    justifyContent: 'center',
  },
  thumbGlyph: {
    color: colors.textMuted,
    fontSize: fontSize.subtitle,
    fontWeight: fontWeight.heavy,
    fontFamily: monoFont,
  },
  body: { flex: 1, gap: spacing.sm },
  titleRow: { flexDirection: 'row', alignItems: 'flex-start' },
  titleText: { flex: 1 },
  name: {
    color: colors.text,
    fontSize: fontSize.bodyLg,
    fontWeight: fontWeight.bold,
  },
  category: {
    color: colors.textMuted,
    fontSize: fontSize.caption,
    marginTop: 1,
  },
  favBtn: { padding: 2 },
  metaRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  level: {
    color: colors.textMuted,
    fontSize: fontSize.caption,
    fontWeight: fontWeight.bold,
    letterSpacing: 0.5,
  },
  levelValue: { color: colors.text, fontFamily: monoFont, fontSize: fontSize.body },
  levelMax: { color: colors.textDim },
  camoText: {
    color: colors.textMuted,
    fontSize: fontSize.caption,
    fontWeight: fontWeight.semibold,
  },
  barSpacer: { height: 2 },
});
