import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { colors, fontSize, fontWeight, monoFont, spacing } from '../theme';
import { ProgressBar } from './ProgressBar';
import { progressColor } from '../lib/format';

interface ChallengeRowProps {
  title: string;
  subtitle?: string;
  current: number;
  target: number;
  progressPct: number;
  completed: boolean;
  accent?: string;
  trailing?: React.ReactNode;
}

/** Generic challenge row reused for camo, calling-card and event challenges. */
export function ChallengeRow({
  title,
  subtitle,
  current,
  target,
  progressPct,
  completed,
  accent,
  trailing,
}: ChallengeRowProps) {
  const color = completed ? colors.success : accent ?? progressColor(progressPct);
  return (
    <View style={styles.row}>
      <View style={styles.iconWrap}>
        <Ionicons
          name={completed ? 'checkmark-circle' : 'ellipse-outline'}
          size={20}
          color={completed ? colors.success : colors.textDim}
        />
      </View>
      <View style={styles.body}>
        <View style={styles.titleRow}>
          <Text style={styles.title} numberOfLines={2}>
            {title}
          </Text>
          <Text style={[styles.count, { color }]}>
            {current}
            <Text style={styles.countDim}>/{target}</Text>
          </Text>
        </View>
        {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
        <ProgressBar value={progressPct} color={color} height={5} style={styles.bar} />
        {trailing}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    gap: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.divider,
  },
  iconWrap: { paddingTop: 2 },
  body: { flex: 1, gap: spacing.xs },
  titleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    gap: spacing.sm,
  },
  title: {
    flex: 1,
    color: colors.text,
    fontSize: fontSize.body,
    fontWeight: fontWeight.semibold,
    lineHeight: 19,
  },
  count: {
    fontSize: fontSize.body,
    fontWeight: fontWeight.bold,
    fontFamily: monoFont,
  },
  countDim: { color: colors.textMuted, fontWeight: fontWeight.regular },
  subtitle: {
    color: colors.textMuted,
    fontSize: fontSize.small,
  },
  bar: { marginTop: spacing.xs },
});
