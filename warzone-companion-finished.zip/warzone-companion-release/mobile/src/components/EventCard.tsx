import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import type { EventView } from '../api/types';
import { colors, fontSize, fontWeight, monoFont, radius, spacing } from '../theme';
import { ProgressBar } from './ProgressBar';

export function EventCard({ event }: { event: EventView }) {
  const endingSoon = event.timeRemaining.endingSoon;
  return (
    <View style={[styles.card, endingSoon && styles.endingSoon]}>
      <View style={styles.header}>
        <View style={styles.titleWrap}>
          <Text style={styles.name}>{event.name}</Text>
          <View style={styles.timeRow}>
            <Ionicons name="time-outline" size={13} color={endingSoon ? colors.danger : colors.textMuted} />
            <Text style={[styles.time, endingSoon && { color: colors.danger }]}>
              {event.timeRemaining.human} remaining
            </Text>
          </View>
        </View>
        <Text style={styles.pct}>{event.completionPct}%</Text>
      </View>

      {event.description ? (
        <Text style={styles.desc} numberOfLines={2}>
          {event.description}
        </Text>
      ) : null}

      <ProgressBar value={event.completionPct} color={colors.tierMastery} height={6} />

      <Text style={styles.challenges}>
        {event.completed}/{event.total} challenges complete
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.lg,
    gap: spacing.md,
  },
  endingSoon: {
    borderColor: 'rgba(255, 92, 92, 0.5)',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  titleWrap: { flex: 1, gap: spacing.xs },
  name: {
    color: colors.text,
    fontSize: fontSize.subtitle,
    fontWeight: fontWeight.bold,
  },
  timeRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs },
  time: {
    color: colors.textMuted,
    fontSize: fontSize.caption,
    fontWeight: fontWeight.semibold,
  },
  pct: {
    color: colors.tierMastery,
    fontSize: fontSize.h2,
    fontWeight: fontWeight.heavy,
    fontFamily: monoFont,
  },
  desc: {
    color: colors.textSecondary,
    fontSize: fontSize.small,
    lineHeight: 18,
  },
  challenges: {
    color: colors.textMuted,
    fontSize: fontSize.caption,
  },
});
