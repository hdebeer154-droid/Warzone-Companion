import React from 'react';
import { StyleSheet, Text, View, ViewStyle } from 'react-native';

import { colors, fontSize, fontWeight, monoFont, radius, spacing } from '../theme';

interface StatTileProps {
  label: string;
  value: string | number;
  accent?: string;
  style?: ViewStyle;
}

/** Compact stat tile used in the profile + match summary grids. */
export function StatTile({ label, value, accent, style }: StatTileProps) {
  return (
    <View style={[styles.tile, style]}>
      <Text style={[styles.value, accent ? { color: accent } : null]}>{value}</Text>
      <Text style={styles.label}>{label.toUpperCase()}</Text>
    </View>
  );
}

export function StatGrid({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  return <View style={[styles.grid, style]}>{children}</View>;
}

const styles = StyleSheet.create({
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  tile: {
    flexGrow: 1,
    flexBasis: '30%',
    minWidth: 92,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.md,
  },
  value: {
    color: colors.text,
    fontSize: fontSize.h2,
    fontWeight: fontWeight.heavy,
    fontFamily: monoFont,
    letterSpacing: -0.5,
  },
  label: {
    color: colors.textMuted,
    fontSize: fontSize.micro,
    fontWeight: fontWeight.bold,
    letterSpacing: 1.2,
    marginTop: spacing.xs,
  },
});
