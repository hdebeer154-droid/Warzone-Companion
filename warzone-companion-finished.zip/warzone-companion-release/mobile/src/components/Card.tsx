import React from 'react';
import { Pressable, StyleSheet, View, ViewStyle } from 'react-native';

import { colors, radius, shadow, spacing } from '../theme';

interface CardProps {
  children: React.ReactNode;
  style?: ViewStyle;
  onPress?: () => void;
  accent?: string;
  padded?: boolean;
}

/** Dark tactical surface card with an optional left accent rail. */
export function Card({ children, style, onPress, accent, padded = true }: CardProps) {
  const body = (
    <View style={[styles.card, padded && styles.padded, style]}>
      {accent ? <View style={[styles.rail, { backgroundColor: accent }]} /> : null}
      <View style={styles.inner}>{children}</View>
    </View>
  );

  if (onPress) {
    return (
      <Pressable onPress={onPress} style={({ pressed }) => [pressed && styles.pressed]}>
        {body}
      </Pressable>
    );
  }
  return body;
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    overflow: 'hidden',
    ...shadow.card,
  },
  padded: {
    padding: spacing.lg,
  },
  inner: { flex: 1 },
  rail: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 3,
  },
  pressed: {
    opacity: 0.85,
  },
});
