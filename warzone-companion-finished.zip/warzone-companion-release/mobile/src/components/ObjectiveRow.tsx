import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

import type { ObjectiveType, ObjectiveView } from '../api/types';
import { colors, fontSize, fontWeight, monoFont, spacing } from '../theme';
import { Badge } from './Badge';
import { ProgressBar } from './ProgressBar';

const TYPE_COLOR: Record<ObjectiveType, string> = {
  CAMO: colors.tierGold,
  CALLING_CARD: colors.info,
  EVENT: colors.tierMastery,
  WEAPON_LEVEL: colors.secondary,
  CUSTOM: colors.primary,
  OTHER: colors.textMuted,
};

const TYPE_LABEL: Record<ObjectiveType, string> = {
  CAMO: 'CAMO',
  CALLING_CARD: 'CALLING CARD',
  EVENT: 'EVENT',
  WEAPON_LEVEL: 'WEAPON',
  CUSTOM: 'CUSTOM',
  OTHER: 'OBJECTIVE',
};

export function ObjectiveRow({ objective }: { objective: ObjectiveView }) {
  const color = TYPE_COLOR[objective.type] ?? colors.primary;
  const endingSoon = Boolean(objective.metadata && (objective.metadata as Record<string, unknown>).endingSoon);

  return (
    <View style={styles.row}>
      <View style={styles.header}>
        <Badge label={TYPE_LABEL[objective.type] ?? 'OBJECTIVE'} color={color} />
        {endingSoon ? <Badge label="Ending soon" color={colors.danger} /> : null}
      </View>
      <Text style={styles.label} numberOfLines={2}>
        {objective.label}
      </Text>
      <View style={styles.progressRow}>
        <ProgressBar value={objective.progressPct} color={color} height={6} style={styles.bar} />
        <Text style={styles.count}>
          {objective.current}
          <Text style={styles.countDim}>/{objective.target}</Text>
        </Text>
      </View>
      <Text style={styles.remaining}>
        {objective.remaining > 0 ? `${objective.remaining} remaining` : 'Complete'}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    paddingVertical: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.divider,
    gap: spacing.sm,
  },
  header: { flexDirection: 'row', gap: spacing.sm },
  label: {
    color: colors.text,
    fontSize: fontSize.bodyLg,
    fontWeight: fontWeight.semibold,
  },
  progressRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  bar: { flex: 1 },
  count: {
    color: colors.text,
    fontSize: fontSize.body,
    fontWeight: fontWeight.bold,
    fontFamily: monoFont,
    minWidth: 64,
    textAlign: 'right',
  },
  countDim: { color: colors.textMuted, fontWeight: fontWeight.regular },
  remaining: {
    color: colors.textMuted,
    fontSize: fontSize.caption,
  },
});
