import React from 'react';
import { StyleSheet, Text, View, ViewStyle } from 'react-native';

import { colors, fontSize, fontWeight, radius, spacing } from '../theme';

interface BadgeProps {
  label: string;
  color?: string;
  soft?: boolean;
  style?: ViewStyle;
}

export function Badge({ label, color = colors.primary, soft = true, style }: BadgeProps) {
  return (
    <View
      style={[
        styles.badge,
        soft ? { backgroundColor: hexToSoft(color) } : { backgroundColor: color },
        style,
      ]}
    >
      <Text style={[styles.text, { color: soft ? color : colors.black }]}>{label.toUpperCase()}</Text>
    </View>
  );
}

/** Convert a hex colour to a translucent version for soft badges. */
function hexToSoft(hex: string): string {
  if (hex.startsWith('rgba')) return hex;
  const clean = hex.replace('#', '');
  const r = parseInt(clean.substring(0, 2), 16);
  const g = parseInt(clean.substring(2, 4), 16);
  const b = parseInt(clean.substring(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, 0.16)`;
}

const styles = StyleSheet.create({
  badge: {
    alignSelf: 'flex-start',
    paddingHorizontal: spacing.sm,
    paddingVertical: 3,
    borderRadius: radius.xs,
  },
  text: {
    fontSize: fontSize.micro,
    fontWeight: fontWeight.bold,
    letterSpacing: 1,
  },
});
