# Task: Upgrade Warzone Companion mobile app to Expo SDK 57

## 1. Research & Version Resolution
- [x] Fetch authoritative SDK 57 bundled native module versions
- [x] Determine target versions for expo, react-native, react, react-dom, expo-* packages
- [x] Determine target versions for @react-navigation, safe-area-context, screens, svg, vector-icons, typescript, @types/react

## 2. Dependency Upgrade
- [x] Update mobile/package.json to SDK 57 versions
- [x] Run npm install (clean) in mobile/
- [x] Verify installed expo/react-native versions (expo 57.0.26, RN 0.86.3, React 19.2.3)

## 3. Code & Config Compatibility
- [x] Update app.json (removed newArchEnabled/splash keys; added expo-splash-screen plugin)
- [x] Fix React 18 -> 19 type/API changes (Screen refreshControl type)
- [x] Fix expo-image-picker mediaTypes API change (MediaTypeOptions.Images -> ['images'])
- [x] Fix expo-notifications handler API change (shouldShowBanner/shouldShowList)
- [x] Update tsconfig.json for TS6 / SDK 57 base (removed deprecated baseUrl)
- [x] Add babel-preset-expo + expo-splash-screen + expo-doctor deps

## 4. Verification
- [x] Run tsc --noEmit (mobile) and fix errors -> exit 0
- [x] Run expo-doctor (21/21 passed) and expo install --check (up to date)
- [x] Verify app config resolves (sdkVersion 57.0.0)
- [x] Build Android bundle (expo export: 1068 modules, 2.7MB hbc)

## 5. Docs
- [x] Update docs/SETUP.md for SDK 57
- [x] Update docs/ANDROID_QUICKSTART.md for SDK 57 + new tunnel URL
- [x] Update README.md tech stack table

## 6. Delivery
- [x] Restart Expo dev server on SDK 57 + tunnel; regenerate QR
- [x] Summarize changes and deliver
