# Architecture

Warzone Companion is split into two independently deployable applications — a **NestJS backend**
and a **React Native/Expo mobile client** — plus supporting infrastructure (PostgreSQL, Redis,
object storage). The client only ever talks to our backend.

```
Mobile App ──► Our Backend API ──► PostgreSQL / Redis ──► Background Workers ──► Data Providers
```

## 1. Backend (NestJS)

The backend is organised into feature modules under `backend/src/`. Each module owns its controller,
service and (where relevant) DTOs. Cross-cutting concerns live in `src/common/`.

### Modules

| Module | Responsibility |
|--------|----------------|
| `auth` | Register, login, refresh (rotating), logout, password reset/change, `me`. |
| `profile` | Player profile + progression (level, prestige, XP). |
| `accounts` | Linked COD accounts, sync status, provider list. |
| `dashboard` | Aggregated dashboard payload (objectives, weapon, calling card, event, activity). |
| `weapons` | Weapon catalog, categories, per-user level/XP progress, favourites. |
| `camos` | Camo sets, camos, challenges, per-weapon progress, overview. |
| `calling-cards` | Calling cards + their challenges and progress. |
| `events` | Seasonal events, challenges, rewards, progress, time-remaining. |
| `matches` | Match history, per-match stats, weapon breakdown, aggregate stats. |
| `activity` | Semantic activity feed generation + read state. |
| `objectives` | Objective engine: unfinished + overlapping objective detection. |
| `ocr` | Screenshot upload, preprocessing, OCR, detection parsing, confirm/reject. |
| `sync` | Sync orchestration, runs, provider health, queue introspection. |
| `notifications` | Notification preferences + push-token registration + worker. |
| `admin` | Protected CRUD for all catalog data (games, seasons, weapons, camos, …). |
| `catalog` | Public game/season metadata. |
| `providers` | `GameDataProvider` interface, registry, mock/manual/ocr/activision impls. |
| `storage` | S3-compatible storage abstraction with local-disk fallback. |
| `queue` | BullMQ queue definitions + worker bootstrap. |
| `redis` | Redis client wrapper (rate limiting, caching, queue backing). |
| `prisma` | Prisma client lifecycle. |
| `audit` | Audit logging for sensitive operations. |
| `health` | Liveness/readiness incl. DB + Redis + queue depths. |

### Cross-cutting

- **Global response envelope** — every response is wrapped as `{ success: true, data: ... }` by
  `TransformInterceptor`; errors become `{ success: false, error: { message, statusCode } }` via
  `AllExceptionsFilter`.
- **Global guards** — `JwtAuthGuard` (auth), `RolesGuard` (RBAC), `ThrottlerGuard` (rate limiting).
  Routes opt out with `@Public()`; roles are declared with `@Roles(...)`.
- **Row-level authorization** — services scope every user-specific query by `userId`; a user can only
  ever read/write their own progression.
- **Validation** — `class-validator`/`class-transformer` DTOs with a global `ValidationPipe`
  (whitelist + forbidNonWhitelisted + transform).

## 2. Data model (PostgreSQL / Prisma)

The schema is fully normalized; **no game data is hard-coded in the UI** — it is all served from the
database and editable via the admin module.

**Identity & auth:** `User`, `RefreshToken`, `PasswordResetToken`, `AuditLog`, `PushToken`,
`NotificationPreference`.

**Player:** `CodAccount`, `PlayerProfile`, `SyncRun`, `ProviderHealth`.

**Catalog:** `Game`, `Season`, `Weapon`, `WeaponLevel`, `CamoSet`, `Camo`, `CamoChallenge`,
`CallingCard`, `CallingCardChallenge`, `Event`, `EventChallenge`, `EventReward`.

**Per-user progress:** `WeaponProgress`, `WeaponFavorite`, `CamoProgress`, `CallingCardProgress`,
`EventProgress`, `Match`, `MatchWeaponStat`, `ActivityEvent`, `UserObjective`, `OcrScan`.

Every progress row carries a **`source`** field (`API` | `OCR` | `MANUAL` | `CALCULATED`) so the
origin of a value is always auditable, and the UI can show where a number came from.

### Enums

`UserRole`, `Platform`, `SyncStatus`, `WeaponCategory`, `CamoCategory`, `ProgressSource`,
`ActivityType`, `ObjectiveType`, `ObjectiveStatus`, `OcrStatus`, `NotificationCategory`.

## 3. Provider abstraction

The single integration point with the outside world is the `GameDataProvider` interface:

```ts
interface GameDataProvider {
  readonly key: string;
  getIdentity(account): Promise<Identity>;
  getProfile(account): Promise<ProfileSnapshot>;
  getMatches(account, since?): Promise<MatchSnapshot[]>;
  getMatchDetails(account, matchId): Promise<MatchDetail>;
  getWeaponStats(account): Promise<WeaponStatSnapshot[]>;
  getChallenges(account): Promise<ChallengeSnapshot[]>;
  getProgression(account): Promise<ProgressionSnapshot>;
}
```

Implementations:

- **`MockProvider`** — deterministic, seeded from existing DB state. Used for the demo account and
  local development. It *anchors* to current values and advances them slightly, so syncs never
  clobber seeded demo data.
- **`ManualProvider`** — user-entered values.
- **`OcrProvider`** — values derived from screenshot scans.
- **`ActivisionProvider`** — a clearly-labelled, **disabled stub** (`ENABLE_ACTIVISION_PROVIDER=false`).
  It is *not* a fake working integration; it documents the seam where a legitimate data source plugs in.

Providers are resolved through a `ProviderRegistry` and monitored by `ProviderHealth` (success rate,
latency, last error) so the app can degrade gracefully when a provider is unhealthy.

## 4. Sync engine

Automatic synchronization is an incremental, non-destructive pipeline driven by BullMQ:

1. Retrieve identity → 2. profile → 3. match history → 4. player stats → 5. weapon info →
6. normalize → 7. compare against previous DB state → 8. calculate changes → 9. update DB →
10. generate activity events → 11. update objectives → 12. notify the mobile app.

Properties:

- **Incremental** — `last_sync_at` bounds each run; only new matches/changes are processed.
- **Non-destructive** — a failed or partial sync **never erases** existing data. On failure the app
  keeps showing the last known values and displays "Last synchronized 37 minutes ago."
- **Resilient** — exponential backoff retries, rate limiting, caching, and provider health monitoring.
- **Queued** — sync, OCR and notification work runs on separate BullMQ queues with dedicated workers.

## 5. Screenshot / OCR pipeline

```
Screenshot → preprocessing (sharp: resize/grayscale/normalize/sharpen)
           → OCR (Tesseract.js)
           → UI/text recognition → text normalization
           → database matching → confidence scoring
           → progress update
```

- Confidence **≥ 95%** and matched → applied automatically.
- Below threshold (or unmatched) → scan is `AWAITING_CONFIRMATION`; the user sees the detected
  changes with **CONFIRM / EDIT** actions.
- **Never regresses**: a lower OCR value will not overwrite a higher stored value unless the user
  explicitly confirms it (`applyDetections(..., explicit)`).

## 6. Mobile app (React Native / Expo)

- **Theme** — dark, premium, gaming-oriented tactical palette (`src/theme`), no generic SaaS look.
- **Data layer** — React Query with cache-first-on-failure + AsyncStorage persistence, so the app is
  fully usable offline with the last synced data and re-syncs on reconnect.
- **Auth** — tokens in `expo-secure-store`; a single-flight refresh handler retries once on 401 and
  signs out on failure.
- **Navigation** — bottom tabs (HOME, CAMOS, WEAPONS, CHALLENGES, PROFILE) + a native stack for
  Scanner and detail screens.
- **OCR upload** — `multipart/form-data` via `FormData` with `{ uri, name, type }` to `/ocr/scan`.

## 7. Security

- Passwords hashed with bcrypt; **Activision passwords are never requested or stored**.
- Short-lived access tokens (15 min) + rotating refresh tokens (30 days), revocable per-device.
- Row-level authorization on every user-specific query.
- Input validation, API rate limiting, secrets via environment variables (never shipped to mobile).
- Audit logging for sensitive operations.
