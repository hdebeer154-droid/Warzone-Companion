# Setup & Running

This guide gets the full stack running locally: PostgreSQL, Redis, the NestJS backend, and the
Expo mobile app.

## Prerequisites

- **Node.js 20+** and npm
- **PostgreSQL 15+**
- **Redis 6+**
- **Expo Go** (SDK 57) on a device, or an Android/iOS simulator
- Optional: `poppler-utils`, `tesseract` (system libs are bundled via `tesseract.js`)

## 1. Infrastructure

Start PostgreSQL and Redis and create the database:

```bash
# PostgreSQL
sudo service postgresql start
sudo -u postgres psql -c "CREATE DATABASE warzone_companion;"

# Redis
sudo service redis-server start
redis-cli ping          # → PONG
```

## 2. Backend

```bash
cd backend
npm install
cp .env.example .env     # if present, otherwise create .env (see below)
npx prisma generate
npx prisma migrate deploy
npm run db:seed          # seeds catalog + FENRIR demo account
npm run build
node dist/src/main.js    # → http://127.0.0.1:4100/api/v1
```

> **Note:** port `4000` is often taken by other tooling; the backend defaults to **4100**.

### `backend/.env`

```ini
PORT=4100
API_PREFIX=api/v1
DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/warzone_companion?schema=public
REDIS_HOST=127.0.0.1
REDIS_PORT=6379
QUEUE_PREFIX=wz
JWT_ACCESS_SECRET=change-me-access
JWT_REFRESH_SECRET=change-me-refresh
JWT_ACCESS_TTL=900
JWT_REFRESH_TTL=2592000
STORAGE_DRIVER=local
STORAGE_LOCAL_DIR=./storage
DEFAULT_PROVIDER=mock
ENABLE_ACTIVISION_PROVIDER=false
OCR_CONFIDENCE_THRESHOLD=0.95
SEED_DEMO=true
DEMO_EMAIL=fenrir@warzone.gg
DEMO_PASSWORD="Fenrir#2025"
```

> Quote `DEMO_PASSWORD` so the `#` is not parsed as a comment.

### Useful scripts

| Command | Purpose |
|---------|---------|
| `npm run start:dev` | Watch-mode dev server. |
| `npm run build` | Compile to `dist/`. |
| `npm run start:prod` | Run compiled server (`dist/src/main.js`). |
| `npm run typecheck` | `tsc --noEmit`. |
| `npm run prisma:migrate` | Apply migrations (`prisma migrate deploy`). |
| `npm run db:seed` | Seed catalog + demo account. |
| `npm test` / `npm run test:e2e` | Unit / e2e tests. |

## 3. Mobile app

The app targets **Expo SDK 57** (React Native 0.86, React 19, New Architecture enabled).

```bash
cd mobile
npm install
npx expo start
```

Press `a` for Android, `i` for iOS, or scan the QR code with Expo Go (make sure Expo Go is
updated to the latest version so it supports SDK 57).

Verify the toolchain at any time:

```bash
cd mobile
npx expo install --check   # confirms every dependency matches SDK 57
npx expo-doctor            # 21 project health checks
npm run typecheck          # tsc --noEmit
```

### `mobile/.env`

```ini
EXPO_PUBLIC_API_BASE_URL=http://127.0.0.1:4100/api/v1
```

`app.json` also carries `extra.apiBaseUrl` as a fallback. On a physical device, replace
`127.0.0.1` with your machine's LAN IP.

### Typecheck

```bash
cd mobile
npm run typecheck
```

## 4. Sign in

Use the seeded demo account:

| Field | Value |
|-------|-------|
| Email | `fenrir@warzone.gg` |
| Password | `Fenrir#2025` |

The Login screen also has a **"Use demo account (FENRIR)"** shortcut that fills these in.

## 5. UI preview (no device required)

A static rendering of every screen is generated from `preview/`:

```bash
node preview/build.js
python3 -m http.server 8090 --directory preview
# open http://127.0.0.1:8090
```

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| Backend won't start, `EADDRINUSE` | Another process holds the port; change `PORT`. |
| `prisma migrate deploy` fails | Ensure PostgreSQL is up and `DATABASE_URL` is correct. |
| Mobile can't reach API | Use your LAN IP instead of `127.0.0.1` on a physical device. |
| OCR returns `FAILED` | The screenshot had no recognizable progress text; try a clearer crop. |
| `npx` hangs | Invoke local binaries directly: `./node_modules/.bin/tsc`, `./node_modules/.bin/nest`. |
